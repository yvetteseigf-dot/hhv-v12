package com.example.hhggk.module.visual;

import com.example.hhggk.module.Drawable3D;
import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;
import com.example.hhggk.render.Overlay3D;

import net.minecraft.block.entity.BarrelBlockEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.block.entity.EnderChestBlockEntity;
import net.minecraft.block.entity.MobSpawnerBlockEntity;
import net.minecraft.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.WorldChunk;

import java.util.ArrayList;
import java.util.List;

/** Boxes around chests, ender chests, shulkers, barrels and spawners (find stashes / bases). */
public class StorageESP extends Module implements Drawable3D {
    public final Setting.Num range = add(new Setting.Num("Range (chunks)", 6, 1, 12, 1));
    public final Setting.Bool spawners = add(new Setting.Bool("Spawners", true));

    private static class Entry { BlockPos pos; float r, g, b; }
    private final List<Entry> list = new ArrayList<>();
    private int cd;

    public StorageESP() { super("StorageESP", Category.VISUAL); }

    @Override
    public void onTick(MinecraftClient mc) {
        if (cd-- > 0) return;
        cd = 20;
        list.clear();
        int cr = (int) range.value;
        int pcx = mc.player.getBlockPos().getX() >> 4, pcz = mc.player.getBlockPos().getZ() >> 4;
        for (int cx = pcx - cr; cx <= pcx + cr; cx++) for (int cz = pcz - cr; cz <= pcz + cr; cz++) {
            WorldChunk ch = mc.world.getChunkManager().getWorldChunk(cx, cz);
            if (ch == null) continue;
            for (BlockEntity be : ch.getBlockEntities().values()) {
                Entry e = new Entry();
                e.pos = be.getPos();
                if (be instanceof EnderChestBlockEntity) { e.r = 0.7f; e.g = 0.2f; e.b = 1f; }
                else if (be instanceof ShulkerBoxBlockEntity) { e.r = 1f; e.g = 0.4f; e.b = 0.9f; }
                else if (be instanceof ChestBlockEntity) { e.r = 1f; e.g = 0.75f; e.b = 0.2f; }
                else if (be instanceof BarrelBlockEntity) { e.r = 0.75f; e.g = 0.55f; e.b = 0.3f; }
                else if (spawners.value && be instanceof MobSpawnerBlockEntity) { e.r = 1f; e.g = 0.15f; e.b = 0.15f; }
                else continue;
                list.add(e);
            }
        }
    }

    @Override
    public void draw3d(MinecraftClient mc, MatrixStack ms, VertexConsumerProvider vcp, Vec3d cam, float td) {
        for (Entry e : list) {
            Box b = new Box(e.pos);
            Overlay3D.filled(ms, vcp, b, e.r, e.g, e.b, 0.2f);
            Overlay3D.outline(ms, vcp, b, e.r, e.g, e.b, 1f);
        }
    }
}
