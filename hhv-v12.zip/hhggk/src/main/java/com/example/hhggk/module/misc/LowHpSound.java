package com.example.hhggk.module.misc;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.sound.SoundEvents;

/** Beeps while your health is low. */
public class LowHpSound extends Module {
    public final Setting.Num health = add(new Setting.Num("Below (hp)", 6, 1, 19, 1));
    private int t;

    public LowHpSound() { super("LowHpSound", Category.MISC); }

    @Override
    public void onTick(MinecraftClient mc) {
        if (mc.player.getHealth() > health.value) { t = 0; return; }
        if (++t % 12 == 1) mc.player.playSound(SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, 0.8f, 0.6f);
    }
}
