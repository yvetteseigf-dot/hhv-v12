package com.example.hhggk.module.visual;

import com.example.hhggk.module.HudText;

import net.minecraft.client.MinecraftClient;
import java.util.ArrayDeque;

public class CpsHud extends HudText {
    private final ArrayDeque<Long> clicks = new ArrayDeque<>();
    private boolean was;

    @Override
    public void onTick(MinecraftClient mc) {
        boolean now = mc.options.attackKey.isPressed();
        if (now && !was) clicks.addLast(System.currentTimeMillis());
        was = now;
    }

    public CpsHud() { super("CpsHud", Category.VISUAL, 0, 30); }

    @Override
    protected String text(MinecraftClient mc) {
        long now = System.currentTimeMillis();
        while (!clicks.isEmpty() && now - clicks.peekFirst() > 1000L) clicks.pollFirst();
        return "CPS " + clicks.size();
    }
}
