package com.example.hhggk;

import com.example.hhggk.module.Setting;
import net.minecraft.block.Block;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.List;

/** Every block of the game in a grid: search, pick one, press Yes. */
public class BlockPickerScreen extends Screen {
    private static final int CELL = 22;

    private final Screen parent;
    private final Setting.BlockPick pick;
    private final List<Block> all = new ArrayList<>();
    private List<Block> shown = new ArrayList<>();
    private Block selected;
    private double scroll;
    private TextFieldWidget search;

    private int cols, gridX, gridTop, gridBot;

    public BlockPickerScreen(Screen parent, Setting.BlockPick pick) {
        super(Text.literal("Pick a block"));
        this.parent = parent;
        this.pick = pick;
        this.selected = pick.block();
    }

    @Override
    protected void init() {
        if (all.isEmpty()) {
            for (Block b : Registries.BLOCK) {
                Item it = b.asItem();
                if (it == null || it == Items.AIR) continue;     // fire, water, portals... cannot be held
                all.add(b);
            }
            all.sort((a, b) -> a.getName().getString().compareToIgnoreCase(b.getName().getString()));
        }

        search = new TextFieldWidget(textRenderer, width / 2 - 100, 24, 200, 16, Text.literal("Search"));
        search.setMaxLength(40);
        search.setPlaceholder(Text.literal("Search block..."));
        search.setChangedListener(s -> { filter(s); scroll = 0; });
        addDrawableChild(search);
        setInitialFocus(search);
        filter(search.getText());

        int by = height - 28;
        addDrawableChild(ButtonWidget.builder(Text.literal("Yes"), b -> confirm())
                .dimensions(width / 2 - 104, by, 100, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Cancel"), b -> close())
                .dimensions(width / 2 + 4, by, 100, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("^"), b -> scrollRows(-3))
                .dimensions(width - 26, 44, 20, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("v"), b -> scrollRows(3))
                .dimensions(width - 26, 66, 20, 20).build());
    }

    private void filter(String q) {
        String s = q == null ? "" : q.trim().toLowerCase();
        List<Block> out = new ArrayList<>();
        for (Block b : all) {
            if (s.isEmpty()
                    || b.getName().getString().toLowerCase().contains(s)
                    || Registries.BLOCK.getId(b).getPath().contains(s.replace(' ', '_'))) out.add(b);
        }
        shown = out;
    }

    private void confirm() {
        if (selected != null) pick.set(selected);
        close();
    }

    @Override
    public void close() { client.setScreen(parent); }

    @Override
    public boolean shouldPause() { return false; }

    private int totalRows() { return (shown.size() + cols - 1) / Math.max(1, cols); }

    private double maxScroll() {
        return Math.max(0, totalRows() * CELL - (gridBot - gridTop));
    }

    private void scrollRows(int rows) {
        scroll = Math.max(0, Math.min(maxScroll(), scroll + rows * CELL));
    }

    private void layout() {
        cols = Math.max(1, (width - 60) / CELL);
        gridX = (width - cols * CELL) / 2;
        gridTop = 46;
        gridBot = height - 62;
        scroll = Math.max(0, Math.min(maxScroll(), scroll));
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        ctx.fillGradient(0, 0, width, height, 0xE0120826, 0xF00A1030);
        layout();
        ctx.drawCenteredTextWithShadow(textRenderer,
                Text.literal("Pick a block").formatted(Formatting.BOLD), width / 2, 8, 0xFFB794FF);

        Block hover = null;
        ctx.enableScissor(gridX, gridTop, gridX + cols * CELL, gridBot);
        for (int i = 0; i < shown.size(); i++) {
            int x = gridX + (i % cols) * CELL;
            int y = gridTop + (i / cols) * CELL - (int) scroll;
            if (y + CELL < gridTop || y > gridBot) continue;
            Block b = shown.get(i);
            boolean sel = b == selected;
            boolean hov = mx >= x && mx < x + CELL && my >= y && my < y + CELL
                    && my >= gridTop && my < gridBot;
            if (hov) hover = b;
            ctx.fill(x + 1, y + 1, x + CELL - 1, y + CELL - 1, sel ? 0xFF4B2FA8 : (hov ? 0xFF2A2650 : 0xAA14141F));
            if (sel) {
                ctx.fill(x, y, x + CELL, y + 1, 0xFFB794FF);
                ctx.fill(x, y + CELL - 1, x + CELL, y + CELL, 0xFFB794FF);
                ctx.fill(x, y, x + 1, y + CELL, 0xFFB794FF);
                ctx.fill(x + CELL - 1, y, x + CELL, y + CELL, 0xFFB794FF);
            }
            ctx.drawItem(new ItemStack(b.asItem()), x + 3, y + 3);
        }
        ctx.disableScissor();

        if (shown.isEmpty()) {
            ctx.drawCenteredTextWithShadow(textRenderer, "No block found", width / 2, gridTop + 20, 0xFFC8C8D8);
        }

        // selected block
        if (selected != null) {
            ctx.drawItem(new ItemStack(selected.asItem()), width / 2 - 100, height - 54);
            ctx.drawTextWithShadow(textRenderer,
                    Text.literal("Selected: ").append(selected.getName()).formatted(Formatting.WHITE),
                    width / 2 - 78, height - 50, 0xFFFFFFFF);
        }
        ctx.drawTextWithShadow(textRenderer, shown.size() + " blocks", 8, 8, 0xFFC8C8D8);

        super.render(ctx, mx, my, delta);   // search box + buttons
        if (hover != null) ctx.drawTooltip(textRenderer, hover.getName(), mx, my);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (super.mouseClicked(mx, my, button)) return true;
        if (button == 0 && my >= gridTop && my < gridBot && mx >= gridX && mx < gridX + cols * CELL) {
            int col = (int) ((mx - gridX) / CELL);
            int row = (int) ((my - gridTop + scroll) / CELL);
            int i = row * cols + col;
            if (col >= 0 && col < cols && i >= 0 && i < shown.size()) {
                selected = shown.get(i);
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double hAmount, double vAmount) {
        scroll = Math.max(0, Math.min(maxScroll(), scroll - vAmount * CELL));
        return true;
    }
}
