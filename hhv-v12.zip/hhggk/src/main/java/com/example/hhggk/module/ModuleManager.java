package com.example.hhggk.module;

import com.example.hhggk.module.combat.AntiBot;
import com.example.hhggk.module.combat.Aura;
import com.example.hhggk.module.combat.AutoGap;
import com.example.hhggk.module.combat.AutoMace;
import com.example.hhggk.module.combat.AutoTotem;
import com.example.hhggk.module.combat.BowAimbot;
import com.example.hhggk.module.combat.CrystalBreaker;
import com.example.hhggk.module.combat.Hitbox;
import com.example.hhggk.module.combat.PopCounter;
import com.example.hhggk.module.combat.Reach;
import com.example.hhggk.module.combat.Teams;
import com.example.hhggk.module.combat.TriggerBot;
import com.example.hhggk.module.combat.Velocity;
import com.example.hhggk.module.misc.AutoRespawn;
import com.example.hhggk.module.misc.AutoSprint;
import com.example.hhggk.module.misc.FakePlayer;
import com.example.hhggk.module.misc.Spin;
import com.example.hhggk.module.misc.Timer;
import com.example.hhggk.module.movement.AutoElytra;
import com.example.hhggk.module.movement.AutoWalk;
import com.example.hhggk.module.movement.BunnyHop;
import com.example.hhggk.module.movement.ElytraTarget;
import com.example.hhggk.module.movement.Flight;
import com.example.hhggk.module.movement.Glide;
import com.example.hhggk.module.movement.HighJump;
import com.example.hhggk.module.movement.Jesus;
import com.example.hhggk.module.movement.NoFall;
import com.example.hhggk.module.movement.Speed;
import com.example.hhggk.module.movement.Spider;
import com.example.hhggk.module.movement.Step;
import com.example.hhggk.module.movement.SuperFireworks;
import com.example.hhggk.module.render.ArmorHud;
import com.example.hhggk.module.render.Freecam;
import com.example.hhggk.module.render.HudModule;
import com.example.hhggk.module.render.Radar;
import com.example.hhggk.module.render.TargetHud;
import com.example.hhggk.module.visual.ComboCounter;
import com.example.hhggk.module.visual.Coords;
import com.example.hhggk.module.visual.CustomCrosshair;
import com.example.hhggk.module.visual.Esp;
import com.example.hhggk.module.visual.FovChanger;
import com.example.hhggk.module.visual.Fullbright;
import com.example.hhggk.module.visual.Hat;
import com.example.hhggk.module.visual.Hell;
import com.example.hhggk.module.visual.HitMarker;
import com.example.hhggk.module.visual.HitParticles;
import com.example.hhggk.module.visual.JumpCircles;
import com.example.hhggk.module.visual.Keystrokes;
import com.example.hhggk.module.visual.KillEffect;
import com.example.hhggk.module.visual.LowHealthWarning;
import com.example.hhggk.module.visual.NoWeather;
import com.example.hhggk.module.visual.PingHud;
import com.example.hhggk.module.visual.ShowHitboxes;
import com.example.hhggk.module.visual.SpeedHud;
import com.example.hhggk.module.visual.TargetCircle;
import com.example.hhggk.module.visual.TotemCount;
import com.example.hhggk.module.visual.Tracers;
import com.example.hhggk.module.visual.Trails;
import com.example.hhggk.module.visual.Watermark;

import com.example.hhggk.Settings;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

import net.fabricmc.loader.api.FabricLoader;

import java.lang.reflect.Modifier;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.List;

public class ModuleManager {
    public static final List<Module> modules = new ArrayList<>();
    public static Aura aura;
    public static Hitbox hitbox;
    public static Speed speed;
    public static Flight flight;
    public static SuperFireworks fireworks;
    public static ElytraTarget elytraTarget;
    public static Esp esp;
    public static Freecam freecam;
    public static Timer timer;
    public static FakePlayer fakePlayer;
    public static AutoMace autoMace;
    public static Hat hat;
    public static Hell hell;
    public static ShowHitboxes showHitboxes;
    public static Velocity velocity;
    public static AntiBot antiBot;
    public static Teams teams;
    public static PopCounter popCounter;
    public static Reach reach;
    public static HitParticles hitParticles;
    public static Tracers tracers;

    public static void init() {
        aura = new Aura();
        hitbox = new Hitbox();
        speed = new Speed();
        flight = new Flight();
        fireworks = new SuperFireworks();
        elytraTarget = new ElytraTarget();
        esp = new Esp();
        freecam = new Freecam();
        timer = new Timer();
        fakePlayer = new FakePlayer();
        autoMace = new AutoMace();
        hat = new Hat();
        hell = new Hell();
        showHitboxes = new ShowHitboxes();
        velocity = new Velocity();
        antiBot = new AntiBot();
        teams = new Teams();
        popCounter = new PopCounter();
        reach = new Reach();
        hitParticles = new HitParticles();
        tracers = new Tracers();

        // order = display order inside each column; Timer last so it ticks last
        // Combat
        modules.add(aura);
        modules.add(hitbox);
        modules.add(autoMace);
        modules.add(new AutoTotem());
        modules.add(new TriggerBot());
        modules.add(new CrystalBreaker());
        modules.add(new AutoGap());
        modules.add(new BowAimbot());
        modules.add(reach);
        modules.add(velocity);
        modules.add(antiBot);
        modules.add(teams);
        modules.add(popCounter);
        // Movement
        modules.add(speed);
        modules.add(flight);
        modules.add(fireworks);
        modules.add(elytraTarget);
        modules.add(new Step());
        modules.add(new HighJump());
        modules.add(new Glide());
        modules.add(new Spider());
        modules.add(new Jesus());
        modules.add(new AutoWalk());
        modules.add(new NoFall());
        modules.add(new BunnyHop());
        modules.add(new AutoElytra());
        // Visual
        modules.add(esp);
        modules.add(new Fullbright());
        modules.add(new FovChanger());
        modules.add(new NoWeather());
        modules.add(showHitboxes);
        modules.add(hat);
        modules.add(hell);
        modules.add(tracers);
        modules.add(new Trails());
        modules.add(new JumpCircles());
        modules.add(hitParticles);
        modules.add(new KillEffect());
        modules.add(new TargetCircle());
        modules.add(new HitMarker());
        modules.add(new ComboCounter());
        modules.add(new CustomCrosshair());
        modules.add(new Keystrokes());
        modules.add(new TotemCount());
        modules.add(new PingHud());
        modules.add(new LowHealthWarning());
        modules.add(new Watermark());
        modules.add(new Coords());
        modules.add(new SpeedHud());
        // Render
        modules.add(freecam);
        modules.add(new HudModule());
        modules.add(new TargetHud());
        modules.add(new ArmorHud());
        modules.add(new Radar());
        // Misc
        modules.add(new AutoSprint());
        modules.add(new AutoRespawn());
        modules.add(new Spin());
        modules.add(fakePlayer);
        modules.add(timer);

        discover();
    }

    /**
     * Drop-in modules: any class extending Module that sits in module/combat, movement, visual, render or misc
     * (and is not registered above) is created automatically and shows up in its menu. No registration needed.
     */
    private static void discover() {
        try {
            var container = FabricLoader.getInstance().getModContainer("hhggk").orElse(null);
            if (container == null) return;
            Set<Class<?>> have = new HashSet<>();
            for (Module m : modules) have.add(m.getClass());
            String pkg = "com.example.hhggk.module.";
            for (Path root : container.getRootPaths()) {
                Path base = root.resolve("com/example/hhggk/module");
                if (!Files.isDirectory(base)) continue;
                try (var walk = Files.walk(base)) {
                    for (Path p : (Iterable<Path>) walk.sorted()::iterator) {
                        String rel = base.relativize(p).toString().replace('\\', '/');
                        if (!rel.endsWith(".class") || rel.contains("$") || !rel.contains("/")) continue;
                        String cn = pkg + rel.substring(0, rel.length() - 6).replace('/', '.');
                        try {
                            Class<?> c = Class.forName(cn, true, ModuleManager.class.getClassLoader());
                            if (!Module.class.isAssignableFrom(c) || Modifier.isAbstract(c.getModifiers())
                                    || have.contains(c)) continue;
                            Module m = (Module) c.getDeclaredConstructor().newInstance();
                            modules.add(m);
                            have.add(c);
                        } catch (Throwable t) {
                            System.err.println("[Diamond] could not load module " + cn + ": " + t);
                        }
                    }
                }
            }
        } catch (Throwable t) {
            System.err.println("[Diamond] module discovery failed: " + t);
        }
    }

    private static void crash(MinecraftClient mc, Module m, Throwable t) {
        m.enabled = false;
        try { m.onDisable(); } catch (Throwable ignored) {}
        t.printStackTrace();
        if (mc.player != null) {
            mc.player.sendMessage(Text.literal("[Diamond] " + m.name + " error, disabled: " + t), false);
        }
    }

    public static void tick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null) {
            for (Module m : modules) {
                if (m.enabled && (m == freecam || m == fakePlayer)) {
                    m.enabled = false;
                    try { m.onDisable(); } catch (Throwable ignored) {}
                }
            }
            return;
        }
        if (!Settings.active()) {
            for (Module m : modules) {
                if (m.enabled) {
                    try { m.toggle(); } catch (Throwable ignored) { m.enabled = false; }
                }
            }
            return;
        }
        try { Stats.tick(mc); } catch (Throwable ignored) {}
        for (Module m : modules) {
            if (!m.enabled) continue;
            try { m.onTick(mc); } catch (Throwable t) { crash(mc, m, t); }
        }
    }

    public static void renderHud(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.options.hudHidden) return;
        for (Module m : modules) {
            if (!m.enabled) continue;
            try { m.onHud(ctx, mc); } catch (Throwable t) { crash(mc, m, t); }
        }
    }
}
