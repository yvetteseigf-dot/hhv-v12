package com.example.hhggk.module.movement;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

public class Spider extends Module {
    public final Setting.Num speed = add(new Setting.Num("Climb speed", 0.2, 0.05, 0.6, 0.05));

    public Spider() { super("Spider", Category.MOVEMENT); }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (mc.currentScreen != null) return;
        if (p.horizontalCollision && !mc.options.sneakKey.isPressed()) {
            Vec3d v = p.getVelocity();
            p.setVelocity(v.x, speed.value, v.z);
        }
    }
}
