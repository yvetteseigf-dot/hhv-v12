package com.example.hhggk.module.combat;

import com.example.hhggk.module.BlockUtil;
import com.example.hhggk.module.Inv;
import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

/** Keeps obsidian around your feet (stops crystal damage from the sides). Re-places broken blocks. */
public class Surround extends Module {
    public final Setting.Num perTick = add(new Setting.Num("Blocks per tick", 2, 1, 4, 1));
    public final Setting.Bool enderChest = add(new Setting.Bool("Use ender chests too", true));
    public final Setting.Bool disableOnJump = add(new Setting.Bool("Disable when you move up", true));

    private double startY = Double.NaN;

    public Surround() { super("Surround", Category.COMBAT); }

    @Override public void onEnable() { startY = Double.NaN; }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (Double.isNaN(startY)) startY = p.getY();
        if (disableOnJump.value && p.getY() > startY + 0.6) { enabled = false; return; }
        if (!p.isOnGround()) return;
        int slot = Inv.hotbar(p, Items.OBSIDIAN);
        if (slot < 0 && enderChest.value) slot = Inv.hotbar(p, Items.ENDER_CHEST);
        if (slot < 0) return;
        BlockPos feet = BlockPos.ofFloored(p.getX(), p.getY() + 0.1, p.getZ());
        int n = 0;
        for (Direction d : BlockUtil.SIDES) {
            if (n >= (int) perTick.value) break;
            if (BlockUtil.place(mc, feet.offset(d), slot)) n++;
        }
    }
}
