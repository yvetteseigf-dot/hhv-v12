package com.example.hhggk.module.misc;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;

/** Runs extra player ticks: faster movement and faster attack cooldown. */
public class Timer extends Module {
    public final Setting.Num speed = add(new Setting.Num("Multiplier", 1.5, 1.0, 5.0, 0.1));
    private double acc;

    public Timer() { super("Timer", Category.MISC); }

    @Override
    public void onTick(MinecraftClient mc) {
        if (mc.currentScreen != null) return;
        acc += speed.value - 1.0;
        int n = 0;
        while (acc >= 1.0 && n < 4) {
            mc.player.tick();
            acc -= 1.0;
            n++;
        }
        if (acc > 4) acc = 0;
    }

    @Override
    public void onDisable() { acc = 0; }
}
