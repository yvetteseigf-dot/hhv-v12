package com.example.hhggk.render;

import com.example.hhggk.Settings;
import com.example.hhggk.module.Drawable3D;
import com.example.hhggk.module.Module;
import com.example.hhggk.module.ModuleManager;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.VertexRendering;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

/** Draws every enabled module that implements Drawable3D (HoleESP, StorageESP, Trajectories...). */
public class Overlay3D {
    public static void outline(MatrixStack ms, VertexConsumerProvider v, Box b, float r, float g, float bl, float a) {
        VertexRendering.drawBox(ms, v.getBuffer(RenderLayer.getLines()), b, r, g, bl, a);
    }

    public static void filled(MatrixStack ms, VertexConsumerProvider v, Box b, float r, float g, float bl, float a) {
        VertexRendering.drawFilledBox(ms, v.getBuffer(RenderLayer.getDebugFilledBox()),
                b.minX, b.minY, b.minZ, b.maxX, b.maxY, b.maxZ, r, g, bl, a);
    }

    public static void render(WorldRenderContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || !Settings.active()) return;
        MatrixStack ms = ctx.matrixStack();
        VertexConsumerProvider vcp = ctx.consumers();
        if (ms == null || vcp == null) return;
        Vec3d cam = ctx.camera().getPos();
        float td = ctx.tickCounter().getTickDelta(false);

        boolean any = false;
        ms.push();
        ms.translate(-cam.x, -cam.y, -cam.z);
        try {
            for (Module m : ModuleManager.modules) {
                if (!m.enabled || !(m instanceof Drawable3D d)) continue;
                try { d.draw3d(mc, ms, vcp, cam, td); any = true; } catch (Throwable t) { m.enabled = false; t.printStackTrace(); }
            }
        } finally {
            ms.pop();
        }
        if (any && vcp instanceof VertexConsumerProvider.Immediate imm) {
            imm.draw(RenderLayer.getDebugFilledBox());
            imm.draw(RenderLayer.getLines());
        }
    }
}
