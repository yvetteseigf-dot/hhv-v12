package com.example.hhggk;

import com.example.hhggk.module.ModuleManager;
import com.example.hhggk.render.Overlay3D;
import com.example.hhggk.render.WorldRender;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class HhggkClient implements ClientModInitializer {
    private static KeyBinding menuKey;

    @Override
    public void onInitializeClient() {
        Settings.reload();
        Friends.load();
        ModuleManager.init();
        Binds.load();
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.hhggk.open", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_P, "category.hhggk"));

        HudRenderCallback.EVENT.register((ctx, tickCounter) -> ModuleManager.renderHud(ctx));
        WorldRenderEvents.AFTER_TRANSLUCENT.register(WorldRender::render);
        WorldRenderEvents.AFTER_TRANSLUCENT.register(Overlay3D::render);

        // ".cfg", ".friend", ".toggle", ".help" typed in chat are handled here and never sent
        ClientSendMessageEvents.ALLOW_CHAT.register(msg -> !Commands.handle(msg));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            // replace the vanilla main menu with the LuxeDLC one
            if (client.currentScreen instanceof TitleScreen) client.setScreen(new LuxeTitleScreen());
            while (menuKey.wasPressed()) {
                if (client.currentScreen == null) client.setScreen(new ClickGui());
            }
            Binds.tick(client);
            ModuleManager.tick(client);
        });
    }
}
