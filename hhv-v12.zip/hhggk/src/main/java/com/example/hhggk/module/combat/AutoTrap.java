package com.example.hhggk.module.combat;

import com.example.hhggk.module.BlockUtil;
import com.example.hhggk.module.EntityFilter;
import com.example.hhggk.module.Inv;
import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

import java.util.ArrayList;
import java.util.List;

/**
 * Boxes the closest enemy in with the block YOU choose (click the Block setting = list of every block).
 *
 *  Server: "No protection"   -> fast, several blocks per tick, no checks (for HvH servers without anticheat)
 *          "With protection" -> looks like a real player: aims at the block, visible face only, reach limit,
 *                               1 block per delay (for servers that have an anticheat)
 */
public class AutoTrap extends Module {
    public final Setting.Mode server = add(new Setting.Mode("Server", "No protection", "With protection"));
    public final Setting.BlockPick block = add(new Setting.BlockPick("Block", "minecraft:obsidian"));
    public final Setting.Mode shape = add(new Setting.Mode("Shape",
            "Full", "Sides", "Feet ring", "Head ring + top", "Full + floor", "Cage", "Double top"));
    public final Setting.Mode targetMode = add(new Setting.Mode("Target", "Closest", "Lowest health"));
    public final Setting.Num range = add(new Setting.Num("Range", 4.5, 2, 6, 0.1));
    public final Setting.Num perTick = add(new Setting.Num("Blocks per tick (no prot.)", 2, 1, 6, 1));
    public final Setting.Num delay = add(new Setting.Num("Delay ticks (protected)", 2, 1, 10, 1));
    public final Setting.Num reach = add(new Setting.Num("Reach (protected)", 4.0, 3.0, 4.5, 0.1));
    public final Setting.Bool rotate = add(new Setting.Bool("Rotate (protected)", true));
    public final Setting.Bool jitter = add(new Setting.Bool("Random aim (protected)", true));
    public final Setting.Bool pull = add(new Setting.Bool("Take from inventory", true));
    public final Setting.Bool autoOff = add(new Setting.Bool("Disable when done", false));

    private int cd, pullCd;

    public AutoTrap() { super("AutoTrap", Category.COMBAT); }

    @Override
    public void onEnable() { cd = 0; pullCd = 0; }

    /** Blocks to place around the target, bottom to top (so every block has something to stand on). */
    private List<BlockPos> plan(BlockPos feet) {
        String s = shape.get();
        boolean floor = s.equals("Full + floor");
        boolean feetRing = !s.equals("Head ring + top");
        boolean headRing = !s.equals("Feet ring");
        boolean top = s.equals("Full") || s.equals("Head ring + top") || s.equals("Full + floor")
                || s.equals("Cage") || s.equals("Double top");
        boolean top2 = s.equals("Double top");
        boolean diag = s.equals("Cage");

        List<BlockPos> l = new ArrayList<>();
        if (floor) l.add(feet.down());
        if (feetRing) for (Direction d : BlockUtil.SIDES) l.add(feet.offset(d));
        if (diag) {
            l.add(feet.add(1, 0, 1)); l.add(feet.add(1, 0, -1));
            l.add(feet.add(-1, 0, 1)); l.add(feet.add(-1, 0, -1));
        }
        if (headRing) for (Direction d : BlockUtil.SIDES) l.add(feet.up().offset(d));
        if (diag) {
            l.add(feet.add(1, 1, 1)); l.add(feet.add(1, 1, -1));
            l.add(feet.add(-1, 1, 1)); l.add(feet.add(-1, 1, -1));
        }
        if (top) l.add(feet.up(2));
        if (top2) l.add(feet.up(3));
        return l;
    }

    private PlayerEntity pickTarget(MinecraftClient mc, ClientPlayerEntity p) {
        PlayerEntity t = null;
        double best = Double.MAX_VALUE;
        double max = range.value * range.value;
        boolean lowest = targetMode.is("Lowest health");
        for (PlayerEntity e : mc.world.getPlayers()) {
            if (EntityFilter.kind(e, p) != 0 || !e.isAlive()) continue;
            double d = p.squaredDistanceTo(e);
            if (d > max) continue;
            double score = lowest ? e.getHealth() : d;
            if (score < best) { best = score; t = e; }
        }
        return t;
    }

    /** Hotbar slot with the chosen block; if it is only in the inventory, moves it to the hotbar (next tick it is usable). */
    private int findSlot(MinecraftClient mc, ClientPlayerEntity p, Item item) {
        int s = Inv.hotbar(p, i -> i.isOf(item));
        if (s >= 0 || !pull.value) return s;
        if (pullCd > 0) return -1;
        for (int i = 9; i < 36; i++) {
            if (!p.getInventory().getStack(i).isOf(item)) continue;
            int target = p.getInventory().selectedSlot;
            for (int h = 0; h < 9; h++) {
                if (p.getInventory().getStack(h).isEmpty()) { target = h; break; }
            }
            Inv.swapSlots(mc, p, Inv.container(i), Inv.container(target));
            pullCd = 5;
            break;
        }
        return -1;
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (cd > 0) cd--;
        if (pullCd > 0) pullCd--;
        if (mc.currentScreen != null) return;

        Item item = block.item();
        int slot = findSlot(mc, p, item);
        if (slot < 0) return;

        PlayerEntity t = pickTarget(mc, p);
        if (t == null) return;

        BlockPos feet = BlockPos.ofFloored(t.getX(), t.getY() + 0.1, t.getZ());
        List<BlockPos> plan = plan(feet);

        boolean protectedMode = server.is("With protection");
        int max = protectedMode ? 1 : (int) perTick.value;
        if (protectedMode && cd > 0) return;

        int placed = 0;
        boolean missing = false;
        for (BlockPos pos : plan) {
            if (!mc.world.getBlockState(pos).isReplaceable()) continue;   // already filled
            missing = true;
            if (placed >= max) break;
            boolean ok = protectedMode
                    ? BlockUtil.placeStrict(mc, pos, slot, reach.value, rotate.value, jitter.value)
                    : BlockUtil.place(mc, pos, slot);
            if (ok) placed++;
        }
        if (placed > 0 && protectedMode) cd = (int) delay.value;

        if (!missing && autoOff.value) {
            p.sendMessage(Text.literal("[Diamond] AutoTrap: " + t.getName().getString() + " is trapped"), true);
            toggle();
        }
    }
}
