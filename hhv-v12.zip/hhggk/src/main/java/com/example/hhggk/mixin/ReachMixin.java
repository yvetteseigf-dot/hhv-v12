package com.example.hhggk.mixin;

import com.example.hhggk.Settings;
import com.example.hhggk.module.ModuleManager;
import com.example.hhggk.module.combat.Reach;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(PlayerEntity.class)
public class ReachMixin {
    @Inject(method = "getEntityInteractionRange", at = @At("HEAD"), cancellable = true)
    private void hhggk$reach(CallbackInfoReturnable<Double> cir) {
        Reach r = ModuleManager.reach;
        if (r != null && r.enabled && (Object) this == MinecraftClient.getInstance().player && Settings.active()) {
            cir.setReturnValue(r.reach.value);
        }
    }
}
