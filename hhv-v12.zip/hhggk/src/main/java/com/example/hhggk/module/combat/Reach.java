package com.example.hhggk.module.combat;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

/**
 * Longer attack reach (client side, applied in ReachMixin).
 * The server still checks distance itself, so very large values only help on servers that allow it.
 */
public class Reach extends Module {
    public final Setting.Num reach = add(new Setting.Num("Entity reach", 3.5, 3.0, 6.0, 0.1));

    public Reach() { super("Reach", Category.COMBAT); }
}
