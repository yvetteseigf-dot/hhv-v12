package com.example.hhggk.module.movement;

import com.example.hhggk.module.EntityFilter;
import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.math.Vec3d;

/**
 * Teleports you to the nearest player and keeps doing it (spam) while it is on.
 * ONLY for HvH servers without movement protection (vanilla "moved too quickly" / anticheats will rubber-band you).
 *
 *  Method "Packet":  walks the distance with position packets (max "Blocks per packet" each) and moves you there.
 *  Method "Command": sends  /tp <name>  (needs permission on that server).
 */
public class TpNearest extends Module {
    public final Setting.Mode method = add(new Setting.Mode("Method", "Packet", "Command"));
    public final Setting.Num range = add(new Setting.Num("Max range", 60, 5, 150, 5));
    public final Setting.Num delay = add(new Setting.Num("Delay (ticks)", 2, 1, 40, 1));
    public final Setting.Num stay = add(new Setting.Num("Stay distance", 1.5, 0, 6, 0.5));
    public final Setting.Num perPacket = add(new Setting.Num("Blocks per packet", 8, 2, 10, 1));
    public final Setting.Bool sync = add(new Setting.Bool("Move client too", true));

    private int cd;

    public TpNearest() { super("TpNearest", Category.MOVEMENT); }

    @Override
    public void onEnable() { cd = 0; }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (mc.getNetworkHandler() == null || !p.isAlive()) return;
        if (cd > 0) { cd--; return; }

        PlayerEntity t = null;
        double best = range.value * range.value;
        for (PlayerEntity e : mc.world.getPlayers()) {
            if (EntityFilter.kind(e, p) != 0 || !e.isAlive()) continue;
            double d = p.squaredDistanceTo(e);
            if (d <= best) { best = d; t = e; }
        }
        if (t == null) return;
        if (Math.sqrt(best) <= stay.value + 0.5) return;     // already next to them
        cd = (int) delay.value - 1;

        if (method.is("Command")) {
            mc.getNetworkHandler().sendChatCommand("tp " + t.getName().getString());
            return;
        }

        Vec3d from = p.getPos();
        Vec3d to = t.getPos();
        Vec3d dir = to.subtract(from);
        double len = dir.length();
        if (len < 0.01) return;
        double go = Math.max(0, len - stay.value);
        Vec3d dest = from.add(dir.multiply(go / len));

        int n = Math.max(1, (int) Math.ceil(go / perPacket.value));
        for (int i = 1; i <= n; i++) {
            Vec3d pt = from.lerp(dest, (double) i / n);
            mc.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(pt.x, pt.y, pt.z, false, false));
        }
        if (sync.value) p.setPosition(dest.x, dest.y, dest.z);
    }
}
