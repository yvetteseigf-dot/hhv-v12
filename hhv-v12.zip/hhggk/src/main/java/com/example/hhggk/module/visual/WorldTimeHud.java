package com.example.hhggk.module.visual;

import com.example.hhggk.module.HudText;

import net.minecraft.client.MinecraftClient;


public class WorldTimeHud extends HudText {

    public WorldTimeHud() { super("WorldTimeHud", Category.VISUAL, 100, 4); }

    @Override
    protected String text(MinecraftClient mc) {
        long t = mc.world.getTimeOfDay();
        long day = t / 24000L, tod = t % 24000L;
        int hh = (int) ((tod / 1000L + 6L) % 24L), mm = (int) ((tod % 1000L) * 60L / 1000L);
        return String.format("Day %d  %02d:%02d", day, hh, mm);
    }
}
