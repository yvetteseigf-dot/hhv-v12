package com.example.hhggk.module;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import net.minecraft.block.Block;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public abstract class Setting {
    public final String name;
    protected Setting(String name) { this.name = name; }

    public abstract JsonElement toJson();
    public abstract void fromJson(JsonElement e);

    public static class Bool extends Setting {
        public boolean value;
        public Bool(String name, boolean value) { super(name); this.value = value; }
        @Override public JsonElement toJson() { return new JsonPrimitive(value); }
        @Override public void fromJson(JsonElement e) { if (e.isJsonPrimitive()) value = e.getAsBoolean(); }
    }

    public static class Num extends Setting {
        public double value, min, max, step;
        public Num(String name, double value, double min, double max, double step) {
            super(name); this.value = value; this.min = min; this.max = max; this.step = step;
        }
        public void set(double v) {
            value = Math.max(min, Math.min(max, Math.round(v / step) * step));
        }
        public void add(double d) { set(value + d); }
        public String text() {
            if (step >= 1) return String.valueOf((int) Math.round(value));
            if (step >= 0.1) return String.format("%.1f", value);
            return String.format("%.2f", value);
        }
        @Override public JsonElement toJson() { return new JsonPrimitive(value); }
        @Override public void fromJson(JsonElement e) { if (e.isJsonPrimitive()) set(e.getAsDouble()); }
    }

    public static class Mode extends Setting {
        public final String[] modes;
        public int index;
        public Mode(String name, String... modes) { super(name); this.modes = modes; }
        public String get() { return modes[index]; }
        public boolean is(String s) { return modes[index].equals(s); }
        public void next() { index = (index + 1) % modes.length; }
        public void prev() { index = (index - 1 + modes.length) % modes.length; }
        @Override public JsonElement toJson() { return new JsonPrimitive(get()); }
        @Override public void fromJson(JsonElement e) {
            if (!e.isJsonPrimitive()) return;
            String s = e.getAsString();
            for (int i = 0; i < modes.length; i++) if (modes[i].equals(s)) index = i;
        }
    }

    /** A block chosen from the full block list (opens BlockPickerScreen from the menu). */
    public static class BlockPick extends Setting {
        public String id;
        public BlockPick(String name, String id) { super(name); this.id = id; }

        public Block block() {
            Identifier i = Identifier.tryParse(id);
            return i == null ? net.minecraft.block.Blocks.OBSIDIAN : Registries.BLOCK.get(i);
        }

        public Item item() {
            Item it = block().asItem();
            return it == null ? Items.AIR : it;
        }

        public Text label() { return block().getName(); }

        public void set(Block b) { id = Registries.BLOCK.getId(b).toString(); }

        @Override public JsonElement toJson() { return new JsonPrimitive(id); }
        @Override public void fromJson(JsonElement e) {
            if (!e.isJsonPrimitive()) return;
            String v = e.getAsString();
            Identifier i = Identifier.tryParse(v);
            if (i != null && Registries.BLOCK.containsId(i)) id = i.toString();
        }
    }
}
