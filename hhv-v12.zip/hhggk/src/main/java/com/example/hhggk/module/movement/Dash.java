package com.example.hhggk.module.movement;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

/** Press V to dash forward. */
public class Dash extends Module {
    public final Setting.Num power = add(new Setting.Num("Power", 1.2, 0.3, 3.0, 0.1));
    public final Setting.Num cooldown = add(new Setting.Num("Cooldown (ticks)", 20, 5, 100, 5));
    private int cd;
    private boolean was;

    public Dash() { super("Dash", Category.MOVEMENT); }

    @Override
    public void onTick(MinecraftClient mc) {
        if (cd > 0) cd--;
        boolean down = mc.currentScreen == null
                && InputUtil.isKeyPressed(mc.getWindow().getHandle(), GLFW.GLFW_KEY_V);
        if (down && !was && cd == 0) {
            double yaw = Math.toRadians(mc.player.getYaw());
            Vec3d v = mc.player.getVelocity();
            mc.player.setVelocity(-Math.sin(yaw) * power.value, v.y, Math.cos(yaw) * power.value);
            cd = (int) cooldown.value;
        }
        was = down;
    }
}
