package com.example.hhggk.module.misc;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;

/** Warns in the action bar (and with a sound) when armor or your held item is almost broken. */
public class DurabilityAlert extends Module {
    public final Setting.Num percent = add(new Setting.Num("Warn below %", 15, 5, 50, 5));
    public final Setting.Bool sound = add(new Setting.Bool("Sound", true));

    private long last;

    public DurabilityAlert() { super("DurabilityAlert", Category.MISC); }

    @Override
    public void onTick(MinecraftClient mc) {
        if (System.currentTimeMillis() - last < 8000) return;
        String[] names = {"Helmet", "Chestplate", "Leggings", "Boots"};
        for (int i = 0; i < 5; i++) {
            ItemStack s = i < 4 ? mc.player.playerScreenHandler.getSlot(5 + i).getStack() : mc.player.getMainHandStack();
            if (s.isEmpty() || !s.isDamageable() || s.getMaxDamage() <= 0) continue;
            double left = 100.0 * (s.getMaxDamage() - s.getDamage()) / s.getMaxDamage();
            if (left > percent.value) continue;
            last = System.currentTimeMillis();
            String what = i < 4 ? names[i] : "Held item";
            mc.player.sendMessage(Text.literal(String.format("[Diamond] %s durability %.0f%%", what, left)), true);
            if (sound.value) mc.player.playSound(net.minecraft.sound.SoundEvents.BLOCK_ANVIL_LAND, 0.5f, 1.2f);
            return;
        }
    }
}
