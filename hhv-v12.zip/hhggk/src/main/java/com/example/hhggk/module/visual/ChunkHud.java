package com.example.hhggk.module.visual;

import com.example.hhggk.module.HudText;

import net.minecraft.client.MinecraftClient;


public class ChunkHud extends HudText {

    public ChunkHud() { super("ChunkHud", Category.VISUAL, 0, 66); }

    @Override
    protected String text(MinecraftClient mc) {
        return "Chunk " + (mc.player.getBlockX() >> 4) + ", " + (mc.player.getBlockZ() >> 4);
    }
}
