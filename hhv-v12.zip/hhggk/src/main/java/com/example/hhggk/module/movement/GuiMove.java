package com.example.hhggk.module.movement;

import com.example.hhggk.module.Module;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.AnvilScreen;
import net.minecraft.client.gui.screen.ingame.CreativeInventoryScreen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;

/** Keep walking / jumping / sprinting while an inventory or chest screen is open. */
public class GuiMove extends Module {
    public GuiMove() { super("GuiMove", Category.MOVEMENT); }

    @Override
    public void onTick(MinecraftClient mc) {
        if (!(mc.currentScreen instanceof HandledScreen<?>)) return;
        if (mc.currentScreen instanceof AnvilScreen || mc.currentScreen instanceof CreativeInventoryScreen) return;
        KeyBinding[] keys = {mc.options.forwardKey, mc.options.backKey, mc.options.leftKey, mc.options.rightKey,
                mc.options.jumpKey, mc.options.sprintKey};
        long win = mc.getWindow().getHandle();
        for (KeyBinding k : keys) {
            int code = KeyBindingHelper.getBoundKeyOf(k).getCode();
            k.setPressed(InputUtil.isKeyPressed(win, code));
        }
    }
}
