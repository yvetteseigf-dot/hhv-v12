package com.example.hhggk.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/** Base for simple text HUD modules. Every one has its own X / Y position (in % of the screen). */
public abstract class HudText extends Module {
    public final Setting.Bool background = add(new Setting.Bool("Background", true));
    public final Setting.Num posX;
    public final Setting.Num posY;

    protected HudText(String name, Category c, double x, double y) {
        super(name, c);
        posX = add(new Setting.Num("Position X %", x, 0, 100, 1));
        posY = add(new Setting.Num("Position Y %", y, 0, 100, 1));
    }

    /** Text to show; use \n for several lines; empty = draw nothing. */
    protected abstract String text(MinecraftClient mc);

    protected int color(MinecraftClient mc) { return 0xFFFFFFFF; }

    @Override
    public void onHud(DrawContext ctx, MinecraftClient mc) {
        String s = text(mc);
        if (s == null || s.isEmpty()) return;
        String[] lines = s.split("\n");
        int w = 0;
        for (String l : lines) w = Math.max(w, mc.textRenderer.getWidth(l));
        int h = lines.length * 10;
        int x = (int) ((ctx.getScaledWindowWidth() - w - 8) * posX.value / 100.0) + 4;
        int y = (int) ((ctx.getScaledWindowHeight() - h - 4) * posY.value / 100.0) + 2;
        if (background.value) ctx.fill(x - 3, y - 2, x + w + 3, y + h, 0xA0101018);
        int col = color(mc);
        for (int i = 0; i < lines.length; i++) {
            ctx.drawTextWithShadow(mc.textRenderer, lines[i], x, y + i * 10, col);
        }
    }
}
