package com.example.hhggk.module.combat;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

public class AutoTotem extends Module {
    public final Setting.Bool lowOnly = add(new Setting.Bool("Only when low health", false));
    public final Setting.Num health = add(new Setting.Num("Health (half hearts)", 10, 2, 20, 1));

    private int cd;

    public AutoTotem() { super("AutoTotem", Category.COMBAT); }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (cd-- > 0 || mc.interactionManager == null) return;
        if (p.currentScreenHandler != p.playerScreenHandler) return;
        if (p.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) return;
        if (lowOnly.value && p.getHealth() > health.value) return;

        for (int i = 0; i < 36; i++) {
            if (p.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) {
                int slot = i < 9 ? 36 + i : i;
                mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, slot, 40, SlotActionType.SWAP, p);
                cd = 4;
                return;
            }
        }
    }
}
