package com.example.hhggk.module.movement;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

/** Hold sneak in the air to stop falling. */
public class Hover extends Module {

    public Hover() { super("Hover", Category.MOVEMENT); }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (mc.currentScreen != null || !mc.options.sneakKey.isPressed()) return;
        if (p.isOnGround() || p.isGliding() || p.isTouchingWater() || p.getAbilities().flying) return;
        Vec3d v = p.getVelocity();
        p.setVelocity(v.x, 0.0, v.z);
        p.fallDistance = 0;
    }
}
