package com.example.hhggk.module.visual;

import com.example.hhggk.module.BlockUtil;
import com.example.hhggk.module.Drawable3D;
import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;
import com.example.hhggk.render.Overlay3D;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

/** Marks safe holes: green = all bedrock, orange = obsidian / mixed. */
public class HoleESP extends Module implements Drawable3D {
    public final Setting.Num range = add(new Setting.Num("Range", 8, 3, 16, 1));

    private final List<BlockPos> bedrock = new ArrayList<>();
    private final List<BlockPos> obsidian = new ArrayList<>();
    private int cd;

    public HoleESP() { super("HoleESP", Category.VISUAL); }

    @Override
    public void onTick(MinecraftClient mc) {
        if (cd-- > 0) return;
        cd = 10;
        bedrock.clear(); obsidian.clear();
        int r = (int) range.value;
        BlockPos me = mc.player.getBlockPos();
        for (int dx = -r; dx <= r; dx++) for (int dy = -4; dy <= 3; dy++) for (int dz = -r; dz <= r; dz++) {
            BlockPos pos = me.add(dx, dy, dz);
            if (!BlockUtil.isHole(mc, pos)) continue;
            if (BlockUtil.isBedrockHole(mc, pos)) bedrock.add(pos); else obsidian.add(pos);
        }
    }

    @Override
    public void draw3d(MinecraftClient mc, MatrixStack ms, VertexConsumerProvider vcp, Vec3d cam, float td) {
        for (BlockPos b : bedrock) box(ms, vcp, b, 0.2f, 1f, 0.35f);
        for (BlockPos b : obsidian) box(ms, vcp, b, 1f, 0.6f, 0.15f);
    }

    private static void box(MatrixStack ms, VertexConsumerProvider vcp, BlockPos b, float r, float g, float bl) {
        Box bx = new Box(b.getX() + 0.05, b.getY(), b.getZ() + 0.05, b.getX() + 0.95, b.getY() + 0.06, b.getZ() + 0.95);
        Overlay3D.filled(ms, vcp, bx, r, g, bl, 0.45f);
        Overlay3D.outline(ms, vcp, bx, r, g, bl, 1f);
    }
}
