package com.example.hhggk.module.render;

import com.example.hhggk.module.Module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;

public class ArmorHud extends Module {
    public ArmorHud() { super("ArmorHUD", Category.RENDER); }

    @Override
    public void onHud(DrawContext ctx, MinecraftClient mc) {
        EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
        int x0 = ctx.getScaledWindowWidth() / 2 - 40;
        int y = ctx.getScaledWindowHeight() - 78;
        for (int i = 0; i < slots.length; i++) {
            ItemStack st = mc.player.getEquippedStack(slots[i]);
            if (st.isEmpty()) continue;
            int x = x0 + i * 20;
            ctx.drawItem(st, x, y);
            if (st.getMaxDamage() > 0) {
                int left = st.getMaxDamage() - st.getDamage();
                int color = left * 4 < st.getMaxDamage() ? 0xFFFF5555 : 0xFFFFFFFF;
                ctx.drawTextWithShadow(mc.textRenderer, String.valueOf(left), x, y + 17, color);
            }
        }
    }
}
