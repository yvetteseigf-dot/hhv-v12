package com.example.hhggk.module.visual;

import com.example.hhggk.module.Fx;
import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;
import com.example.hhggk.module.Stats;

import net.minecraft.client.MinecraftClient;

import java.util.concurrent.ThreadLocalRandom;

/** Particle explosion where your target dies. */
public class KillEffect extends Module {
    public final Setting.Mode particle = add(new Setting.Mode("Particle", "Totem", "Flame", "Soul flame", "End rod", "Crit", "Enchant"));
    public final Setting.Num amount = add(new Setting.Num("Amount", 40, 10, 150, 5));

    public KillEffect() { super("KillEffect", Category.VISUAL); }

    @Override
    public void onTick(MinecraftClient mc) {
        if (!Stats.killPending) return;
        Stats.killPending = false;
        ThreadLocalRandom r = ThreadLocalRandom.current();
        var eff = Fx.particle(particle.get());
        for (int i = 0; i < (int) amount.value; i++) {
            Fx.add(mc, eff, Stats.killPos.x, Stats.killPos.y + 0.9, Stats.killPos.z,
                    (r.nextDouble() - 0.5) * 0.7, (r.nextDouble() - 0.2) * 0.6, (r.nextDouble() - 0.5) * 0.7);
        }
    }
}
