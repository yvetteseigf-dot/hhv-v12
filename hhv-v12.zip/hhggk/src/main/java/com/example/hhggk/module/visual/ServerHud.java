package com.example.hhggk.module.visual;

import com.example.hhggk.module.HudText;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ServerInfo;

public class ServerHud extends HudText {

    public ServerHud() { super("ServerHud", Category.VISUAL, 0, 42); }

    @Override
    protected String text(MinecraftClient mc) {
        ServerInfo si = mc.getCurrentServerEntry();
        return si == null ? "Singleplayer" : si.address;
    }
}
