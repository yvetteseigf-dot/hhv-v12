package com.example.hhggk.module.render;

import com.example.hhggk.module.HudText;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.text.Text;

public class EffectHud extends HudText {

    public EffectHud() { super("EffectHud", Category.RENDER, 100, 25); }

    @Override
    protected String text(MinecraftClient mc) {
        StringBuilder sb = new StringBuilder();
        for (StatusEffectInstance e : mc.player.getStatusEffects()) {
            if (sb.length() > 0) sb.append('\n');
            int sec = e.getDuration() / 20;
            sb.append(Text.translatable(e.getTranslationKey()).getString()).append(' ').append(e.getAmplifier() + 1)
              .append("  ").append(String.format("%d:%02d", sec / 60, sec % 60));
        }
        return sb.toString();
    }
}
