package com.example.hhggk.module.combat;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.ModuleManager;
import com.example.hhggk.module.Setting;
import com.example.hhggk.module.misc.FakePlayer;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.player.PlayerEntity;

/** Combat modules ignore "players" that are not in the tab list (NPCs / bots). */
public class AntiBot extends Module {
    public final Setting.Bool ping0 = add(new Setting.Bool("Ignore ping 0", false));

    public AntiBot() { super("AntiBot", Category.COMBAT); }

    public static boolean isBot(PlayerEntity pe) {
        AntiBot ab = ModuleManager.antiBot;
        if (ab == null || !ab.enabled || pe == FakePlayer.fake) return false;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.getNetworkHandler() == null) return false;
        PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(pe.getUuid());
        if (e == null) return true;
        return ab.ping0.value && e.getLatency() == 0;
    }
}
