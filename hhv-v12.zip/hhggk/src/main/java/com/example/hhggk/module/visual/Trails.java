package com.example.hhggk.module.visual;

import com.example.hhggk.module.Fx;
import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;

import java.util.concurrent.ThreadLocalRandom;

/** Particle trail behind you while you move. */
public class Trails extends Module {
    public final Setting.Mode particle = add(new Setting.Mode("Particle", Fx.PARTICLES));
    public final Setting.Num amount = add(new Setting.Num("Amount", 3, 1, 15, 1));

    public Trails() { super("Trails", Category.VISUAL); }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        double dx = p.getX() - p.prevX, dy = p.getY() - p.prevY, dz = p.getZ() - p.prevZ;
        if (dx * dx + dy * dy + dz * dz < 1.0E-4) return;
        ThreadLocalRandom r = ThreadLocalRandom.current();
        var eff = Fx.particle(particle.get());
        for (int i = 0; i < (int) amount.value; i++) {
            double t = r.nextDouble();
            Fx.add(mc, eff, p.prevX + dx * t + (r.nextDouble() - 0.5) * 0.4,
                    p.prevY + dy * t + 0.1 + r.nextDouble() * 0.5,
                    p.prevZ + dz * t + (r.nextDouble() - 0.5) * 0.4, 0, 0.01, 0);
        }
    }
}
