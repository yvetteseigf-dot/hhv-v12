package com.example.hhggk.module.movement;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;

/** Opens your equipped elytra automatically when you fall (handy before ElytraTarget). */
public class AutoElytra extends Module {
    public final Setting.Num minFall = add(new Setting.Num("Min fall distance", 3.0, 1.0, 20.0, 0.5));
    private int cd;

    public AutoElytra() { super("AutoElytra", Category.MOVEMENT); }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (cd-- > 0 || p.isGliding() || p.isOnGround() || p.isTouchingWater() || p.hasVehicle()) return;
        if (p.getVelocity().y > -0.1 || p.fallDistance < minFall.value || mc.getNetworkHandler() == null) return;
        ItemStack chest = p.getEquippedStack(EquipmentSlot.CHEST);
        if (!chest.isOf(Items.ELYTRA) || chest.getDamage() >= chest.getMaxDamage() - 1) return;
        mc.getNetworkHandler().sendPacket(new ClientCommandC2SPacket(p, ClientCommandC2SPacket.Mode.START_FALL_FLYING));
        cd = 10;
    }
}
