package com.example.hhggk.module.visual;

import com.example.hhggk.module.HudText;

import net.minecraft.client.MinecraftClient;


public class FoodInfo extends HudText {

    public FoodInfo() { super("FoodInfo", Category.VISUAL, 0, 36); }

    @Override
    protected String text(MinecraftClient mc) {
        return "Food " + mc.player.getHungerManager().getFoodLevel()
                + "  Sat " + String.format("%.1f", mc.player.getHungerManager().getSaturationLevel());
    }
}
