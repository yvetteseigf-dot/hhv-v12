package com.example.hhggk.module.visual;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/** XYZ coordinates (and the Nether/Overworld equivalent) above the hotbar corner. */
public class Coords extends Module {
    public final Setting.Bool dimension = add(new Setting.Bool("Other dimension", true));

    public Coords() { super("Coords", Category.VISUAL); }

    @Override
    public void onHud(DrawContext ctx, MinecraftClient mc) {
        double x = mc.player.getX(), y = mc.player.getY(), z = mc.player.getZ();
        String s = String.format("XYZ %.1f  %.1f  %.1f", x, y, z);
        if (dimension.value) {
            String key = mc.world.getRegistryKey().getValue().getPath();
            if (key.equals("the_nether")) s += String.format("  (OW %.0f, %.0f)", x * 8, z * 8);
            else if (key.equals("overworld")) s += String.format("  (Nether %.0f, %.0f)", x / 8, z / 8);
        }
        int w = mc.textRenderer.getWidth(s);
        int px = 4, py = ctx.getScaledWindowHeight() - 14;
        ctx.fill(px - 2, py - 2, px + w + 4, py + 10, 0xA0101018);
        ctx.drawTextWithShadow(mc.textRenderer, s, px + 1, py, 0xFFFFFFFF);
    }
}
