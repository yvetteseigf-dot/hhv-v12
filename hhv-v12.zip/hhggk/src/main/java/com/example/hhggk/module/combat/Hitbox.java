package com.example.hhggk.module.combat;

import com.example.hhggk.module.Setting;
import com.example.hhggk.module.TargetModule;

import net.minecraft.entity.Entity;

public class Hitbox extends TargetModule {
    /** How much every side of the target's box grows (blocks). Applied via EntityMixin. Max is now 5.0. */
    public final Setting.Num size = add(new Setting.Num("Size", 0.6, 0.0, 5.0, 0.05));
    /** Extra growth per block of distance, so far targets are still easy to hit. */
    public final Setting.Bool grow = add(new Setting.Bool("Grow with distance", true));
    public final Setting.Num growRate = add(new Setting.Num("Growth per block", 0.03, 0.0, 0.3, 0.01));
    /** Draws the REAL expanded box (box + size) around targets. */
    public final Setting.Bool show = add(new Setting.Bool("Show real box", true));

    public Hitbox() { super("Hitbox", Category.COMBAT, true, true, true, true); }

    public float margin(Entity target, Entity me) {
        double m = size.value;
        if (grow.value && me != null) m += target.distanceTo(me) * growRate.value;
        return (float) Math.min(m, 8.0);
    }
}
