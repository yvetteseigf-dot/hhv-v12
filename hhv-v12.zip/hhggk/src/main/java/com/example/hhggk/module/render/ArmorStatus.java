package com.example.hhggk.module.render;

import com.example.hhggk.module.HudText;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;

public class ArmorStatus extends HudText {

    public ArmorStatus() { super("ArmorStatus", Category.RENDER, 100, 70); }

    @Override
    protected String text(MinecraftClient mc) {
        StringBuilder sb = new StringBuilder();
        EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
        for (EquipmentSlot sl : slots) {
            ItemStack s = mc.player.getEquippedStack(sl);
            if (s.isEmpty()) continue;
            if (sb.length() > 0) sb.append('\n');
            sb.append(s.getName().getString());
            if (s.isDamageable()) sb.append("  ").append((s.getMaxDamage() - s.getDamage()) * 100 / s.getMaxDamage()).append('%');
        }
        return sb.toString();
    }
}
