package com.example.hhggk.module.visual;

import com.example.hhggk.module.Module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;

public class PingHud extends Module {
    public PingHud() { super("Ping", Category.VISUAL); }

    @Override
    public void onHud(DrawContext ctx, MinecraftClient mc) {
        if (mc.getNetworkHandler() == null) return;
        PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
        if (e == null) return;
        int ms = e.getLatency();
        int col = ms < 60 ? 0xFF55FF55 : ms < 150 ? 0xFFFFFF55 : 0xFFFF5555;
        String s = "Ping " + ms + " ms";
        int w = mc.textRenderer.getWidth(s);
        int x = ctx.getScaledWindowWidth() - w - 8, y = ctx.getScaledWindowHeight() - 14;
        ctx.fill(x - 3, y - 2, x + w + 3, y + 10, 0xA0101018);
        ctx.drawTextWithShadow(mc.textRenderer, s, x, y, col);
    }
}
