package com.example.hhggk.module.misc;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;
import com.example.hhggk.module.Stats;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;

/** Sends a chat message when you kill someone (uses the same kill detection as KillEffect). */
public class AutoEZ extends Module {
    public final Setting.Mode message = add(new Setting.Mode("Message", "gg", "ez", "good fight", "gg ez"));
    public final Setting.Bool mention = add(new Setting.Bool("Add player name", true));

    private long seenKill;
    private String lastName = "";

    public AutoEZ() { super("AutoEZ", Category.MISC); }

    @Override
    public void onEnable() { seenKill = Stats.killTime; }

    @Override
    public void onTick(MinecraftClient mc) {
        LivingEntity t = Stats.lastTarget;
        if (t != null && t != FakePlayer.fake) lastName = t.getName().getString();
        else if (t == FakePlayer.fake) lastName = "";
        if (Stats.killTime != seenKill) {
            seenKill = Stats.killTime;
            if (lastName.isEmpty() || mc.getNetworkHandler() == null || mc.isInSingleplayer()) return;
            String msg = message.get() + (mention.value ? " " + lastName : "");
            mc.getNetworkHandler().sendChatMessage(msg);
            lastName = "";
        }
    }
}
