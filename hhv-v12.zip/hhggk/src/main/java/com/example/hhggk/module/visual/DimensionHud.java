package com.example.hhggk.module.visual;

import com.example.hhggk.module.HudText;

import net.minecraft.client.MinecraftClient;


public class DimensionHud extends HudText {

    public DimensionHud() { super("DimensionHud", Category.VISUAL, 0, 78); }

    @Override
    protected String text(MinecraftClient mc) {
        return mc.world.getRegistryKey().getValue().getPath();
    }
}
