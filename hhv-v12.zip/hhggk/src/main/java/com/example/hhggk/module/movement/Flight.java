package com.example.hhggk.module.movement;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.Move;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

public class Flight extends Module {
    public final Setting.Mode mode = add(new Setting.Mode("Mode",
            "Normal", "Hover", "Jetpack", "AirJump", "Creative", "LookFly", "Bounce"));
    public final Setting.Num speed = add(new Setting.Num("Speed", 0.8, 0.1, 4.0, 0.1));
    public final Setting.Num vSpeed = add(new Setting.Num("Vertical speed", 0.5, 0.1, 3.0, 0.1));
    public final Setting.Bool noFall = add(new Setting.Bool("No fall damage", true));

    private boolean wasJump;
    private boolean wasCreative;

    public Flight() { super("Flight", Category.MOVEMENT); }

    private void restoreAbilities(ClientPlayerEntity p) {
        if (p != null && !p.isCreative() && !p.isSpectator()) {
            p.getAbilities().allowFlying = false;
            p.getAbilities().flying = false;
            p.getAbilities().setFlySpeed(0.05f);
        }
    }

    @Override
    public void onDisable() {
        if (wasCreative) restoreAbilities(MinecraftClient.getInstance().player);
        wasCreative = false;
        wasJump = false;
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (mc.currentScreen != null || p.isGliding()) return;

        boolean creative = mode.is("Creative");
        if (!creative && wasCreative) { restoreAbilities(p); wasCreative = false; }

        boolean up = mc.options.jumpKey.isPressed();
        boolean down = mc.options.sneakKey.isPressed();
        double s = speed.value, vs = vSpeed.value;
        Vec3d h = Move.horizontal(mc, s);
        Vec3d cur = p.getVelocity();
        boolean moving = h.lengthSquared() > 0;

        switch (mode.get()) {
            case "Hover" -> {
                double vy = up ? vs * 0.5 : (down ? -vs * 0.5 : 0);
                p.setVelocity(h.x * 0.6, vy, h.z * 0.6);
            }
            case "Jetpack" -> {
                double vy = up ? Math.min(cur.y + 0.12, vs * 1.5) : cur.y;
                p.setVelocity(moving ? h.x : cur.x, vy, moving ? h.z : cur.z);
            }
            case "AirJump" -> {
                double vy = (up && !wasJump) ? 0.42 : cur.y;
                wasJump = up;
                p.setVelocity(moving ? h.x : cur.x, vy, moving ? h.z : cur.z);
            }
            case "Creative" -> {
                p.getAbilities().allowFlying = true;
                p.getAbilities().flying = true;
                p.getAbilities().setFlySpeed((float) (s * 0.05));
                wasCreative = true;
            }
            case "LookFly" -> {
                Vec3d look = p.getRotationVec(1.0f);
                double f = (mc.options.forwardKey.isPressed() ? 1 : 0) - (mc.options.backKey.isPressed() ? 1 : 0);
                double sd = (mc.options.leftKey.isPressed() ? 1 : 0) - (mc.options.rightKey.isPressed() ? 1 : 0);
                double yaw = Math.toRadians(p.getYaw());
                Vec3d left = new Vec3d(Math.cos(yaw), 0, Math.sin(yaw));
                Vec3d v = look.multiply(f).add(left.multiply(sd));
                if (v.lengthSquared() > 0) v = v.normalize().multiply(s);
                p.setVelocity(v);
            }
            case "Bounce" -> {
                double vy = p.isOnGround() ? 0.42 + vs : cur.y;
                p.setVelocity(moving ? h.x : cur.x, vy, moving ? h.z : cur.z);
            }
            default -> {
                double vy = up ? vs : (down ? -vs : 0);
                p.setVelocity(h.x, vy, h.z);
            }
        }
        if (noFall.value) p.fallDistance = 0;
    }
}
