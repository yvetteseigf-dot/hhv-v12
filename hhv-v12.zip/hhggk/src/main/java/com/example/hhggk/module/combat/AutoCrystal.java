package com.example.hhggk.module.combat;

import com.example.hhggk.module.EntityFilter;
import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.Comparator;
import java.util.List;

/** Places end crystals next to the closest enemy and blows them up. Damage is estimated (no armor). */
public class AutoCrystal extends Module {
    public final Setting.Num targetRange = add(new Setting.Num("Target range", 10, 4, 16, 1));
    public final Setting.Num placeRange = add(new Setting.Num("Place range", 4.5, 2, 6, 0.1));
    public final Setting.Num breakRange = add(new Setting.Num("Break range", 4.5, 2, 6, 0.1));
    public final Setting.Num delay = add(new Setting.Num("Delay (ticks)", 2, 0, 10, 1));
    public final Setting.Num minDamage = add(new Setting.Num("Min target damage", 6, 1, 20, 1));
    public final Setting.Num maxSelf = add(new Setting.Num("Max self damage", 8, 1, 20, 1));
    public final Setting.Bool place = add(new Setting.Bool("Place", true));
    public final Setting.Bool breakIt = add(new Setting.Bool("Break", true));
    public final Setting.Bool onlyHolding = add(new Setting.Bool("Only when holding crystal", false));

    private int cd;

    public AutoCrystal() { super("AutoCrystal", Category.COMBAT); }

    /** Raw explosion damage (power 6, full exposure, no armor / resistance). */
    public static double damage(Vec3d crystal, Entity e) {
        double dist = e.getPos().add(0, e.getHeight() / 2, 0).distanceTo(crystal);
        if (dist >= 12) return 0;
        double impact = 1.0 - dist / 12.0;
        return (impact * impact + impact) / 2.0 * 7.0 * 12.0 + 1.0;
    }

    private PlayerEntity target(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        PlayerEntity best = null;
        double bd = targetRange.value * targetRange.value;
        for (PlayerEntity e : mc.world.getPlayers()) {
            if (EntityFilter.kind(e, p) != 0 || !e.isAlive()) continue;
            double d = p.squaredDistanceTo(e);
            if (d < bd) { bd = d; best = e; }
        }
        return best;
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (cd-- > 0 || mc.interactionManager == null || mc.currentScreen != null) return;
        PlayerEntity t = target(mc);
        if (t == null) return;
        boolean off = p.getOffHandStack().isOf(Items.END_CRYSTAL);
        boolean main = p.getMainHandStack().isOf(Items.END_CRYSTAL);
        if (onlyHolding.value && !off && !main) return;

        // ---- break
        if (breakIt.value) {
            double r = breakRange.value;
            List<EndCrystalEntity> list = mc.world.getEntitiesByClass(EndCrystalEntity.class,
                    p.getBoundingBox().expand(r + 1), c -> c.isAlive()
                            && EntityFilter.distSqToBox(p.getEyePos(), c.getBoundingBox()) <= r * r);
            EndCrystalEntity pick = list.stream()
                    .filter(c -> damage(c.getPos(), p) <= maxSelf.value && damage(c.getPos(), t) >= minDamage.value * 0.5)
                    .max(Comparator.comparingDouble(c -> damage(c.getPos(), t))).orElse(null);
            if (pick != null) {
                mc.interactionManager.attackEntity(p, pick);
                p.swingHand(Hand.MAIN_HAND);
                cd = (int) delay.value;
                return;
            }
        }

        // ---- place
        if (!place.value || (!off && !main && Inv_hotbar(p) < 0)) return;
        BlockPos best = null;
        double bestScore = -1e9;
        BlockPos tp = t.getBlockPos();
        double pr = placeRange.value;
        for (int dx = -4; dx <= 4; dx++) for (int dy = -3; dy <= 1; dy++) for (int dz = -4; dz <= 4; dz++) {
            BlockPos base = tp.add(dx, dy, dz);
            if (!(mc.world.getBlockState(base).isOf(Blocks.OBSIDIAN) || mc.world.getBlockState(base).isOf(Blocks.BEDROCK))) continue;
            BlockPos up = base.up();
            if (!mc.world.getBlockState(up).isAir() || !mc.world.getBlockState(up.up()).isAir()) continue;
            Vec3d top = new Vec3d(base.getX() + 0.5, base.getY() + 1, base.getZ() + 0.5);
            if (p.getEyePos().squaredDistanceTo(top) > pr * pr) continue;
            if (!mc.world.getOtherEntities(null, new Box(up.getX(), up.getY(), up.getZ(), up.getX() + 1, up.getY() + 2, up.getZ() + 1),
                    e -> e.isAlive() && !e.isSpectator() && !(e instanceof net.minecraft.entity.ItemEntity)).isEmpty()) continue;
            double td = damage(top, t), sd = damage(top, p);
            if (td < minDamage.value || sd > maxSelf.value) continue;
            double score = td - sd * 1.5;
            if (score > bestScore) { bestScore = score; best = base; }
        }
        if (best == null) return;

        Hand hand = off ? Hand.OFF_HAND : Hand.MAIN_HAND;
        int prev = p.getInventory().selectedSlot;
        if (!off && !main) p.getInventory().selectedSlot = Inv_hotbar(p);
        Vec3d hit = new Vec3d(best.getX() + 0.5, best.getY() + 1, best.getZ() + 0.5);
        mc.interactionManager.interactBlock(p, hand, new BlockHitResult(hit, Direction.UP, best, false));
        p.swingHand(hand);
        p.getInventory().selectedSlot = prev;
        cd = (int) delay.value;
    }

    private static int Inv_hotbar(ClientPlayerEntity p) {
        return com.example.hhggk.module.Inv.hotbar(p, Items.END_CRYSTAL);
    }
}
