package com.example.hhggk.module.visual;

import com.example.hhggk.module.Fx;
import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;
import com.example.hhggk.module.Stats;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;

/** Rotating particle ring at the feet of the target you are fighting. */
public class TargetCircle extends Module {
    public final Setting.Mode particle = add(new Setting.Mode("Particle", "End rod", "Flame", "Soul flame", "Crit", "Enchant", "Totem"));
    public final Setting.Num radius = add(new Setting.Num("Radius", 0.8, 0.4, 2.0, 0.1));
    private double ang;

    public TargetCircle() { super("TargetCircle", Category.VISUAL); }

    @Override
    public void onTick(MinecraftClient mc) {
        LivingEntity t = Stats.lastTarget;
        if (t == null || !t.isAlive() || System.currentTimeMillis() - Stats.lastHit > 4000) return;
        var eff = Fx.particle(particle.get());
        for (int i = 0; i < 3; i++) {
            ang += 0.45;
            Fx.add(mc, eff, t.getX() + Math.cos(ang) * radius.value, t.getY() + 0.1, t.getZ() + Math.sin(ang) * radius.value, 0, 0.005, 0);
        }
    }
}
