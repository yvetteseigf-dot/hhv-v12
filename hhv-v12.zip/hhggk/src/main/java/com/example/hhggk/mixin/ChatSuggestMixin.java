package com.example.hhggk.mixin;

import com.example.hhggk.Commands;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import net.minecraft.client.gui.screen.ChatInputSuggestor;
import net.minecraft.client.gui.widget.TextFieldWidget;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import java.util.concurrent.CompletableFuture;

/** Shows the ".cfg / .friend / ..." suggestion list when you type "." in chat. */
@Mixin(ChatInputSuggestor.class)
public abstract class ChatSuggestMixin {
    @Shadow @Final TextFieldWidget textField;
    @Shadow private CompletableFuture<Suggestions> pendingSuggestions;
    @Shadow public abstract void show(boolean narrateFirstSuggestion);

    @Inject(method = "refresh", at = @At("TAIL"))
    private void hhggk$dotCommands(CallbackInfo ci) {
        String text = textField.getText();
        if (!text.startsWith(".")) return;
        String upToCursor = text.substring(0, Math.min(text.length(), textField.getCursor()));
        List<String> list = Commands.suggest(upToCursor);
        SuggestionsBuilder b = new SuggestionsBuilder(upToCursor, upToCursor.lastIndexOf(' ') + 1);
        for (String s : list) b.suggest(s);
        pendingSuggestions = b.buildFuture();
        show(false);
    }
}
