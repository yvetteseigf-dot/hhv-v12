package com.example.hhggk.module.visual;

import com.example.hhggk.module.HudText;

import net.minecraft.client.MinecraftClient;


public class BlockUnderfoot extends HudText {

    public BlockUnderfoot() { super("BlockUnderfoot", Category.VISUAL, 100, 56); }

    @Override
    protected String text(MinecraftClient mc) {
        return mc.world.getBlockState(mc.player.getBlockPos().down()).getBlock().getName().getString();
    }
}
