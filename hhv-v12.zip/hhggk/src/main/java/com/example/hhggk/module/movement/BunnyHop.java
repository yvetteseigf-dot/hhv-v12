package com.example.hhggk.module.movement;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

/** Jumps automatically while you hold forward. */
public class BunnyHop extends Module {
    public final Setting.Bool sprintOnly = add(new Setting.Bool("Only while sprinting", false));

    public BunnyHop() { super("BunnyHop", Category.MOVEMENT); }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (mc.currentScreen != null || !mc.options.forwardKey.isPressed()) return;
        if (!p.isOnGround() || p.isSneaking() || p.isTouchingWater() || p.isClimbing()) return;
        if (sprintOnly.value && !p.isSprinting()) return;
        Vec3d v = p.getVelocity();
        p.setVelocity(v.x, 0.42, v.z);
    }
}
