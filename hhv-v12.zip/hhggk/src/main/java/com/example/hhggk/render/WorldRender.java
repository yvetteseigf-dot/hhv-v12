package com.example.hhggk.render;

import com.example.hhggk.Settings;
import com.example.hhggk.module.movement.ElytraTarget;
import com.example.hhggk.module.EntityFilter;
import com.example.hhggk.module.visual.Hat;
import com.example.hhggk.module.combat.Hitbox;
import com.example.hhggk.module.ModuleManager;
import com.example.hhggk.module.visual.ShowHitboxes;
import com.example.hhggk.module.visual.Tracers;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.VertexRendering;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;

/**
 * All 3D drawing: real hitboxes, ElytraTarget prediction block + path, Hat.
 * If a Yarn name for the box drawing changes, only the two Draw.* helpers below need fixing.
 */
public class WorldRender {

    private static class Draw {
        static void outline(MatrixStack ms, VertexConsumerProvider v, Box b, float r, float g, float bl, float a) {
            VertexRendering.drawBox(ms, v.getBuffer(RenderLayer.getLines()), b, r, g, bl, a);
        }

        static void filled(MatrixStack ms, VertexConsumerProvider v, Box b, float r, float g, float bl, float a) {
            VertexRendering.drawFilledBox(ms, v.getBuffer(RenderLayer.getDebugFilledBox()),
                    b.minX, b.minY, b.minZ, b.maxX, b.maxY, b.maxZ, r, g, bl, a);
        }
    }

    public static void render(WorldRenderContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || !Settings.active()) return;
        MatrixStack ms = ctx.matrixStack();
        VertexConsumerProvider vcp = ctx.consumers();
        if (ms == null || vcp == null) return;

        Vec3d cam = ctx.camera().getPos();
        float td = ctx.tickCounter().getTickDelta(false);

        ms.push();
        ms.translate(-cam.x, -cam.y, -cam.z);
        try {
            hitboxes(mc, ms, vcp, td);
            tracker(ms, vcp);
            hat(mc, ms, vcp, td, cam);
            tracers(mc, ms, vcp, td, cam);
        } finally {
            ms.pop();
        }

        if (vcp instanceof VertexConsumerProvider.Immediate imm) {
            imm.draw(RenderLayer.getDebugFilledBox());
            imm.draw(RenderLayer.getLines());
        }
    }

    // ---------------------------------------------------------------- hitboxes
    private static void hitboxes(MinecraftClient mc, MatrixStack ms, VertexConsumerProvider vcp, float td) {
        ShowHitboxes sh = ModuleManager.showHitboxes;
        Hitbox hb = ModuleManager.hitbox;
        boolean showAll = sh != null && sh.enabled;
        boolean showHb = hb != null && hb.enabled && hb.show.value;
        if (!showAll && !showHb) return;

        ClientPlayerEntity me = mc.player;
        double r = showAll ? sh.range.value : 64;
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity) || e == me) continue;
            if (me.squaredDistanceTo(e) > r * r) continue;
            if (showAll && sh.playersOnly.value && EntityFilter.kind(e, me) != 0 && e != me) {
                if (!(showHb && EntityFilter.kind(e, me) >= 0 && hb.allows(EntityFilter.kind(e, me)))) continue;
            }
            Vec3d off = e.getLerpedPos(td).subtract(e.getPos());
            Box base = e.getBoundingBox().offset(off);
            float margin = e.getTargetingMargin();      // already includes the Hitbox module's size
            Box real = base.expand(margin);

            if (showAll) {
                Draw.outline(ms, vcp, base, 0.75f, 0.75f, 0.75f, 1f);
                // eye height line
                double ey = base.minY + e.getStandingEyeHeight();
                Draw.outline(ms, vcp, new Box(base.minX, ey - 0.005, base.minZ, base.maxX, ey + 0.005, base.maxZ),
                        1f, 0.3f, 0.3f, 1f);
            }
            if (margin > 0.001f) Draw.outline(ms, vcp, real, 1f, 0.2f, 0.25f, 1f);
        }
    }

    // ---------------------------------------------------------------- elytra tracker
    private static void tracker(MatrixStack ms, VertexConsumerProvider vcp) {
        ElytraTarget et = ModuleManager.elytraTarget;
        if (et == null || !et.enabled || !et.showPrediction.value || et.target == null || et.goal == null) return;

        Vec3d g = et.goal;
        Box gb = new Box(g.x - 0.5, g.y - 0.5, g.z - 0.5, g.x + 0.5, g.y + 0.5, g.z + 0.5);
        float pulse = 0.25f + 0.1f * (float) Math.sin(System.currentTimeMillis() / 120.0);
        if (et.locked) {
            Draw.filled(ms, vcp, gb, 1f, 0.15f, 0.15f, pulse);
            Draw.outline(ms, vcp, gb, 1f, 0.3f, 0.3f, 1f);
        } else {
            Draw.filled(ms, vcp, gb, 0.2f, 0.85f, 1f, pulse);
            Draw.outline(ms, vcp, gb, 0.4f, 0.95f, 1f, 1f);
        }
        for (Vec3d pt : et.path) {
            Draw.filled(ms, vcp, new Box(pt.x - 0.08, pt.y - 0.08, pt.z - 0.08, pt.x + 0.08, pt.y + 0.08, pt.z + 0.08),
                    1f, 0.85f, 0.2f, 0.9f);
        }
        Draw.outline(ms, vcp, et.target.getBoundingBox(), 1f, 0.85f, 0.2f, 1f);
    }

    // ---------------------------------------------------------------- tracers
    private static void tracers(MinecraftClient mc, MatrixStack ms, VertexConsumerProvider vcp, float td, Vec3d cam) {
        Tracers t = ModuleManager.tracers;
        if (t == null || !t.enabled) return;
        ClientPlayerEntity me = mc.player;
        Vec3d start = cam.add(me.getRotationVec(td).multiply(0.6)).add(0, -0.12, 0);
        int n = (int) t.dots.value;
        double r = t.range.value;
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity) || e == me || me.squaredDistanceTo(e) > r * r) continue;
            int k = EntityFilter.kind(e, me);
            if (k < 0 || !t.allows(k)) continue;
            Vec3d end = e.getLerpedPos(td).add(0, e.getHeight() * 0.5, 0);
            float dist = (float) Math.min(1.0, me.distanceTo(e) / 60.0);
            float cr = 1f - dist * 0.6f, cg = 0.3f + dist * 0.6f, cb = 0.35f;
            for (int i = 1; i <= n; i++) {
                Vec3d pt = start.lerp(end, i / (double) n);
                double sz = 0.025;
                Draw.filled(ms, vcp, new Box(pt.x - sz, pt.y - sz, pt.z - sz, pt.x + sz, pt.y + sz, pt.z + sz), cr, cg, cb, 0.95f);
            }
        }
    }

    // ---------------------------------------------------------------- hat
    private static void hat(MinecraftClient mc, MatrixStack ms, VertexConsumerProvider vcp, float td, Vec3d cam) {
        Hat h = ModuleManager.hat;
        if (h == null || !h.enabled) return;
        if (mc.options.getPerspective().isFirstPerson()) return;
        ClientPlayerEntity p = mc.player;

        Vec3d eye = p.getLerpedPos(td).add(0, p.getEyeHeight(p.getPose()), 0);
        float yaw = MathHelper.lerpAngleDegrees(td, p.prevHeadYaw, p.headYaw);
        float pitch = MathHelper.lerp(td, p.prevPitch, p.getPitch());
        float s = (float) h.size.value;
        float[] c = h.rgb(0);
        float[] c2 = {Math.min(1f, c[0] + 0.35f), Math.min(1f, c[1] + 0.35f), Math.min(1f, c[2] + 0.35f)};

        ms.push();
        ms.translate(eye.x, eye.y, eye.z);
        ms.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-yaw));
        ms.multiply(RotationAxis.POSITIVE_X.rotationDegrees(pitch));
        ms.scale(s, s, s);
        // local space: origin = eyes, +Y = up out of the head, head top is at about y = 0.27
        switch (h.style.get()) {
            case "Crown" -> {
                box(ms, vcp, -0.27, 0.26, -0.27, 0.27, 0.40, 0.27, c);
                double[][] spikes = {{-0.25, -0.25}, {0.25, -0.25}, {-0.25, 0.25}, {0.25, 0.25}, {0, -0.26}, {0, 0.26}, {-0.26, 0}, {0.26, 0}};
                for (double[] sp : spikes) box(ms, vcp, sp[0] - 0.04, 0.40, sp[1] - 0.04, sp[0] + 0.04, 0.58, sp[1] + 0.04, c);
                box(ms, vcp, -0.04, 0.30, -0.285, 0.04, 0.36, -0.265, c2);
            }
            case "Wizard" -> {
                box(ms, vcp, -0.42, 0.26, -0.42, 0.42, 0.30, 0.42, c);
                double w = 0.30, y = 0.30;
                for (int i = 0; i < 6; i++) {
                    box(ms, vcp, -w + i * 0.002, y, -w, w + i * 0.002, y + 0.14, w, i % 2 == 0 ? c : c2);
                    w -= 0.045; y += 0.14;
                }
            }
            case "Halo" -> {
                double bob = Math.sin(System.currentTimeMillis() / 400.0) * 0.03;
                float[] g = h.color.is("Black") ? new float[]{1f, 0.85f, 0.25f} : c;
                for (int i = 0; i < 20; i++) {
                    double a = i * Math.PI * 2 / 20;
                    double x = Math.cos(a) * 0.38, z = Math.sin(a) * 0.38;
                    box(ms, vcp, x - 0.035, 0.52 + bob, z - 0.035, x + 0.035, 0.57 + bob, z + 0.035, g);
                }
            }
            default -> { // Top hat
                box(ms, vcp, -0.42, 0.26, -0.42, 0.42, 0.31, 0.42, c);
                box(ms, vcp, -0.26, 0.31, -0.26, 0.26, 0.78, 0.26, c);
                box(ms, vcp, -0.265, 0.31, -0.265, 0.265, 0.42, 0.265, h.color.is("Red") ? c2 : new float[]{0.85f, 0.1f, 0.12f});
            }
        }
        ms.pop();
    }

    private static void box(MatrixStack ms, VertexConsumerProvider vcp, double x1, double y1, double z1,
                            double x2, double y2, double z2, float[] c) {
        Draw.filled(ms, vcp, new Box(x1, y1, z1, x2, y2, z2), c[0], c[1], c[2], 1f);
    }
}
