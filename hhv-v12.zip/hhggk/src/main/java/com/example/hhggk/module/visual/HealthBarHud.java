package com.example.hhggk.module.visual;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/** Wide health bar (with absorption) in the middle of the screen. */
public class HealthBarHud extends Module {
    public final Setting.Num posY = add(new Setting.Num("Position Y %", 62, 0, 100, 1));
    public final Setting.Num width = add(new Setting.Num("Width", 80, 40, 200, 5));

    public HealthBarHud() { super("HealthBarHud", Category.VISUAL); }

    @Override
    public void onHud(DrawContext ctx, MinecraftClient mc) {
        float hp = mc.player.getHealth(), max = Math.max(1f, mc.player.getMaxHealth()), ab = mc.player.getAbsorptionAmount();
        int w = (int) width.value, x = (ctx.getScaledWindowWidth() - w) / 2, y = (int) ((ctx.getScaledWindowHeight() - 6) * posY.value / 100.0);
        ctx.fill(x - 1, y - 1, x + w + 1, y + 6, 0xC0000000);
        int fw = (int) (w * Math.min(1f, hp / max));
        int col = hp / max > 0.6f ? 0xFF3DDC84 : hp / max > 0.3f ? 0xFFFFC857 : 0xFFFF4D4D;
        ctx.fill(x, y, x + fw, y + 5, col);
        if (ab > 0) ctx.fill(x, y + 5, x + (int) (w * Math.min(1f, ab / max)), y + 6, 0xFFFFD700);
    }
}
