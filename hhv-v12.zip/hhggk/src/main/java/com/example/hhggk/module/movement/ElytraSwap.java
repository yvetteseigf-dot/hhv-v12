package com.example.hhggk.module.movement;

import com.example.hhggk.module.Inv;
import com.example.hhggk.module.Module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

/** One-shot: swaps chestplate <-> elytra. Bind a key to it in the ClickGui (middle click) and it works like a button. */
public class ElytraSwap extends Module {
    public ElytraSwap() { super("ElytraSwap", Category.MOVEMENT); }

    @Override
    public void onEnable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        enabled = false;                                       // single use
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.interactionManager == null || p.currentScreenHandler != p.playerScreenHandler) return;
        ItemStack chest = p.playerScreenHandler.getSlot(6).getStack();
        int found = -1;
        if (chest.isOf(Items.ELYTRA)) {
            double best = 0;
            for (int i = 0; i < 36; i++) {
                ItemStack s = p.getInventory().getStack(i);
                if (Inv.armorKind(s) != 1) continue;
                double sc = Inv.armorScore(s);
                if (sc > best) { best = sc; found = i; }
            }
        } else {
            for (int i = 0; i < 36; i++) {
                if (p.getInventory().getStack(i).isOf(Items.ELYTRA)) { found = i; break; }
            }
        }
        if (found >= 0) Inv.swapSlots(mc, p, Inv.container(found), 6);
    }
}
