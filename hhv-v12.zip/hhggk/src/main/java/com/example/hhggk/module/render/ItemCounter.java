package com.example.hhggk.module.render;

import com.example.hhggk.module.HudText;

import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Items;
import net.minecraft.item.Item;

public class ItemCounter extends HudText {
    private static int count(MinecraftClient mc, Item item) {
        int n = 0;
        for (int i = 0; i < mc.player.getInventory().size(); i++) {
            var s = mc.player.getInventory().getStack(i);
            if (s.isOf(item)) n += s.getCount();
        }
        return n;
    }

    public ItemCounter() { super("ItemCounter", Category.RENDER, 0, 60); }

    @Override
    protected String text(MinecraftClient mc) {
        return "Crystals " + count(mc, Items.END_CRYSTAL) + "\nGaps " + count(mc, Items.GOLDEN_APPLE)
                + "\nEGaps " + count(mc, Items.ENCHANTED_GOLDEN_APPLE) + "\nTotems " + count(mc, Items.TOTEM_OF_UNDYING)
                + "\nArrows " + count(mc, Items.ARROW);
    }
}
