package com.example.hhggk.module.combat;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;

/** Packet crits: tells the server you were falling for a moment right before each hit. Hooked in AttackMixin. */
public class Criticals extends Module {
    public static Criticals instance;
    public final Setting.Mode mode = add(new Setting.Mode("Mode", "Packet", "Mini jump"));

    public Criticals() { super("Criticals", Category.COMBAT); instance = this; }

    public static void onAttack(MinecraftClient mc, Entity target) {
        Criticals c = instance;
        if (c == null || !c.enabled || mc.getNetworkHandler() == null) return;
        ClientPlayerEntity p = mc.player;
        if (!p.isOnGround() || p.isTouchingWater() || p.isClimbing() || p.isGliding() || p.hasVehicle()) return;
        double x = p.getX(), y = p.getY(), z = p.getZ();
        if (c.mode.is("Packet")) {
            mc.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(x, y + 0.0625, z, false, false));
            mc.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(x, y, z, false, false));
        } else {
            mc.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(x, y + 0.11, z, false, false));
            mc.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(x, y + 0.1100013579, z, false, false));
            mc.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(x, y + 0.0000013579, z, false, false));
        }
    }
}
