package com.example.hhggk.module.visual;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.MathHelper;

/** Animated rainbow frame around the screen. */
public class ScreenBorder extends Module {
    public final Setting.Num thickness = add(new Setting.Num("Thickness", 2, 1, 8, 1));
    public final Setting.Num speed = add(new Setting.Num("Speed", 20, 5, 60, 5));

    public ScreenBorder() { super("ScreenBorder", Category.VISUAL); }

    @Override
    public void onHud(DrawContext ctx, MinecraftClient mc) {
        int w = ctx.getScaledWindowWidth(), h = ctx.getScaledWindowHeight(), t = (int) thickness.value;
        long time = System.currentTimeMillis();
        int seg = 24;
        for (int i = 0; i < seg; i++) {
            int c = 0xFF000000 | MathHelper.hsvToRgb(((time / (long) speed.value + i * 15L) % 360L) / 360f, 0.7f, 1f);
            int x0 = w * i / seg, x1 = w * (i + 1) / seg, y0 = h * i / seg, y1 = h * (i + 1) / seg;
            ctx.fill(x0, 0, x1, t, c);
            ctx.fill(x0, h - t, x1, h, c);
            ctx.fill(0, y0, t, y1, c);
            ctx.fill(w - t, y0, w, y1, c);
        }
    }
}
