package com.example.hhggk.module.combat;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.Stats;

import net.minecraft.client.MinecraftClient;

/** Resets your sprint right after every hit (more knockback). */
public class WTap extends Module {
    private long seen;

    public WTap() { super("WTap", Category.COMBAT); }

    @Override
    public void onTick(MinecraftClient mc) {
        if (Stats.lastHit != seen) {
            seen = Stats.lastHit;
            mc.player.setSprinting(false);
        }
    }
}
