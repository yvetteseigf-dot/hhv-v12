package com.example.hhggk.module.visual;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/** Pulsing red screen edges + text when your health is low. */
public class LowHealthWarning extends Module {
    public final Setting.Num health = add(new Setting.Num("Health (half hearts)", 8, 2, 19, 1));

    public LowHealthWarning() { super("LowHealth", Category.VISUAL); }

    @Override
    public void onHud(DrawContext ctx, MinecraftClient mc) {
        float hp = mc.player.getHealth();
        if (hp > health.value) return;
        int w = ctx.getScaledWindowWidth(), h = ctx.getScaledWindowHeight();
        int a = 0x30 + (int) (0x30 * (0.5 + 0.5 * Math.sin(System.currentTimeMillis() / 140.0)));
        int edge = (a << 24) | 0xFF0000, none = 0x00FF0000;
        int t = Math.max(24, h / 6);
        ctx.fillGradient(0, 0, w, t, edge, none);
        ctx.fillGradient(0, h - t, w, h, none, edge);
        ctx.drawCenteredTextWithShadow(mc.textRenderer, String.format("LOW HEALTH  %.1f", hp), w / 2, h / 2 + 50, 0xFFFF5555);
    }
}
