package com.example.hhggk.module.visual;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;

/** Replaces the vanilla crosshair (HudMixin hides the vanilla one). Turns red over a target. */
public class CustomCrosshair extends Module {
    public final Setting.Mode style = add(new Setting.Mode("Style", "Cross", "Dot", "Square"));
    public final Setting.Mode color = add(new Setting.Mode("Color", "Cyan", "White", "Green", "Rainbow"));
    public final Setting.Num size = add(new Setting.Num("Size", 5, 2, 14, 1));
    public final Setting.Num gap = add(new Setting.Num("Gap", 2, 0, 8, 1));
    public final Setting.Bool redOnTarget = add(new Setting.Bool("Red on target", true));

    public CustomCrosshair() { super("Crosshair", Category.VISUAL); }

    private int col(MinecraftClient mc) {
        Entity t = mc.targetedEntity;
        if (redOnTarget.value && t != null) return 0xFFFF3B3B;
        return switch (color.get()) {
            case "White" -> 0xFFFFFFFF;
            case "Green" -> 0xFF55FF55;
            case "Rainbow" -> 0xFF000000 | MathHelper.hsvToRgb((System.currentTimeMillis() % 3000) / 3000f, 0.7f, 1f);
            default -> 0xFF5CE1FF;
        };
    }

    @Override
    public void onHud(DrawContext ctx, MinecraftClient mc) {
        int cx = ctx.getScaledWindowWidth() / 2, cy = ctx.getScaledWindowHeight() / 2;
        int s = (int) size.value, g = (int) gap.value, c = col(mc), o = 0xC0000000;
        switch (style.get()) {
            case "Dot" -> {
                ctx.fill(cx - 2, cy - 2, cx + 2, cy + 2, o);
                ctx.fill(cx - 1, cy - 1, cx + 1, cy + 1, c);
            }
            case "Square" -> {
                int r = s + g;
                ctx.fill(cx - r - 1, cy - r - 1, cx + r + 1, cy - r + 1, c);
                ctx.fill(cx - r - 1, cy + r - 1, cx + r + 1, cy + r + 1, c);
                ctx.fill(cx - r - 1, cy - r - 1, cx - r + 1, cy + r + 1, c);
                ctx.fill(cx + r - 1, cy - r - 1, cx + r + 1, cy + r + 1, c);
            }
            default -> {
                ctx.fill(cx - g - s - 1, cy - 2, cx - g + 1, cy + 2, o);
                ctx.fill(cx + g - 1, cy - 2, cx + g + s + 1, cy + 2, o);
                ctx.fill(cx - 2, cy - g - s - 1, cx + 2, cy - g + 1, o);
                ctx.fill(cx - 2, cy + g - 1, cx + 2, cy + g + s + 1, o);
                ctx.fill(cx - g - s, cy - 1, cx - g, cy + 1, c);
                ctx.fill(cx + g, cy - 1, cx + g + s, cy + 1, c);
                ctx.fill(cx - 1, cy - g - s, cx + 1, cy - g, c);
                ctx.fill(cx - 1, cy + g, cx + 1, cy + g + s, c);
            }
        }
    }
}
