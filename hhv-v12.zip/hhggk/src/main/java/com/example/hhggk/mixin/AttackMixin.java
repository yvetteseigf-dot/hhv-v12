package com.example.hhggk.mixin;

import com.example.hhggk.module.combat.AutoMace;
import com.example.hhggk.module.combat.Criticals;
import com.example.hhggk.module.combat.MoreKnockback;
import com.example.hhggk.module.misc.FakePlayer;
import com.example.hhggk.module.Stats;
import com.example.hhggk.module.ModuleManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayerInteractionManager.class)
public class AttackMixin {
    @Inject(method = "attackEntity", at = @At("HEAD"), cancellable = true)
    private void hhggk$beforeAttack(PlayerEntity player, Entity target, CallbackInfo ci) {
        AutoMace am = ModuleManager.autoMace;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (player != mc.player) return;
        if (am != null && am.enabled) am.beforeAttack(mc, target);
        Criticals.onAttack(mc, target);
        MoreKnockback.onAttack(mc, target);
        Stats.onAttack(mc, target);
        if (target == FakePlayer.fake && FakePlayer.fake != null) {
            FakePlayer.onAttacked(mc, player);
            player.resetLastAttackedTicks();   // like a real hit, but nothing is sent to the server
            ci.cancel();
        }
    }
}
