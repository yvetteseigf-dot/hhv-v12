package com.example.hhggk.module.combat;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;

/** Eats a golden apple (offhand or hotbar) when your health is low, then switches back. */
public class AutoGap extends Module {
    public final Setting.Num health = add(new Setting.Num("Health (half hearts)", 10, 2, 19, 1));
    public final Setting.Bool enchanted = add(new Setting.Bool("Use enchanted apples", true));

    private boolean eating;
    private int prevSlot = -1, ticks;

    public AutoGap() { super("AutoGap", Category.COMBAT); }

    private boolean isGap(net.minecraft.item.ItemStack s) {
        return s.isOf(Items.GOLDEN_APPLE) || (enchanted.value && s.isOf(Items.ENCHANTED_GOLDEN_APPLE));
    }

    private void stop(MinecraftClient mc, ClientPlayerEntity p) {
        mc.options.useKey.setPressed(false);
        if (prevSlot >= 0) p.getInventory().selectedSlot = prevSlot;
        prevSlot = -1; eating = false; ticks = 0;
    }

    @Override
    public void onDisable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (eating && mc.player != null) stop(mc, mc.player);
        eating = false;
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (!eating) {
            if (p.getHealth() > health.value || mc.currentScreen != null || p.isUsingItem()) return;
            boolean off = isGap(p.getOffHandStack());
            int slot = -1;
            if (!off) for (int i = 0; i < 9; i++) if (isGap(p.getInventory().getStack(i))) { slot = i; break; }
            if (!off && slot < 0) return;
            if (slot >= 0) { prevSlot = p.getInventory().selectedSlot; p.getInventory().selectedSlot = slot; }
            eating = true; ticks = 0;
            mc.options.useKey.setPressed(true);
        } else {
            ticks++;
            if ((!p.isUsingItem() && ticks > 3) || ticks > 70) stop(mc, p);
            else mc.options.useKey.setPressed(true);
        }
    }
}
