package com.example.hhggk.module.misc;

import com.example.hhggk.Friends;
import com.example.hhggk.Settings;
import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.PlayerListEntry;

/** Answers "X wants to teleport to you" with /tpaccept. Friends only by default. */
public class AutoTPaccept extends Module {
    public final Setting.Bool onlyFriends = add(new Setting.Bool("Friends only", true));

    private static AutoTPaccept self;

    public AutoTPaccept() {
        super("AutoTPaccept", Category.MISC);
        self = this;
        ClientReceiveMessageEvents.GAME.register((msg, overlay) -> {
            if (overlay) return;
            try { handle(msg.getString()); } catch (Throwable ignored) {}
        });
    }

    private static void handle(String text) {
        AutoTPaccept m = self;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (m == null || !m.enabled || !Settings.active() || mc.getNetworkHandler() == null || mc.player == null) return;
        String low = text.toLowerCase();
        if (!(low.contains("teleport to you") || low.contains("requested to teleport") || low.contains("tpa request"))) return;
        for (PlayerListEntry e : mc.getNetworkHandler().getPlayerList()) {
            String name = e.getProfile().getName();
            if (name.equals(mc.player.getGameProfile().getName()) || !text.contains(name)) continue;
            if (m.onlyFriends.value && !Friends.isFriend(name)) continue;
            mc.getNetworkHandler().sendChatCommand("tpaccept");
            return;
        }
    }
}
