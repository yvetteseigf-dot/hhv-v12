package com.example.hhggk.module.visual;

import com.example.hhggk.module.Drawable3D;
import com.example.hhggk.module.Module;
import com.example.hhggk.render.Overlay3D;

import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.shape.VoxelShape;

/** Colored box on the block you are looking at. */
public class BlockHighLight extends Module implements Drawable3D {
    public BlockHighLight() { super("BlockHighLight", Category.VISUAL); }

    @Override
    public void draw3d(MinecraftClient mc, MatrixStack ms, VertexConsumerProvider vcp, Vec3d cam, float td) {
        if (!(mc.crosshairTarget instanceof BlockHitResult h) || h.getType() != HitResult.Type.BLOCK) return;
        BlockPos pos = h.getBlockPos();
        BlockState st = mc.world.getBlockState(pos);
        VoxelShape shape = st.getOutlineShape(mc.world, pos);
        Box b = shape.isEmpty() ? new Box(pos) : shape.getBoundingBox().offset(pos);
        b = b.expand(0.002);
        Overlay3D.filled(ms, vcp, b, 0.3f, 0.6f, 1f, 0.25f);
        Overlay3D.outline(ms, vcp, b, 0.4f, 0.75f, 1f, 1f);
    }
}
