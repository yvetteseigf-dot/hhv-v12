package com.example.hhggk.module.visual;

import com.example.hhggk.module.HudText;

import net.minecraft.client.MinecraftClient;


public class PlayerCount extends HudText {

    public PlayerCount() { super("PlayerCount", Category.VISUAL, 100, 8); }

    @Override
    protected String text(MinecraftClient mc) {
        if (mc.getNetworkHandler() == null) return "";
        return "Players " + mc.getNetworkHandler().getPlayerList().size();
    }
}
