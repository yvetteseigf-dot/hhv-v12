package com.example.hhggk.module.render;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.ModuleManager;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.MathHelper;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class HudModule extends Module {
    public final Setting.Bool watermark = add(new Setting.Bool("Watermark", true));
    public final Setting.Bool arrayList = add(new Setting.Bool("Module list", true));
    public final Setting.Bool coords = add(new Setting.Bool("Coordinates", true));
    public final Setting.Bool fps = add(new Setting.Bool("FPS", true));
    public final Setting.Bool speed = add(new Setting.Bool("Speed (b/s)", true));

    public HudModule() { super("HUD", Category.RENDER); }

    @Override
    public void onHud(DrawContext ctx, MinecraftClient mc) {
        var p = mc.player;
        int y = 2;
        if (watermark.value) { ctx.drawTextWithShadow(mc.textRenderer, "Diamond", 2, y, 0xFF55E6FF); y += 10; }
        if (coords.value) {
            ctx.drawTextWithShadow(mc.textRenderer,
                    String.format("XYZ %.1f %.1f %.1f", p.getX(), p.getY(), p.getZ()), 2, y, 0xFFFFFFFF);
            y += 10;
        }
        if (fps.value) { ctx.drawTextWithShadow(mc.textRenderer, "FPS " + mc.getCurrentFps(), 2, y, 0xFFFFFFFF); y += 10; }
        if (speed.value) {
            double bps = Math.hypot(p.getX() - p.prevX, p.getZ() - p.prevZ) * 20.0;
            ctx.drawTextWithShadow(mc.textRenderer, String.format("%.1f b/s", bps), 2, y, 0xFFFFFFFF);
        }
        if (arrayList.value) {
            List<String> names = new ArrayList<>();
            for (Module m : ModuleManager.modules) if (m.enabled) names.add(m.name);
            names.sort(Comparator.comparingInt((String n) -> mc.textRenderer.getWidth(n)).reversed());
            int w = ctx.getScaledWindowWidth();
            int ry = 2, i = 0;
            for (String n : names) {
                int color = 0xFF000000 | MathHelper.hsvToRgb(
                        ((System.currentTimeMillis() / 20 + i * 20) % 360) / 360f, 0.6f, 1f);
                int tw = mc.textRenderer.getWidth(n);
                ctx.fill(w - tw - 6, ry, w, ry + 11, 0xC0000000);
                ctx.fill(w - 2, ry, w, ry + 11, color);
                ctx.drawTextWithShadow(mc.textRenderer, n, w - tw - 4, ry + 2, 0xFFFFFFFF);
                ry += 11; i++;
            }
        }
    }
}
