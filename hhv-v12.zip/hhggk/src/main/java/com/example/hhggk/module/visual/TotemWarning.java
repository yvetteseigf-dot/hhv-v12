package com.example.hhggk.module.visual;

import com.example.hhggk.module.HudText;

import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Items;

public class TotemWarning extends HudText {

    public TotemWarning() { super("TotemWarning", Category.VISUAL, 50, 30); }

    @Override
    protected String text(MinecraftClient mc) {
        boolean has = mc.player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)
                || mc.player.getMainHandStack().isOf(Items.TOTEM_OF_UNDYING);
        return has ? "" : "NO TOTEM";
    }

    @Override
    protected int color(MinecraftClient mc) {
        return 0xFFFF5555;
    }
}
