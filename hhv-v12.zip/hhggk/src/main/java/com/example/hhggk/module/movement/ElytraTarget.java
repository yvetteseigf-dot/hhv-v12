package com.example.hhggk.module.movement;

import com.example.hhggk.module.EntityFilter;
import com.example.hhggk.module.Fireworks;
import com.example.hhggk.module.Module;
import com.example.hhggk.module.ModuleManager;
import com.example.hhggk.module.Rot;
import com.example.hhggk.module.Setting;
import com.example.hhggk.module.misc.FakePlayer;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Deque;
import java.util.List;

/**
 * Predictive elytra tracker.
 *  CHASE: estimates the target's velocity + acceleration, solves an intercept point and flies to a
 *         "virtual block" placed AHEAD of the target (cut-off distance) using fireworks at full speed.
 *  LOCK : once inside the lock radius it matches the target's velocity, stays at hit distance,
 *         keeps the aim glued to the target and attacks every cooldown so no hit is lost.
 */
public class ElytraTarget extends Module {
    public final Setting.Mode mode = add(new Setting.Mode("Lock position", "Front", "Behind", "Orbit"));
    public final Setting.Num distance = add(new Setting.Num("Hit distance", 2.5, 1.0, 5.0, 0.1));
    public final Setting.Num height = add(new Setting.Num("Height offset", 0.0, -2.0, 3.0, 0.5));
    public final Setting.Num range = add(new Setting.Num("Search range", 100, 10, 300, 5));
    public final Setting.Bool playersOnly = add(new Setting.Bool("Players only", true));
    public final Setting.Bool predict = add(new Setting.Bool("Predict + intercept", true));
    public final Setting.Num maxPredict = add(new Setting.Num("Max predict ticks", 25, 3, 60, 1));
    public final Setting.Num cutOff = add(new Setting.Num("Cut-off distance", 3.0, 0.0, 12.0, 0.5));
    public final Setting.Num lockRadius = add(new Setting.Num("Lock radius", 8, 3, 25, 1));
    public final Setting.Num gain = add(new Setting.Num("Lock strength", 0.6, 0.1, 1.0, 0.05));
    public final Setting.Bool face = add(new Setting.Bool("Face target in lock", true));
    public final Setting.Num smooth = add(new Setting.Num("Rotation smoothing", 0.6, 0.05, 1.0, 0.05));
    public final Setting.Num orbitSpeed = add(new Setting.Num("Orbit speed", 12, 2, 40, 1));
    public final Setting.Bool autoFw = add(new Setting.Bool("Auto fireworks", true));
    public final Setting.Num fwDelay = add(new Setting.Num("Rocket delay ms", 350, 100, 1000, 50));
    public final Setting.Bool autoAttack = add(new Setting.Bool("Auto attack", true));
    public final Setting.Num reach = add(new Setting.Num("Attack reach", 3.0, 2.0, 6.0, 0.1));
    public final Setting.Bool pauseEating = add(new Setting.Bool("Pause while eating", true));
    public final Setting.Bool showPrediction = add(new Setting.Bool("Show prediction", true));

    // state read by the renderer / other modules
    public boolean targeting;
    public boolean locked;
    public LivingEntity target;
    public Vec3d goal;
    public double targetDist;
    public final List<Vec3d> path = new ArrayList<>();

    private final Deque<Vec3d> hist = new ArrayDeque<>();
    private int histId = -1;
    private LivingEntity sticky;
    private long lastFw;
    private long lastWarn;
    private double orbitAngle;

    public ElytraTarget() { super("ElytraTarget", Category.MOVEMENT); }

    @Override
    public void onDisable() { reset(); hist.clear(); sticky = null; }

    private void reset() { targeting = false; locked = false; target = null; goal = null; path.clear(); }

    private boolean valid(ClientPlayerEntity p, LivingEntity e) {
        int k = EntityFilter.kind(e, p);
        return k >= 0 && (!playersOnly.value || k == 0) && e.isAlive() && !e.isSpectator();
    }

    private LivingEntity pick(MinecraftClient mc, ClientPlayerEntity p) {
        if (sticky != null && valid(p, sticky) && p.distanceTo(sticky) < range.value * 1.2) return sticky;
        List<LivingEntity> list = new ArrayList<>(mc.world.getEntitiesByClass(LivingEntity.class,
                p.getBoundingBox().expand(range.value), e -> valid(p, e)));
        if (FakePlayer.fake != null && valid(p, FakePlayer.fake) && p.distanceTo(FakePlayer.fake) < range.value) {
            FakePlayer.addTo(list);
        }
        if (list.isEmpty()) return null;
        sticky = list.stream().min(Comparator.comparingDouble(p::distanceTo)).get();
        return sticky;
    }

    @Override
    public void onTick(MinecraftClient mc) {
        reset();
        ClientPlayerEntity p = mc.player;
        if (!p.isGliding() || mc.currentScreen != null) { hist.clear(); return; }
        if (pauseEating.value && p.isUsingItem()) return;

        LivingEntity t = pick(mc, p);
        if (t == null) { hist.clear(); return; }

        if (t.getId() != histId) { hist.clear(); histId = t.getId(); }
        hist.addLast(t.getPos());
        while (hist.size() > 6) hist.removeFirst();
        Vec3d[] h = hist.toArray(new Vec3d[0]);
        int n = h.length;

        // velocity (blocks/tick), smoothed over the last few ticks
        Vec3d tv = n >= 2 ? h[n - 1].subtract(h[0]).multiply(1.0 / (n - 1))
                : new Vec3d(t.getX() - t.prevX, t.getY() - t.prevY, t.getZ() - t.prevZ);
        // acceleration (curved paths), damped and capped
        Vec3d acc = Vec3d.ZERO;
        if (n >= 5) {
            Vec3d vNew = h[n - 1].subtract(h[n - 3]).multiply(0.5);
            Vec3d vOld = h[n - 3].subtract(h[n - 5]).multiply(0.5);
            acc = vNew.subtract(vOld).multiply(0.25);
            if (acc.length() > 0.08) acc = acc.normalize().multiply(0.08);
        }
        final Vec3d fv = tv, fa = acc;
        final Vec3d tp = t.getPos();
        final Vec3d me = p.getPos();

        SuperFireworks sf = ModuleManager.fireworks;
        double cap = (sf != null && sf.enabled) ? sf.capPerTick() : 1.6;
        cap = Math.max(cap, 0.3);

        double dist = me.distanceTo(tp);
        boolean lock = dist <= lockRadius.value;
        Vec3d dir = tv.lengthSquared() > 0.0025 ? tv.normalize() : yawDir(t.getYaw());

        Vec3d goalPos;
        if (!lock) {
            Vec3d ip = tp;
            if (predict.value) {
                double time = Math.max(1.0, dist / cap);
                for (int i = 0; i < 5; i++) {
                    time = Math.min(maxPredict.value, Math.max(1.0, at(tp, fv, fa, time).distanceTo(me) / cap));
                }
                ip = at(tp, fv, fa, time);
            }
            goalPos = ip.add(dir.multiply(cutOff.value)).add(0, height.value, 0);
        } else {
            Vec3d p1 = predict.value ? at(tp, fv, fa, 1.0) : tp;
            Vec3d off;
            switch (mode.get()) {
                case "Behind" -> off = dir.multiply(-distance.value);
                case "Orbit" -> {
                    orbitAngle += Math.toRadians(orbitSpeed.value);
                    off = new Vec3d(Math.cos(orbitAngle), 0, Math.sin(orbitAngle)).multiply(distance.value);
                }
                default -> off = dir.multiply(distance.value);
            }
            goalPos = p1.add(off).add(0, height.value, 0);
        }

        double mySpeed = p.getVelocity().length();
        Vec3d delta = goalPos.subtract(me);
        Vec3d desired = tv.add(delta.multiply(gain.value));
        if (desired.length() > cap) desired = desired.normalize().multiply(cap);
        p.setVelocity(desired);

        // state for renderer / HUD
        targeting = true;
        locked = lock;
        target = t;
        goal = goalPos;
        targetDist = dist;
        for (int k = 2; k <= 24; k += 2) path.add(at(tp, fv, fa, k));

        // rotation
        Vec3d eye = p.getEyePos();
        Vec3d center = t.getBoundingBox().getCenter();
        Vec3d lookAt;
        float s;
        if (face.value && lock) {
            lookAt = center.add(tv);
            s = 1.0f;
        } else {
            lookAt = eye.add(desired.lengthSquared() > 1.0E-4 ? desired : delta);
            s = (float) smooth.value;
        }
        float ty = Rot.yawTo(eye, lookAt), tpitch = Rot.pitchTo(eye, lookAt);
        p.setYaw(p.getYaw() + MathHelper.wrapDegrees(ty - p.getYaw()) * s);
        p.setPitch(MathHelper.clamp(p.getPitch() + (tpitch - p.getPitch()) * s, -90f, 90f));

        // attack: never miss a swing while locked on
        if (autoAttack.value && mc.interactionManager != null) {
            double r = reach.value;
            if (EntityFilter.distSqToBox(eye, t.getBoundingBox()) <= r * r
                    && p.getAttackCooldownProgress(0.5f) >= 0.99f) {
                p.setYaw(Rot.yawTo(eye, center));
                p.setPitch(Rot.pitchTo(eye, center));
                mc.interactionManager.attackEntity(p, t);
                p.swingHand(Hand.MAIN_HAND);
            }
        }

        // fireworks: boost hard while chasing, keep up with the target while locked
        if (autoFw.value && !p.isUsingItem()) {
            long now = System.currentTimeMillis();
            boolean slow = mySpeed < cap * 0.8;
            boolean need = !lock || slow || mySpeed < tv.length() * 0.95;
            if (need && now - lastFw >= (long) fwDelay.value) {
                if (Fireworks.use(mc, p)) {
                    lastFw = now;
                } else if (now - lastWarn > 4000) {
                    lastWarn = now;
                    p.sendMessage(Text.literal("[Diamond] ElytraTarget: no firework rockets found (offhand / hotbar / inventory)."), true);
                }
            }
        }
    }

    private static Vec3d at(Vec3d tp, Vec3d v, Vec3d a, double ticks) {
        Vec3d accTerm = a.multiply(0.5 * ticks * ticks);
        if (accTerm.length() > 6.0) accTerm = accTerm.normalize().multiply(6.0);
        return tp.add(v.multiply(ticks)).add(accTerm);
    }

    private static Vec3d yawDir(float yawDeg) {
        double y = Math.toRadians(yawDeg);
        return new Vec3d(-Math.sin(y), 0, Math.cos(y));
    }

    @Override
    public void onHud(DrawContext ctx, MinecraftClient mc) {
        if (target == null) return;
        String s = target.getName().getString() + "  " + String.format("%.1fm", targetDist)
                + "  " + (locked ? "LOCK" : "CHASE");
        int w = ctx.getScaledWindowWidth(), h = ctx.getScaledWindowHeight();
        int tw = mc.textRenderer.getWidth(s);
        ctx.fill(w / 2 - tw / 2 - 5, h / 2 + 20, w / 2 + tw / 2 + 5, h / 2 + 34, 0xA0000000);
        ctx.fill(w / 2 - tw / 2 - 5, h / 2 + 33, w / 2 + tw / 2 + 5, h / 2 + 34, locked ? 0xFFFF5555 : 0xFF5CE1FF);
        ctx.drawCenteredTextWithShadow(mc.textRenderer, s, w / 2, h / 2 + 23, locked ? 0xFFFF7777 : 0xFFFFFFFF);
    }
}
