package com.example.hhggk;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

/** Main menu: full-screen LuxeDLC artwork with a slim button column. Replaces the vanilla title screen. */
public class LuxeTitleScreen extends Screen {
    private static final Identifier BG = Identifier.of("hhggk", "textures/gui/luxe_menu.png");
    private static final int TEX_W = 1280, TEX_H = 698;
    private static final int PURPLE = 0xFFB794FF, PURPLE_DARK = 0xFF4B2FA8;

    private static final String[] LABELS = {"Singleplayer", "Multiplayer", "Options", "Quit Game"};
    private static final int BTN_W = 150, BTN_H = 22, GAP = 6;

    public LuxeTitleScreen() { super(Text.literal("Diamond")); }

    @Override
    public boolean shouldCloseOnEsc() { return false; }

    private int bx() { return Math.max(14, width / 18); }

    private int by(int i) {
        int total = LABELS.length * BTN_H + (LABELS.length - 1) * GAP;
        return (height - total) / 2 + i * (BTN_H + GAP);
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        // background: artwork scaled to cover the whole window
        ctx.fill(0, 0, width, height, 0xFF05030C);
        float scale = Math.max(width / (float) TEX_W, height / (float) TEX_H);
        float ox = (width - TEX_W * scale) / 2f, oy = (height - TEX_H * scale) / 2f;
        ctx.getMatrices().push();
        ctx.getMatrices().translate(ox, oy, 0f);
        ctx.getMatrices().scale(scale, scale, 1f);
        ctx.drawTexture(RenderLayer::getGuiTextured, BG, 0, 0, 0f, 0f, TEX_W, TEX_H, TEX_W, TEX_H);
        ctx.getMatrices().pop();
        // soft dark band on the left so the buttons stay readable
        ctx.fillGradient(0, 0, bx() * 2 + BTN_W, height, 0xB0000000, 0x00000000);

        for (int i = 0; i < LABELS.length; i++) {
            int x = bx(), y = by(i);
            boolean hov = mx >= x && mx < x + BTN_W && my >= y && my < y + BTN_H;
            ctx.fill(x, y, x + BTN_W, y + BTN_H, hov ? 0xE02A2650 : 0xC00E0B1E);
            ctx.fill(x, y, x + 3, y + BTN_H, hov ? PURPLE : PURPLE_DARK);
            ctx.drawTextWithShadow(textRenderer, LABELS[i], x + 12, y + 7, hov ? 0xFFFFFFFF : 0xFFC8C8D8);
        }
        ctx.drawTextWithShadow(textRenderer, "Diamond  |  P = menu in game", bx(), height - 14, 0xFF8A7BC8);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button == 0) {
            for (int i = 0; i < LABELS.length; i++) {
                int x = bx(), y = by(i);
                if (mx >= x && mx < x + BTN_W && my >= y && my < y + BTN_H) {
                    MinecraftClient mc = MinecraftClient.getInstance();
                    switch (i) {
                        case 0 -> mc.setScreen(new SelectWorldScreen(this));
                        case 1 -> mc.setScreen(new MultiplayerScreen(this));
                        case 2 -> mc.setScreen(new OptionsScreen(this, mc.options));
                        default -> mc.scheduleStop();
                    }
                    return true;
                }
            }
        }
        return super.mouseClicked(mx, my, button);
    }
}
