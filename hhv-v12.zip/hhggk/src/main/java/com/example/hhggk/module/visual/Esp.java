package com.example.hhggk.module.visual;

import com.example.hhggk.module.TargetModule;

/** Outline (glow) through walls. Applied in EntityMixin. */
public class Esp extends TargetModule {
    public Esp() { super("ESP", Category.VISUAL, true, true, true, true); }
}
