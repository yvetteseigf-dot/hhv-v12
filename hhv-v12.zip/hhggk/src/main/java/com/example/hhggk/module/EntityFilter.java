package com.example.hhggk.module;

import com.example.hhggk.module.combat.AntiBot;
import com.example.hhggk.module.combat.Teams;
import com.example.hhggk.module.misc.FakePlayer;

import com.example.hhggk.Friends;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class EntityFilter {
    /** 0 = player, 1 = hostile, 2 = animal, 3 = other living, -1 = ignore (self, fake player, friends...) */
    public static int kind(Entity e, Entity self) {
        if (e == null || e == self) return -1;
        if (e == FakePlayer.fake) return FakePlayer.canTarget ? 0 : -1;
        if (e instanceof PlayerEntity pe) {
            if (Friends.isFriend(pe.getName().getString())) return -1;
            if (AntiBot.isBot(pe)) return -1;
            if (Teams.same(self, pe)) return -1;
            return 0;
        }
        if (e instanceof ArmorStandEntity) return -1;
        if (!(e instanceof LivingEntity)) return -1;
        if (e instanceof Monster) return 1;
        if (e instanceof AnimalEntity) return 2;
        return 3;
    }

    public static double distSqToBox(Vec3d p, Box b) {
        double dx = p.x - MathHelper.clamp(p.x, b.minX, b.maxX);
        double dy = p.y - MathHelper.clamp(p.y, b.minY, b.maxY);
        double dz = p.z - MathHelper.clamp(p.z, b.minZ, b.maxZ);
        return dx * dx + dy * dy + dz * dz;
    }
}
