package com.example.hhggk.module.visual;

import com.example.hhggk.module.HudText;

import net.minecraft.client.MinecraftClient;


public class FpsHud extends HudText {

    public FpsHud() { super("FpsHud", Category.VISUAL, 0, 10); }

    @Override
    protected String text(MinecraftClient mc) {
        return "FPS " + mc.getCurrentFps();
    }

    @Override
    protected int color(MinecraftClient mc) {
        int f = mc.getCurrentFps();
        return f >= 120 ? 0xFF55FF55 : f >= 60 ? 0xFFFFFF55 : 0xFFFF5555;
    }
}
