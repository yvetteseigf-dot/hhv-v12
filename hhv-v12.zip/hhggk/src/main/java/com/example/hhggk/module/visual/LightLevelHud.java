package com.example.hhggk.module.visual;

import com.example.hhggk.module.HudText;

import net.minecraft.client.MinecraftClient;


public class LightLevelHud extends HudText {

    public LightLevelHud() { super("LightLevelHud", Category.VISUAL, 0, 72); }

    @Override
    protected String text(MinecraftClient mc) {
        return "Light " + mc.world.getLightLevel(mc.player.getBlockPos());
    }
}
