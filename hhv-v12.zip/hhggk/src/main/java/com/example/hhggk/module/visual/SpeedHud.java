package com.example.hhggk.module.visual;

import com.example.hhggk.module.Module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/** Your horizontal speed in blocks per second. */
public class SpeedHud extends Module {
    private double lx, lz;
    private double bps;

    public SpeedHud() { super("SpeedHud", Category.VISUAL); }

    @Override
    public void onTick(MinecraftClient mc) {
        double dx = mc.player.getX() - lx, dz = mc.player.getZ() - lz;
        bps = Math.hypot(dx, dz) * 20.0;
        lx = mc.player.getX();
        lz = mc.player.getZ();
    }

    @Override
    public void onHud(DrawContext ctx, MinecraftClient mc) {
        String s = String.format("%.1f b/s", bps);
        int w = mc.textRenderer.getWidth(s);
        int x = ctx.getScaledWindowWidth() - w - 8, y = ctx.getScaledWindowHeight() - 28;
        ctx.fill(x - 3, y - 2, x + w + 3, y + 10, 0xA0101018);
        ctx.drawTextWithShadow(mc.textRenderer, s, x, y, 0xFF5CE1FF);
    }
}
