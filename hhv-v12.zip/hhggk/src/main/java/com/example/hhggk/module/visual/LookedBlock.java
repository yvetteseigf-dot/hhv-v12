package com.example.hhggk.module.visual;

import com.example.hhggk.module.HudText;

import net.minecraft.client.MinecraftClient;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;

public class LookedBlock extends HudText {

    public LookedBlock() { super("LookedBlock", Category.VISUAL, 50, 45); }

    @Override
    protected String text(MinecraftClient mc) {
        if (mc.crosshairTarget instanceof BlockHitResult b && b.getType() == HitResult.Type.BLOCK) {
            return mc.world.getBlockState(b.getBlockPos()).getBlock().getName().getString();
        }
        return "";
    }
}
