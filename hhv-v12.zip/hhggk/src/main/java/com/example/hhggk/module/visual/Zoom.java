package com.example.hhggk.module.visual;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

/** Hold C to zoom in. */
public class Zoom extends Module {
    public final Setting.Num zoomFov = add(new Setting.Num("Zoom FOV", 20, 5, 60, 1));
    private int old = 70;
    private boolean zooming;

    public Zoom() { super("Zoom", Category.VISUAL); }

    @Override
    public void onTick(MinecraftClient mc) {
        boolean down = mc.currentScreen == null
                && InputUtil.isKeyPressed(mc.getWindow().getHandle(), GLFW.GLFW_KEY_C);
        if (down && !zooming) { old = mc.options.getFov().getValue(); zooming = true; }
        if (down) mc.options.getFov().setValue((int) zoomFov.value);
        else if (zooming) { mc.options.getFov().setValue(old); zooming = false; }
    }

    @Override
    public void onDisable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (zooming) { mc.options.getFov().setValue(old); zooming = false; }
    }
}
