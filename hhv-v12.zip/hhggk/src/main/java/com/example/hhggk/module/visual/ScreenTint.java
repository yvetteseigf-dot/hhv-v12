package com.example.hhggk.module.visual;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/** Colored film over the whole screen. */
public class ScreenTint extends Module {
    public final Setting.Num red = add(new Setting.Num("Red", 90, 0, 255, 5));
    public final Setting.Num green = add(new Setting.Num("Green", 40, 0, 255, 5));
    public final Setting.Num blue = add(new Setting.Num("Blue", 200, 0, 255, 5));
    public final Setting.Num alpha = add(new Setting.Num("Strength", 40, 5, 160, 5));

    public ScreenTint() { super("ScreenTint", Category.VISUAL); }

    @Override
    public void onHud(DrawContext ctx, MinecraftClient mc) {
        int col = ((int) alpha.value << 24) | ((int) red.value << 16) | ((int) green.value << 8) | (int) blue.value;
        ctx.fill(0, 0, ctx.getScaledWindowWidth(), ctx.getScaledWindowHeight(), col);
    }
}
