package com.example.hhggk.module.visual;

import com.example.hhggk.module.Drawable3D;
import com.example.hhggk.module.Module;
import com.example.hhggk.render.Overlay3D;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

/** Shows where an ender pearl / snowball / egg / splash potion / arrow you are about to throw will land. */
public class Trajectories extends Module implements Drawable3D {
    public Trajectories() { super("Trajectories", Category.VISUAL); }

    private static boolean throwable(ItemStack s) {
        return s.isOf(Items.ENDER_PEARL) || s.isOf(Items.SNOWBALL) || s.isOf(Items.EGG)
                || s.isOf(Items.SPLASH_POTION) || s.isOf(Items.EXPERIENCE_BOTTLE);
    }

    @Override
    public void draw3d(MinecraftClient mc, MatrixStack ms, VertexConsumerProvider vcp, Vec3d cam, float td) {
        ClientPlayerEntity p = mc.player;
        ItemStack s = p.getMainHandStack();
        double speed, grav;
        if (s.isOf(Items.BOW) && p.isUsingItem()) {
            float f = p.getItemUseTime() / 20f;
            f = (f * f + f * 2f) / 3f;
            if (f < 0.1f) return;
            if (f > 1f) f = 1f;
            speed = f * 3.0; grav = 0.05;
        } else if (throwable(s)) {
            speed = s.isOf(Items.SPLASH_POTION) ? 0.5 : (s.isOf(Items.EXPERIENCE_BOTTLE) ? 0.7 : 1.5);
            grav = s.isOf(Items.SPLASH_POTION) ? 0.05 : (s.isOf(Items.EXPERIENCE_BOTTLE) ? 0.07 : 0.03);
        } else return;

        Vec3d pos = p.getLerpedPos(td).add(0, p.getStandingEyeHeight() - 0.1, 0);
        Vec3d vel = p.getRotationVec(td).multiply(speed);
        Vec3d end = null;
        for (int i = 0; i < 160; i++) {
            Vec3d next = pos.add(vel);
            var hit = mc.world.raycast(new RaycastContext(pos, next, RaycastContext.ShapeType.COLLIDER,
                    RaycastContext.FluidHandling.NONE, p));
            boolean stop = hit.getType() != HitResult.Type.MISS;
            if (stop) next = hit.getPos();
            if (i % 2 == 0 || stop) {
                double d = 0.04;
                Overlay3D.filled(ms, vcp, new Box(next.x - d, next.y - d, next.z - d, next.x + d, next.y + d, next.z + d),
                        1f, 0.9f, 0.3f, 0.95f);
            }
            pos = next;
            if (stop) { end = next; break; }
            vel = vel.multiply(0.99).subtract(0, grav, 0);
            if (pos.y < mc.world.getBottomY() - 10) break;
        }
        if (end != null) {
            Box b = new Box(end.x - 0.25, end.y - 0.02, end.z - 0.25, end.x + 0.25, end.y + 0.02, end.z + 0.25);
            Overlay3D.filled(ms, vcp, b, 1f, 0.3f, 0.3f, 0.6f);
            Overlay3D.outline(ms, vcp, b, 1f, 0.3f, 0.3f, 1f);
        }
    }
}
