package com.example.hhggk.module.visual;

import com.example.hhggk.module.HudText;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;

public class CompassHud extends HudText {

    public CompassHud() { super("CompassHud", Category.VISUAL, 50, 0); }

    @Override
    protected String text(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        float heading = ((p.getYaw() + 180f) % 360f + 360f) % 360f;
        String[] n = {"N", "NE", "E", "SE", "S", "SW", "W", "NW"};
        return n[Math.round(heading / 45f) % 8] + "  " + Math.round(heading) + "\u00B0";
    }
}
