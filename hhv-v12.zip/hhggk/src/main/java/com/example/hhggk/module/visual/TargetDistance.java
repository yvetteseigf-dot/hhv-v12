package com.example.hhggk.module.visual;

import com.example.hhggk.module.HudText;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;

public class TargetDistance extends HudText {

    public TargetDistance() { super("TargetDistance", Category.VISUAL, 50, 52); }

    @Override
    protected String text(MinecraftClient mc) {
        Entity t = mc.targetedEntity;
        if (t == null) return "";
        return String.format("%.2f m", mc.player.distanceTo(t));
    }
}
