package com.example.hhggk.module.movement;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

public class HighJump extends Module {
    public final Setting.Num power = add(new Setting.Num("Power", 2.0, 1.0, 4.0, 0.1));

    public HighJump() { super("HighJump", Category.MOVEMENT); }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (mc.currentScreen != null) return;
        if (mc.options.jumpKey.isPressed() && p.isOnGround()) {
            Vec3d v = p.getVelocity();
            p.setVelocity(v.x, 0.42 * power.value, v.z);
        }
    }
}
