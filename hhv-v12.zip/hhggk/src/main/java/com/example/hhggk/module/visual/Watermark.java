package com.example.hhggk.module.visual;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/** Small client name + FPS badge in the top-left corner. */
public class Watermark extends Module {
    public final Setting.Bool showFps = add(new Setting.Bool("Show FPS", true));

    public Watermark() { super("Watermark", Category.VISUAL); }

    @Override
    public void onHud(DrawContext ctx, MinecraftClient mc) {
        String s = "Diamond" + (showFps.value ? "  |  " + mc.getCurrentFps() + " fps" : "");
        int w = mc.textRenderer.getWidth(s);
        ctx.fill(4, 4, 4 + w + 10, 18, 0xB0101020);
        ctx.fill(4, 4, 6, 18, 0xFF5CE1FF);
        ctx.drawTextWithShadow(mc.textRenderer, s, 10, 8, 0xFFFFFFFF);
    }
}
