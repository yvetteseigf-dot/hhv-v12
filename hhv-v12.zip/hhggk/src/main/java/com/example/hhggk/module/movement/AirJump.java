package com.example.hhggk.module.movement;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

/** Jump again while in the air (press jump). */
public class AirJump extends Module {
    public final Setting.Num delay = add(new Setting.Num("Delay (ticks)", 8, 1, 20, 1));
    private int cd;
    private boolean was;
    public AirJump() { super("AirJump", Category.MOVEMENT); }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        boolean j = mc.currentScreen == null && mc.options.jumpKey.isPressed();
        if (cd > 0) cd--;
        if (j && !was && !p.isOnGround() && !p.isGliding() && !p.isTouchingWater() && cd == 0) {
            Vec3d v = p.getVelocity();
            p.setVelocity(v.x, 0.42, v.z);
            p.fallDistance = 0;
            cd = (int) delay.value;
        }
        was = j;
    }
}
