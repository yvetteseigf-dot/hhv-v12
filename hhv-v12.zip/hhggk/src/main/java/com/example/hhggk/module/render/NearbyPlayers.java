package com.example.hhggk.module.render;

import com.example.hhggk.module.HudText;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.client.network.AbstractClientPlayerEntity;

public class NearbyPlayers extends HudText {
    public final Setting.Num range = add(new Setting.Num("Range", 64, 8, 200, 4));
    public final Setting.Num max = add(new Setting.Num("Max shown", 6, 1, 12, 1));

    public NearbyPlayers() { super("NearbyPlayers", Category.RENDER, 100, 40); }

    @Override
    protected String text(MinecraftClient mc) {
        List<AbstractClientPlayerEntity> list = new ArrayList<>();
        for (AbstractClientPlayerEntity o : mc.world.getPlayers()) {
            if (o != mc.player && mc.player.distanceTo(o) <= range.value) list.add(o);
        }
        list.sort(Comparator.comparingDouble(o -> mc.player.distanceTo(o)));
        StringBuilder sb = new StringBuilder();
        int n = Math.min(list.size(), (int) max.value);
        for (int i = 0; i < n; i++) {
            AbstractClientPlayerEntity o = list.get(i);
            if (i > 0) sb.append('\n');
            sb.append(o.getName().getString()).append("  ").append(String.format("%.0fm", mc.player.distanceTo(o)))
              .append("  ").append(String.format("%.0fhp", o.getHealth() + o.getAbsorptionAmount()));
        }
        return sb.toString();
    }
}
