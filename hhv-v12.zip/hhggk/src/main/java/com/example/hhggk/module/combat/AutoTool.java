package com.example.hhggk.module.combat;

import com.example.hhggk.module.Inv;
import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;

/** Holds the best sword when you attack and the fastest tool when you mine. Switches back afterwards. */
public class AutoTool extends Module {
    public final Setting.Bool weapon = add(new Setting.Bool("Sword when attacking", true));
    public final Setting.Bool tools = add(new Setting.Bool("Best tool when mining", true));
    public final Setting.Bool back = add(new Setting.Bool("Switch back", true));

    private int prev = -1;

    public AutoTool() { super("AutoTool", Category.COMBAT); }

    @Override
    public void onDisable() { prev = -1; }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (mc.currentScreen != null) return;
        if (!mc.options.attackKey.isPressed()) {
            if (prev >= 0 && back.value) p.getInventory().selectedSlot = prev;
            prev = -1;
            return;
        }
        int target = -1;
        if (weapon.value && mc.targetedEntity instanceof LivingEntity) {
            int bestRank = -1;
            for (int i = 0; i < 9; i++) {
                ItemStack s = p.getInventory().getStack(i);
                if (!Inv.path(s).endsWith("_sword")) continue;
                int r = Inv.material(s);
                if (r > bestRank) { bestRank = r; target = i; }
            }
        } else if (tools.value && mc.crosshairTarget instanceof BlockHitResult b && b.getType() == HitResult.Type.BLOCK) {
            BlockState st = mc.world.getBlockState(b.getBlockPos());
            float best = 1.0f;
            for (int i = 0; i < 9; i++) {
                float sp = p.getInventory().getStack(i).getMiningSpeedMultiplier(st);
                if (sp > best) { best = sp; target = i; }
            }
        }
        if (target >= 0 && target != p.getInventory().selectedSlot) {
            if (prev < 0) prev = p.getInventory().selectedSlot;
            p.getInventory().selectedSlot = target;
        }
    }
}
