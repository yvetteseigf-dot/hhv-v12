package com.example.hhggk.module.combat;

import com.example.hhggk.module.EntityFilter;
import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import com.example.hhggk.Settings;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.math.Box;

/**
 * Before every attack with a mace the server is told you fell {height} blocks (position packets
 * up and straight back down), so the smash bonus is calculated as if you jumped from that height
 * while you stay where you are. Hooked from AttackMixin, so it works for manual hits, Aura and ElytraTarget.
 * Note: the mace smash does not work while gliding (vanilla rule) - land / stop gliding first.
 */
public class AutoMace extends Module {
    public final Setting.Num height = add(new Setting.Num("Fake fall height", 150, 10, 200, 5));
    public final Setting.Bool waitCooldown = add(new Setting.Bool("Only when charged", true));
    public final Setting.Bool playersOnly = add(new Setting.Bool("Players only", false));

    private static final double STEP = 8.0; // stay under the server's per-packet movement limit

    public AutoMace() { super("AutoMace", Category.COMBAT); }

    public void beforeAttack(MinecraftClient mc, Entity target) {
        if (!enabled || !Settings.active()) return;
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.getNetworkHandler() == null) return;
        if (!(target instanceof LivingEntity)) return;
        if (playersOnly.value && EntityFilter.kind(target, p) != 0) return;
        if (!p.getMainHandStack().isOf(Items.MACE)) return;
        if (p.isGliding() || p.hasVehicle() || p.isTouchingWater()) return;
        if (waitCooldown.value && p.getAttackCooldownProgress(0.5f) < 0.9f) return;

        // how far up is the air free (roof / world height)?
        double want = Math.min(height.value, (mc.world.getBottomY() + mc.world.getHeight()) - p.getY() - 2);
        Box base = p.getBoundingBox();
        double free = 0;
        for (double y = 1; y <= want; y += 1.0) {
            if (!mc.world.isSpaceEmpty(p, base.offset(0, y, 0))) break;
            free = y;
        }
        if (free < 2) return;

        double x = p.getX(), y = p.getY(), z = p.getZ();
        double top = y + free, cur = y;
        while (cur < top) {
            cur = Math.min(top, cur + STEP);
            send(mc, x, cur, z);
        }
        while (cur > y) {
            cur = Math.max(y, cur - STEP);
            send(mc, x, cur, z);
        }
    }

    private static void send(MinecraftClient mc, double x, double y, double z) {
        mc.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(x, y, z, false, false));
    }
}
