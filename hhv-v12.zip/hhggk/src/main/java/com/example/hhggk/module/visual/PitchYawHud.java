package com.example.hhggk.module.visual;

import com.example.hhggk.module.HudText;

import net.minecraft.client.MinecraftClient;


public class PitchYawHud extends HudText {

    public PitchYawHud() { super("PitchYawHud", Category.VISUAL, 0, 54); }

    @Override
    protected String text(MinecraftClient mc) {
        return String.format("Yaw %.1f  Pitch %.1f", mc.player.getYaw() % 360f, mc.player.getPitch());
    }
}
