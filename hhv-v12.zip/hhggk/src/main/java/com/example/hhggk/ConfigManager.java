package com.example.hhggk;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.ModuleManager;
import com.example.hhggk.module.Setting;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

/** Save / load the whole client setup (modules on/off + every setting) as a .json file. */
public class ConfigManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public static boolean validName(String n) { return n != null && n.matches("[A-Za-z0-9_\\-]{1,32}"); }

    private static Path dir() {
        Path d = FabricLoader.getInstance().getConfigDir().resolve("hhggk").resolve("configs");
        try { Files.createDirectories(d); } catch (Exception ignored) {}
        return d;
    }

    private static Path file(String name) { return dir().resolve(name + ".json"); }

    public static boolean save(String name) {
        if (!validName(name)) return false;
        try {
            JsonObject root = new JsonObject();
            for (Module m : ModuleManager.modules) {
                JsonObject mo = new JsonObject();
                mo.addProperty("enabled", m.enabled);
                JsonObject so = new JsonObject();
                for (Setting s : m.settings) so.add(s.name, s.toJson());
                mo.add("settings", so);
                root.add(m.name, mo);
            }
            Files.writeString(file(name), GSON.toJson(root));
            return true;
        } catch (Exception e) { return false; }
    }

    public static boolean load(String name) {
        if (!validName(name) || !Files.exists(file(name))) return false;
        try {
            JsonObject root = JsonParser.parseString(Files.readString(file(name))).getAsJsonObject();
            for (Module m : ModuleManager.modules) {
                if (!root.has(m.name)) continue;
                JsonObject mo = root.getAsJsonObject(m.name);
                if (mo.has("settings")) {
                    JsonObject so = mo.getAsJsonObject("settings");
                    for (Setting s : m.settings) {
                        JsonElement e = so.get(s.name);
                        if (e != null) s.fromJson(e);
                    }
                }
                if (mo.has("enabled")) {
                    boolean want = mo.get("enabled").getAsBoolean();
                    boolean skip = m == ModuleManager.freecam || m == ModuleManager.fakePlayer;
                    if (want != m.enabled && !skip && (!want || Settings.active())) m.toggle();
                }
            }
            return true;
        } catch (Exception e) { return false; }
    }

    public static boolean delete(String name) {
        if (!validName(name)) return false;
        try { return Files.deleteIfExists(file(name)); } catch (Exception e) { return false; }
    }

    public static List<String> list() {
        List<String> out = new ArrayList<>();
        try (Stream<Path> s = Files.list(dir())) {
            s.forEach(p -> {
                String n = p.getFileName().toString();
                if (n.endsWith(".json")) out.add(n.substring(0, n.length() - 5));
            });
        } catch (Exception ignored) {}
        out.sort(String::compareToIgnoreCase);
        return out;
    }
}
