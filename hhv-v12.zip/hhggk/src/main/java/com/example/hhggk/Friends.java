package com.example.hhggk;

import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

/** Friend list. Friends are never targeted by Aura / ElytraTarget / Hitbox etc. */
public class Friends {
    private static final Set<String> names = new TreeSet<>();

    private static Path file() {
        Path dir = FabricLoader.getInstance().getConfigDir().resolve("hhggk");
        try { Files.createDirectories(dir); } catch (Exception ignored) {}
        return dir.resolve("friends.txt");
    }

    public static void load() {
        names.clear();
        try {
            Path f = file();
            if (!Files.exists(f)) return;
            for (String l : Files.readAllLines(f)) {
                l = l.trim().toLowerCase();
                if (!l.isEmpty()) names.add(l);
            }
        } catch (Exception ignored) {}
    }

    private static void save() {
        try { Files.write(file(), new ArrayList<>(names)); } catch (Exception ignored) {}
    }

    public static boolean isFriend(String name) {
        return name != null && names.contains(name.toLowerCase());
    }

    public static boolean add(String name) {
        boolean r = names.add(name.toLowerCase());
        if (r) save();
        return r;
    }

    public static boolean remove(String name) {
        boolean r = names.remove(name.toLowerCase());
        if (r) save();
        return r;
    }

    public static void clear() { names.clear(); save(); }

    public static List<String> list() { return new ArrayList<>(names); }
}
