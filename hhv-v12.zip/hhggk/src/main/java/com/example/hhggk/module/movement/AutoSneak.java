package com.example.hhggk.module.movement;

import com.example.hhggk.module.Module;

import net.minecraft.client.MinecraftClient;

/** Keeps you sneaking. */
public class AutoSneak extends Module {
    public AutoSneak() { super("AutoSneak", Category.MOVEMENT); }

    @Override
    public void onTick(MinecraftClient mc) {
        if (mc.currentScreen == null) mc.options.sneakKey.setPressed(true);
    }

    @Override
    public void onDisable() {
        MinecraftClient.getInstance().options.sneakKey.setPressed(false);
    }
}
