package com.example.hhggk.module.visual;

import com.example.hhggk.module.Fx;
import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;

import java.util.concurrent.ThreadLocalRandom;

/** Burst of particles on the target every time you hit it (called from Stats.onAttack). */
public class HitParticles extends Module {
    public final Setting.Mode particle = add(new Setting.Mode("Particle", "Crit", "Flame", "Soul flame", "End rod", "Enchant", "Totem"));
    public final Setting.Num amount = add(new Setting.Num("Amount", 12, 2, 40, 1));

    public HitParticles() { super("HitParticles", Category.VISUAL); }

    public void spawn(MinecraftClient mc, LivingEntity t) {
        ThreadLocalRandom r = ThreadLocalRandom.current();
        var eff = Fx.particle(particle.get());
        for (int i = 0; i < (int) amount.value; i++) {
            Fx.add(mc, eff, t.getX() + (r.nextDouble() - 0.5) * 0.8, t.getY() + r.nextDouble() * t.getHeight(),
                    t.getZ() + (r.nextDouble() - 0.5) * 0.8,
                    (r.nextDouble() - 0.5) * 0.4, r.nextDouble() * 0.3, (r.nextDouble() - 0.5) * 0.4);
        }
    }
}
