package com.example.hhggk.module;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.concurrent.ThreadLocalRandom;

/** Block placing + hole detection used by Surround, AutoTrap, Scaffold, HoleFill, Burrow, AutoCrystal... */
public class BlockUtil {
    public static final Direction[] SIDES = {Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST};

    public static boolean solid(MinecraftClient mc, BlockPos pos) {
        BlockState s = mc.world.getBlockState(pos);
        return !s.isAir() && !s.isReplaceable() && !s.getCollisionShape(mc.world, pos).isEmpty();
    }

    public static boolean blastProof(MinecraftClient mc, BlockPos pos) {
        Block b = mc.world.getBlockState(pos).getBlock();
        return b == Blocks.OBSIDIAN || b == Blocks.BEDROCK || b == Blocks.CRYING_OBSIDIAN
                || b == Blocks.NETHERITE_BLOCK || b == Blocks.ENDER_CHEST || b == Blocks.RESPAWN_ANCHOR;
    }

    public static boolean entityFree(MinecraftClient mc, BlockPos pos) {
        return mc.world.getOtherEntities(null, new Box(pos),
                e -> !(e instanceof ItemEntity) && e.isAlive() && !e.isSpectator()).isEmpty();
    }

    public static boolean canPlace(MinecraftClient mc, BlockPos pos) {
        return mc.world.getBlockState(pos).isReplaceable() && entityFree(mc, pos);
    }

    /** A 1x1 hole: free feet + head, solid floor, blast-proof walls on 4 sides. */
    public static boolean isHole(MinecraftClient mc, BlockPos pos) {
        if (!mc.world.getBlockState(pos).isAir() || !mc.world.getBlockState(pos.up()).isAir()) return false;
        if (!solid(mc, pos.down())) return false;
        for (Direction d : SIDES) if (!blastProof(mc, pos.offset(d))) return false;
        return true;
    }

    /** True if every wall + the floor is bedrock (the safest kind of hole). */
    public static boolean isBedrockHole(MinecraftClient mc, BlockPos pos) {
        if (mc.world.getBlockState(pos.down()).getBlock() != Blocks.BEDROCK) return false;
        for (Direction d : SIDES) if (mc.world.getBlockState(pos.offset(d)).getBlock() != Blocks.BEDROCK) return false;
        return true;
    }

    /**
     * Places the block that is in the given HOTBAR slot at pos (against any solid neighbour).
     * Returns true if a place packet was sent. The previous slot is restored.
     */
    public static boolean place(MinecraftClient mc, BlockPos pos, int slot) {
        ClientPlayerEntity p = mc.player;
        if (mc.interactionManager == null || slot < 0 || !canPlace(mc, pos)) return false;
        Direction face = null;
        BlockPos support = null;
        for (Direction d : Direction.values()) {
            BlockPos n = pos.offset(d);
            if (solid(mc, n)) { face = d.getOpposite(); support = n; break; }
        }
        if (support == null) return false;
        Vec3d hit = Vec3d.ofCenter(support).add(face.getOffsetX() * 0.5, face.getOffsetY() * 0.5, face.getOffsetZ() * 0.5);
        int prev = p.getInventory().selectedSlot;
        p.getInventory().selectedSlot = slot;
        mc.interactionManager.interactBlock(p, Hand.MAIN_HAND, new BlockHitResult(hit, face, support, false));
        p.swingHand(Hand.MAIN_HAND);
        p.getInventory().selectedSlot = prev;
        return true;
    }

    /**
     * Anticheat-friendly placement ("server with protection"):
     *  - only against a face that is really visible from your eyes (strict direction)
     *  - the line eye -> hit point must reach exactly that support block (no placing through walls)
     *  - hit point within {@code reach}
     *  - optional: the rotation is sent to the server before the click, like a real player aiming
     *  - optional: hit point slightly different each time
     * Returns true if a place packet was sent.
     */
    public static boolean placeStrict(MinecraftClient mc, BlockPos pos, int slot, double reach,
                                      boolean rotate, boolean jitter) {
        ClientPlayerEntity p = mc.player;
        if (mc.interactionManager == null || mc.getNetworkHandler() == null || mc.world == null
                || slot < 0 || !canPlace(mc, pos)) return false;
        Vec3d eye = p.getEyePos();

        Direction bestFace = null;
        BlockPos bestSupport = null;
        Vec3d bestHit = null;
        double bestD = Double.MAX_VALUE;
        ThreadLocalRandom rnd = ThreadLocalRandom.current();

        for (Direction d : Direction.values()) {
            BlockPos support = pos.offset(d);
            if (!solid(mc, support)) continue;
            Direction face = d.getOpposite();                 // face of the support block that touches pos
            Vec3d c = Vec3d.ofCenter(support).add(face.getOffsetX() * 0.5, face.getOffsetY() * 0.5, face.getOffsetZ() * 0.5);

            // eye has to be on the outer side of that face
            double side;
            if (face.getOffsetX() != 0) side = (eye.x - c.x) * face.getOffsetX();
            else if (face.getOffsetY() != 0) side = (eye.y - c.y) * face.getOffsetY();
            else side = (eye.z - c.z) * face.getOffsetZ();
            if (side <= 0) continue;

            Vec3d hit = c;
            if (jitter) {
                double a = rnd.nextDouble(-0.25, 0.25), b = rnd.nextDouble(-0.25, 0.25);
                if (face.getOffsetX() != 0) hit = c.add(0, a, b);
                else if (face.getOffsetY() != 0) hit = c.add(a, 0, b);
                else hit = c.add(a, b, 0);
            }
            double dist = eye.distanceTo(hit);
            if (dist > reach || dist < 0.01) continue;

            // line of sight: the first thing the ray touches must be the support block
            Vec3d dir = hit.subtract(eye).normalize();
            Vec3d end = hit.add(dir.multiply(0.05));
            BlockHitResult r = mc.world.raycast(new RaycastContext(eye, end,
                    RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, p));
            if (r.getType() != HitResult.Type.BLOCK || !r.getBlockPos().equals(support)) continue;

            if (dist < bestD) { bestD = dist; bestFace = face; bestSupport = support; bestHit = hit; }
        }
        if (bestSupport == null) return false;

        if (rotate) {
            float yaw = Rot.yawTo(eye, bestHit);
            float pitch = Rot.pitchTo(eye, bestHit);
            mc.getNetworkHandler().sendPacket(
                    new PlayerMoveC2SPacket.LookAndOnGround(yaw, pitch, p.isOnGround(), p.horizontalCollision));
        }
        int prev = p.getInventory().selectedSlot;
        p.getInventory().selectedSlot = slot;
        mc.interactionManager.interactBlock(p, Hand.MAIN_HAND, new BlockHitResult(bestHit, bestFace, bestSupport, false));
        p.swingHand(Hand.MAIN_HAND);
        p.getInventory().selectedSlot = prev;
        return true;
    }
}
