package com.example.hhggk.module.movement;

import com.example.hhggk.module.BlockUtil;
import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.block.BlockWithEntity;
import net.minecraft.block.FallingBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

/** Places blocks under your feet while you walk / bridge. Uses full solid blocks from your hotbar. */
public class Scaffold extends Module {
    public final Setting.Num ahead = add(new Setting.Num("Look ahead (ticks)", 2, 0, 6, 1));
    public final Setting.Bool tower = add(new Setting.Bool("Tower (hold jump)", true));

    private int cd;

    public Scaffold() { super("Scaffold", Category.MOVEMENT); }

    private boolean usable(MinecraftClient mc, ItemStack s) {
        if (!(s.getItem() instanceof BlockItem bi)) return false;
        if (bi.getBlock() instanceof FallingBlock || bi.getBlock() instanceof BlockWithEntity) return false;
        return bi.getBlock().getDefaultState().isFullCube(mc.world, BlockPos.ORIGIN);
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (mc.currentScreen != null || p.getAbilities().flying || p.isGliding()) return;
        int slot = -1;
        for (int i = 0; i < 9; i++) if (usable(mc, p.getInventory().getStack(i))) { slot = i; break; }
        if (slot < 0) return;
        Vec3d v = p.getVelocity();
        double t = ahead.value;
        BlockPos pos = BlockPos.ofFloored(p.getX() + v.x * t, p.getY() - 1.0, p.getZ() + v.z * t);
        BlockUtil.place(mc, pos, slot);
        if (tower.value && mc.options.jumpKey.isPressed() && !mc.options.forwardKey.isPressed()
                && !p.isOnGround() && v.y < 0.2 && BlockUtil.solid(mc, BlockPos.ofFloored(p.getX(), p.getY() - 1.0, p.getZ()))) {
            p.setVelocity(v.x, 0.42, v.z);
        }
    }
}
