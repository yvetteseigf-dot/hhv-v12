package com.example.hhggk.module.visual;

import com.example.hhggk.module.HudText;

import net.minecraft.client.MinecraftClient;


public class VelocityHud extends HudText {

    public VelocityHud() { super("VelocityHud", Category.VISUAL, 0, 84); }

    @Override
    protected String text(MinecraftClient mc) {
        return String.format("Vy %.2f", mc.player.getVelocity().y);
    }
}
