package com.example.hhggk.module.visual;

import com.example.hhggk.module.HudText;

import net.minecraft.client.MinecraftClient;


public class SessionTime extends HudText {
    private long start = System.currentTimeMillis();

    @Override public void onEnable() { start = System.currentTimeMillis(); }

    public SessionTime() { super("SessionTime", Category.VISUAL, 100, 12); }

    @Override
    protected String text(MinecraftClient mc) {
        long s = (System.currentTimeMillis() - start) / 1000L;
        return String.format("%02d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60);
    }
}
