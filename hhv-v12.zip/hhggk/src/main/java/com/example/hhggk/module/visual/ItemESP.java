package com.example.hhggk.module.visual;

import com.example.hhggk.module.Drawable3D;
import com.example.hhggk.module.Inv;
import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;
import com.example.hhggk.render.Overlay3D;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

/** Boxes around dropped items. Totems, gapples, crystals, pearls, elytra and netherite gear are yellow. */
public class ItemESP extends Module implements Drawable3D {
    public final Setting.Num range = add(new Setting.Num("Range", 40, 5, 120, 5));
    public final Setting.Bool onlyValuable = add(new Setting.Bool("Only valuable", false));

    public ItemESP() { super("ItemESP", Category.VISUAL); }

    private static boolean valuable(ItemStack s) {
        return s.isOf(Items.TOTEM_OF_UNDYING) || s.isOf(Items.ENCHANTED_GOLDEN_APPLE) || s.isOf(Items.GOLDEN_APPLE)
                || s.isOf(Items.END_CRYSTAL) || s.isOf(Items.ENDER_PEARL) || s.isOf(Items.ELYTRA)
                || s.isOf(Items.OBSIDIAN) || s.isOf(Items.MACE) || Inv.path(s).startsWith("netherite_");
    }

    @Override
    public void draw3d(MinecraftClient mc, MatrixStack ms, VertexConsumerProvider vcp, Vec3d cam, float td) {
        double r = range.value;
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof ItemEntity ie) || mc.player.squaredDistanceTo(e) > r * r) continue;
            boolean v = valuable(ie.getStack());
            if (onlyValuable.value && !v) continue;
            Vec3d off = e.getLerpedPos(td).subtract(e.getPos());
            Box b = e.getBoundingBox().offset(off).expand(0.08);
            if (v) {
                Overlay3D.filled(ms, vcp, b, 1f, 0.85f, 0.15f, 0.3f);
                Overlay3D.outline(ms, vcp, b, 1f, 0.85f, 0.15f, 1f);
            } else {
                Overlay3D.outline(ms, vcp, b, 0.9f, 0.9f, 0.9f, 1f);
            }
        }
    }
}
