package com.example.hhggk.module.movement;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

/** Swim faster. */
public class WaterSpeed extends Module {
    public final Setting.Num factor = add(new Setting.Num("Speed factor", 1.15, 1.0, 2.0, 0.05));
    public WaterSpeed() { super("WaterSpeed", Category.MOVEMENT); }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (!p.isTouchingWater() || p.isGliding()) return;
        Vec3d v = p.getVelocity();
        p.setVelocity(v.x * factor.value, v.y, v.z * factor.value);
    }
}
