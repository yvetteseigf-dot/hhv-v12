package com.example.hhggk.module.render;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.ModuleManager;
import com.example.hhggk.module.combat.Aura;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;

public class TargetHud extends Module {
    public TargetHud() { super("TargetHUD", Category.RENDER); }

    @Override
    public void onHud(DrawContext ctx, MinecraftClient mc) {
        LivingEntity t = null;
        Aura a = ModuleManager.aura;
        if (a != null && a.lastTarget != null && a.lastTarget.isAlive()
                && System.currentTimeMillis() - a.lastHit < 3000) t = a.lastTarget;
        if (t == null) {
            Entity e = mc.targetedEntity;
            if (e instanceof LivingEntity le && le.isAlive()) t = le;
        }
        if (t == null) return;

        int x = ctx.getScaledWindowWidth() / 2 + 30, y = ctx.getScaledWindowHeight() / 2 + 10;
        float hp = t.getHealth(), max = Math.max(1f, t.getMaxHealth());
        ctx.fill(x, y, x + 110, y + 34, 0xA0101018);
        ctx.drawTextWithShadow(mc.textRenderer, t.getName().getString(), x + 4, y + 4, 0xFFFFFFFF);
        ctx.fill(x + 4, y + 18, x + 106, y + 26, 0xFF301010);
        int fw = (int) (102 * Math.min(1f, hp / max));
        ctx.fill(x + 4, y + 18, x + 4 + fw, y + 26, hp / max > 0.5f ? 0xFF3AC84A : 0xFFD8483A);
        ctx.drawTextWithShadow(mc.textRenderer, String.format("%.1f HP", hp), x + 4, y + 26 - 1 + 1, 0xFFBBBBBB);
    }
}
