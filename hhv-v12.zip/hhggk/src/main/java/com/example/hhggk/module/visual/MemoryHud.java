package com.example.hhggk.module.visual;

import com.example.hhggk.module.HudText;

import net.minecraft.client.MinecraftClient;


public class MemoryHud extends HudText {

    public MemoryHud() { super("MemoryHud", Category.VISUAL, 100, 62); }

    @Override
    protected String text(MinecraftClient mc) {
        Runtime r = Runtime.getRuntime();
        long used = (r.totalMemory() - r.freeMemory()) / 1048576L;
        return "Mem " + used + "/" + (r.maxMemory() / 1048576L) + " MB";
    }
}
