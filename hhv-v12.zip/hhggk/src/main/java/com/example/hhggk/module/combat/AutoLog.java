package com.example.hhggk.module.combat;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

/** Leaves the server when your health gets too low. */
public class AutoLog extends Module {
    public final Setting.Num health = add(new Setting.Num("Leave below (hp)", 6, 1, 19, 1));

    public AutoLog() { super("AutoLog", Category.COMBAT); }

    @Override
    public void onTick(MinecraftClient mc) {
        if (mc.getNetworkHandler() == null || mc.isInSingleplayer()) return;
        if (mc.player.getHealth() + mc.player.getAbsorptionAmount() < health.value) {
            enabled = false;
            mc.getNetworkHandler().getConnection().disconnect(Text.literal("[Diamond] AutoLog: health " + mc.player.getHealth()));
        }
    }
}
