package com.example.hhggk.module.visual;

import com.example.hhggk.module.HudText;

import net.minecraft.client.MinecraftClient;


public class HealthText extends HudText {

    public HealthText() { super("HealthText", Category.VISUAL, 50, 56); }

    @Override
    protected String text(MinecraftClient mc) {
        float hp = mc.player.getHealth(), ab = mc.player.getAbsorptionAmount();
        return String.format("%.1f", hp) + (ab > 0 ? " +" + String.format("%.1f", ab) : "");
    }

    @Override
    protected int color(MinecraftClient mc) {
        float hp = mc.player.getHealth();
        return hp > 14 ? 0xFF55FF55 : hp > 7 ? 0xFFFFFF55 : 0xFFFF5555;
    }
}
