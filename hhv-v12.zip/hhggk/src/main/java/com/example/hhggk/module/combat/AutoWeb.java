package com.example.hhggk.module.combat;

import com.example.hhggk.module.BlockUtil;
import com.example.hhggk.module.EntityFilter;
import com.example.hhggk.module.Inv;
import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;

/** Throws cobwebs onto the closest enemy (feet, and head if you want). */
public class AutoWeb extends Module {
    public final Setting.Num range = add(new Setting.Num("Range", 4.5, 2, 6, 0.1));
    public final Setting.Bool head = add(new Setting.Bool("Also head", true));

    public AutoWeb() { super("AutoWeb", Category.COMBAT); }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        int slot = Inv.hotbar(p, Items.COBWEB);
        if (slot < 0) return;
        PlayerEntity t = null;
        double bd = range.value * range.value;
        for (PlayerEntity e : mc.world.getPlayers()) {
            if (EntityFilter.kind(e, p) != 0 || !e.isAlive()) continue;
            double d = p.squaredDistanceTo(e);
            if (d <= bd) { bd = d; t = e; }
        }
        if (t == null) return;
        BlockPos feet = BlockPos.ofFloored(t.getX(), t.getY() + 0.1, t.getZ());
        if (BlockUtil.place(mc, feet, slot)) return;
        if (head.value) BlockUtil.place(mc, feet.up(), slot);
    }
}
