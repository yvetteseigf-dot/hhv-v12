package com.example.hhggk.module.visual;

import com.example.hhggk.module.HudText;

import net.minecraft.client.MinecraftClient;
import net.minecraft.item.ItemStack;

public class HeldItemInfo extends HudText {

    public HeldItemInfo() { super("HeldItemInfo", Category.VISUAL, 50, 80); }

    @Override
    protected String text(MinecraftClient mc) {
        ItemStack s = mc.player.getMainHandStack();
        if (s.isEmpty()) return "";
        String r = s.getName().getString();
        if (s.isDamageable()) r += "  " + (s.getMaxDamage() - s.getDamage()) + "/" + s.getMaxDamage();
        else if (s.getCount() > 1) r += "  x" + s.getCount();
        return r;
    }
}
