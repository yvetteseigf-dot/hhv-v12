package com.example.hhggk.module.misc;

import com.example.hhggk.Friends;
import com.example.hhggk.module.Inv;
import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;

/** Middle click: on a player = add / remove friend, otherwise = throw an ender pearl from the hotbar. */
public class MiddleClick extends Module {
    public final Setting.Bool friend = add(new Setting.Bool("Friend on player", true));
    public final Setting.Bool pearl = add(new Setting.Bool("Pearl otherwise", true));

    private boolean was;

    public MiddleClick() { super("MiddleClick", Category.MISC); }

    @Override
    public void onTick(MinecraftClient mc) {
        boolean down = mc.options.pickItemKey.isPressed() && mc.currentScreen == null;
        boolean edge = down && !was;
        was = down;
        if (!edge || mc.interactionManager == null) return;
        ClientPlayerEntity p = mc.player;
        if (friend.value && mc.targetedEntity instanceof PlayerEntity pe) {
            String n = pe.getName().getString();
            if (Friends.isFriend(n)) { Friends.remove(n); p.sendMessage(Text.literal("[Diamond] Removed friend " + n), true); }
            else { Friends.add(n); p.sendMessage(Text.literal("[Diamond] Added friend " + n), true); }
            return;
        }
        if (!pearl.value) return;
        int slot = Inv.hotbar(p, Items.ENDER_PEARL);
        if (slot < 0) return;
        int prev = p.getInventory().selectedSlot;
        p.getInventory().selectedSlot = slot;
        mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
        p.swingHand(Hand.MAIN_HAND);
        p.getInventory().selectedSlot = prev;
    }
}
