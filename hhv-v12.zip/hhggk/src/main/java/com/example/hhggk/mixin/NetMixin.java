package com.example.hhggk.mixin;

import com.example.hhggk.Settings;
import com.example.hhggk.module.ModuleManager;
import com.example.hhggk.module.combat.PopCounter;
import com.example.hhggk.module.combat.Velocity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.entity.Entity;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Velocity (anti knockback) and PopCounter. Loaded from the optional mixin config (never crashes the game). */
@Mixin(ClientPlayNetworkHandler.class)
public class NetMixin {
    @Unique private Vec3d hhggk$before;

    @Inject(method = "onEntityVelocityUpdate", at = @At("HEAD"))
    private void hhggk$velHead(EntityVelocityUpdateS2CPacket packet, CallbackInfo ci) {
        MinecraftClient mc = MinecraftClient.getInstance();
        hhggk$before = (mc.player != null && mc.isOnThread() && packet.getEntityId() == mc.player.getId())
                ? mc.player.getVelocity() : null;
    }

    @Inject(method = "onEntityVelocityUpdate", at = @At("TAIL"))
    private void hhggk$velTail(EntityVelocityUpdateS2CPacket packet, CallbackInfo ci) {
        MinecraftClient mc = MinecraftClient.getInstance();
        Velocity v = ModuleManager.velocity;
        if (hhggk$before != null && mc.player != null && v != null && v.enabled && Settings.active()) {
            Vec3d after = mc.player.getVelocity();
            Vec3d d = after.subtract(hhggk$before);
            double h = v.horizontal.value / 100.0, vv = v.vertical.value / 100.0;
            mc.player.setVelocity(hhggk$before.x + d.x * h, hhggk$before.y + d.y * vv, hhggk$before.z + d.z * h);
        }
        hhggk$before = null;
    }

    @Inject(method = "onEntityStatus", at = @At("HEAD"))
    private void hhggk$status(EntityStatusS2CPacket packet, CallbackInfo ci) {
        MinecraftClient mc = MinecraftClient.getInstance();
        PopCounter pc = ModuleManager.popCounter;
        if (pc == null || !pc.enabled || mc.world == null || !mc.isOnThread() || !Settings.active()) return;
        if (packet.getStatus() != 35) return;
        Entity e = packet.getEntity(mc.world);
        if (e != null) pc.onPop(mc, e);
    }
}
