package com.example.hhggk.module.visual;

import com.example.hhggk.module.Setting;
import com.example.hhggk.module.TargetModule;

/** Dotted line from your crosshair to every target. Drawn in WorldRender. */
public class Tracers extends TargetModule {
    public final Setting.Num range = add(new Setting.Num("Range", 120, 10, 300, 10));
    public final Setting.Num dots = add(new Setting.Num("Dots per line", 24, 8, 60, 2));

    public Tracers() { super("Tracers", Category.VISUAL, true, false, false, false); }
}
