package com.example.hhggk;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.ModuleManager;
import com.example.hhggk.module.Setting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public class ClickGui extends Screen {
    private static final int MODULE = 0, SETTING = 1, UP = 2, DOWN = 3;
    private static final int ROW_H = 23, BOOL_H = 24, NUM_H = 38;
    private static final int[] HEADER = {0xFF7C3AED, 0xFF2563EB, 0xFFDB2777, 0xFF0891B2, 0xFF059669};
    private static final int ACCENT = 0xFFB794FF;
    private static final int PANEL_BG = 0xE60A0A14, BORDER = 0xFF6D4AFF;
    private static final int ROW_OFF = 0xCC14141F, ROW_HOV = 0xFF2A2650, SET_BG = 0xCC0B0B16;
    private static final int TEXT = 0xFFFFFFFF, DIM = 0xFFFFFFFF;

    private static class Row {
        int type, x, y, w, h, panel;
        Module m;
        Setting s;
        Row(int type, Module m, Setting s, int x, int y, int w, int h, int panel) {
            this.type = type; this.m = m; this.s = s;
            this.x = x; this.y = y; this.w = w; this.h = h; this.panel = panel;
        }
    }

    private final List<Row> rows = new ArrayList<>();
    private final Module.Category[] cats = Module.Category.values();
    private final double[] scroll = new double[cats.length];
    private final double[] maxScroll = new double[cats.length];
    private int bodyTop, bodyBot, px0, pw;
    private final int gap = 8;

    private Row dragNum;
    private Row holdRow;
    private int holdDir;
    private long holdStart, lastRepeat;

    public ClickGui() { super(Text.literal("Diamond")); }

    @Override
    public boolean shouldPause() { return false; }

    private static Text bold(String s) { return Text.literal(s).formatted(Formatting.BOLD); }

    private String fit(String s, int maxW) {
        if (textRenderer.getWidth(s) <= maxW) return s;
        return textRenderer.trimToWidth(s, Math.max(4, maxW - 8)) + "..";
    }

    /** rectangle with notched corners */
    private static void rect(DrawContext c, int x, int y, int w, int h, int col) {
        c.fill(x + 1, y, x + w - 1, y + h, col);
        c.fill(x, y + 1, x + w, y + h - 1, col);
    }

    private static int settingH(Setting s) { return s instanceof Setting.Num ? NUM_H : BOOL_H; }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        ctx.fillGradient(0, 0, width, height, 0xD0120826, 0xE00A1030);
        rows.clear();

        // hold-to-repeat on the + / - buttons
        if (holdRow != null && holdRow.s instanceof Setting.Num n) {
            long now = System.currentTimeMillis();
            if (now - holdStart > 350 && now - lastRepeat > 55) { n.add(holdDir * n.step); lastRepeat = now; }
        }

        pw = Math.min(165, (width - 24 - (cats.length - 1) * gap) / cats.length);
        int total = cats.length * pw + (cats.length - 1) * gap;
        px0 = (width - total) / 2;

        int enabledCount = 0;
        for (Module m : ModuleManager.modules) if (m.enabled) enabledCount++;
        ctx.drawCenteredTextWithShadow(textRenderer, bold("D I A M O N D"), width / 2, 5, ACCENT);
        ctx.drawCenteredTextWithShadow(textRenderer, enabledCount + " modules enabled", width / 2, 15, DIM);

        int y0 = 28;
        bodyTop = y0 + 22;
        bodyBot = height - 28;

        for (int i = 0; i < cats.length; i++) {
            int px = px0 + i * (pw + gap);
            int hc = HEADER[i % HEADER.length];

            // panel
            rect(ctx, px - 1, y0 - 1, pw + 2, bodyBot - y0 + 2, BORDER);
            rect(ctx, px, y0, pw, bodyBot - y0, PANEL_BG);
            // header
            ctx.fillGradient(px, y0, px + pw, y0 + 20, hc, 0xFF000000 | ((hc >> 1) & 0x7F7F7F));
            ctx.fill(px, y0 + 19, px + pw, y0 + 21, hc);
            ctx.drawTextWithShadow(textRenderer, bold(cats[i].label.toUpperCase()), px + 7, y0 + 6, TEXT);

            // scroll buttons
            rows.add(new Row(UP, null, null, px + pw - 33, y0 + 3, 14, 14, i));
            rows.add(new Row(DOWN, null, null, px + pw - 17, y0 + 3, 14, 14, i));
            ctx.fill(px + pw - 33, y0 + 3, px + pw - 19, y0 + 17, 0x70000000);
            ctx.fill(px + pw - 17, y0 + 3, px + pw - 3, y0 + 17, 0x70000000);
            ctx.drawCenteredTextWithShadow(textRenderer, "^", px + pw - 26, y0 + 6, TEXT);
            ctx.drawCenteredTextWithShadow(textRenderer, "v", px + pw - 10, y0 + 6, TEXT);

            ctx.enableScissor(px, bodyTop, px + pw, bodyBot);
            int startY = bodyTop + 3 - (int) scroll[i];
            int y = startY;
            for (Module m : ModuleManager.modules) {
                if (m.category != cats[i]) continue;

                int rx = px + 4, rw = pw - 8;
                boolean hov = mx >= rx && mx < rx + rw && my >= y && my < y + ROW_H - 1
                        && my >= bodyTop && my <= bodyBot;
                int bg = m.enabled ? (hov ? 0xFF5B3FC4 : 0xFF4B2FA8) : (hov ? ROW_HOV : ROW_OFF);
                rect(ctx, rx, y, rw, ROW_H - 1, bg);
                ctx.fill(rx, y + 1, rx + 3, y + ROW_H - 2, m.enabled ? ACCENT : 0xFF3F4160);
                rows.add(new Row(MODULE, m, null, rx, y, rw, ROW_H - 1, i));

                String bindTxt = m.bind == null ? "" : "[" + fit(Binds.label(m.bind), 40) + "]";
                int bindW = bindTxt.isEmpty() ? 0 : textRenderer.getWidth(bindTxt) + 4;
                int nameMax = rw - (m.settings.isEmpty() ? 14 : 30) - bindW;
                Text name = bold(fit(m.name, nameMax));
                ctx.drawTextWithShadow(textRenderer, name, rx + 9, y + 7, m.enabled ? 0xFFFFFFFF : 0xFFC8C8D8);
                if (!bindTxt.isEmpty()) {
                    ctx.drawTextWithShadow(textRenderer, bindTxt,
                            rx + rw - (m.settings.isEmpty() ? 4 : 21) - bindW + 4, y + 7, 0xFFFFD36B);
                }
                if (!m.settings.isEmpty()) {
                    ctx.fill(rx + rw - 18, y + 3, rx + rw - 3, y + ROW_H - 4, 0x66000000);
                    ctx.drawCenteredTextWithShadow(textRenderer, m.expanded ? "-" : "+", rx + rw - 10, y + 7, TEXT);
                }
                y += ROW_H;

                if (m.expanded) {
                    int boxTop = y;
                    for (Setting s : m.settings) {
                        int sx = px + 10, sw = pw - 16, sh = settingH(s);
                        rows.add(new Row(SETTING, m, s, sx, y, sw, sh, i));
                        drawSetting(ctx, s, sx, y, sw, sh, mx, my);
                        y += sh;
                    }
                    ctx.fill(px + 6, boxTop, px + 8, y, ACCENT);
                    y += 4;
                }
            }
            ctx.disableScissor();
            maxScroll[i] = Math.max(0, (y - startY) + 6 - (bodyBot - bodyTop));
            scroll[i] = Math.max(0, Math.min(maxScroll[i], scroll[i]));
        }

        boolean on = Settings.active();
        ctx.drawTextWithShadow(textRenderer,
                on ? Text.literal("ACTIVE").formatted(Formatting.GREEN, Formatting.BOLD)
                        : Text.literal("LOCKED - type .server add in chat").formatted(Formatting.RED, Formatting.BOLD),
                px0, height - 22, TEXT);
        ctx.drawTextWithShadow(textRenderer,
                "Click = on/off   Right click or + = settings   - / + buttons = change (Shift = x5)   Chat: .help",
                px0, height - 11, DIM);
    }

    private void drawSetting(DrawContext ctx, Setting s, int x, int y, int w, int h, int mx, int my) {
        rect(ctx, x, y, w, h - 2, SET_BG);
        if (s instanceof Setting.Bool b) {
            int pillW = 26, pillX = x + w - pillW - 5;
            ctx.drawTextWithShadow(textRenderer, bold(fit(b.name, w - pillW - 18)), x + 6, y + 7, TEXT);
            rect(ctx, pillX, y + 5, pillW, 11, b.value ? 0xFF1F9D55 : 0xFF5A2B33);
            int kx = b.value ? pillX + pillW - 10 : pillX + 2;
            rect(ctx, kx, y + 7, 8, 7, 0xFFFFFFFF);
        } else if (s instanceof Setting.Mode md) {
            String val = md.get();
            int vw = textRenderer.getWidth(val);
            ctx.drawTextWithShadow(textRenderer, bold(fit(md.name, w - vw - 24)), x + 6, y + 7, TEXT);
            rect(ctx, x + w - vw - 14, y + 4, vw + 10, 13, 0xFF4A3B14);
            ctx.drawTextWithShadow(textRenderer, val, x + w - vw - 9, y + 7, 0xFFFFD36B);
        } else if (s instanceof Setting.BlockPick bp) {
            String val = bp.label().getString();
            int vw = Math.min(textRenderer.getWidth(val), w / 2);
            ctx.drawTextWithShadow(textRenderer, bold(fit(bp.name, w - vw - 44)), x + 6, y + 7, TEXT);
            rect(ctx, x + w - vw - 32, y + 3, vw + 28, 17, 0xFF1F3A4A);
            ctx.drawItem(new net.minecraft.item.ItemStack(bp.item()), x + w - vw - 30, y + 3);
            ctx.drawTextWithShadow(textRenderer, fit(val, vw), x + w - vw - 11, y + 7, 0xFF8BE3FF);
        } else if (s instanceof Setting.Num n) {
            String val = n.text();
            int vw = textRenderer.getWidth(val);
            ctx.drawTextWithShadow(textRenderer, bold(fit(n.name, w - vw - 18)), x + 6, y + 5, TEXT);
            ctx.drawTextWithShadow(textRenderer, val, x + w - vw - 6, y + 4, ACCENT);

            int by = y + 17;
            // [-] button
            boolean hm = mx >= x + 5 && mx < x + 19 && my >= by && my < by + 14;
            rect(ctx, x + 5, by, 14, 14, hm ? 0xFF55587F : 0xFF35375A);
            ctx.drawCenteredTextWithShadow(textRenderer, "-", x + 12, by + 3, TEXT);
            // [+] button
            boolean hp = mx >= x + w - 19 && mx < x + w - 5 && my >= by && my < by + 14;
            rect(ctx, x + w - 19, by, 14, 14, hp ? 0xFF55587F : 0xFF35375A);
            ctx.drawCenteredTextWithShadow(textRenderer, "+", x + w - 12, by + 3, TEXT);
            // slider
            int tx = x + 24, tw = w - 48, ty = by + 5;
            ctx.fill(tx, ty, tx + tw, ty + 4, 0xFF2A2C46);
            int fw = (int) (tw * (n.value - n.min) / (n.max - n.min));
            ctx.fill(tx, ty, tx + fw, ty + 4, ACCENT);
            ctx.fill(tx + fw - 2, ty - 2, tx + fw + 2, ty + 6, 0xFFFFFFFF);
        }
    }

    private void setNum(Setting.Num n, Row r, double mx) {
        double t = Math.max(0, Math.min(1, (mx - (r.x + 24)) / (double) (r.w - 48)));
        n.set(n.min + t * (n.max - n.min));
    }

    private boolean hit(Row r, double mx, double my) {
        return mx >= r.x && mx < r.x + r.w && my >= r.y && my < r.y + r.h;
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        for (Row r : rows) {
            if ((r.type == UP || r.type == DOWN) && hit(r, mx, my)) {
                scroll[r.panel] = Math.max(0, Math.min(maxScroll[r.panel],
                        scroll[r.panel] + (r.type == UP ? -34 : 34)));
                return true;
            }
        }
        if (my >= bodyTop && my <= bodyBot) {
            for (Row r : rows) {
                if ((r.type == MODULE || r.type == SETTING) && hit(r, mx, my)) {
                    if (r.type == MODULE) {
                        boolean arrow = mx >= r.x + r.w - 18 && !r.m.settings.isEmpty();
                        if (button == 1 || arrow) r.m.expanded = !r.m.expanded;
                        else if (Settings.active()) r.m.toggle();
                    } else if (r.s instanceof Setting.Bool b) {
                        b.value = !b.value;
                    } else if (r.s instanceof Setting.BlockPick bp) {
                        client.setScreen(new BlockPickerScreen(this, bp));
                    } else if (r.s instanceof Setting.Mode md) {
                        if (button == 1) md.prev(); else md.next();
                    } else if (r.s instanceof Setting.Num n) {
                        double step = n.step * (hasShiftDown() ? 5 : 1);
                        boolean lowerRow = my >= r.y + 15;
                        if (lowerRow && mx < r.x + 21) {
                            n.add(-step); holdRow = r; holdDir = -1;
                            holdStart = System.currentTimeMillis(); lastRepeat = holdStart;
                        } else if (lowerRow && mx >= r.x + r.w - 21) {
                            n.add(step); holdRow = r; holdDir = 1;
                            holdStart = System.currentTimeMillis(); lastRepeat = holdStart;
                        } else {
                            dragNum = r;
                            setNum(n, r, mx);
                        }
                    }
                    return true;
                }
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragNum != null && dragNum.s instanceof Setting.Num n) {
            setNum(n, dragNum, mx);
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        dragNum = null;
        holdRow = null;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double hAmount, double vAmount) {
        for (int i = 0; i < cats.length; i++) {
            int px = px0 + i * (pw + gap);
            if (mx >= px && mx < px + pw) {
                scroll[i] = Math.max(0, Math.min(maxScroll[i], scroll[i] - vAmount * 16));
                return true;
            }
        }
        return super.mouseScrolled(mx, my, hAmount, vAmount);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_P) { close(); return true; }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
}
