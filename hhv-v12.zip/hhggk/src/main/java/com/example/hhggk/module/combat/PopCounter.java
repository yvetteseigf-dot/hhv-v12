package com.example.hhggk.module.combat;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.HashMap;
import java.util.Map;

/** Chat message every time a player pops a totem, with their pop count. Fed by NetMixin. */
public class PopCounter extends Module {
    public final Setting.Bool self = add(new Setting.Bool("Count myself", false));
    private final Map<String, Integer> pops = new HashMap<>();

    public PopCounter() { super("PopCounter", Category.COMBAT); }

    @Override
    public void onDisable() { pops.clear(); }

    public void onPop(MinecraftClient mc, Entity e) {
        if (!(e instanceof PlayerEntity pe) || mc.inGameHud == null) return;
        if (pe == mc.player && !self.value) return;
        String n = pe.getName().getString();
        int c = pops.merge(n, 1, Integer::sum);
        mc.inGameHud.getChatHud().addMessage(Text.literal("[Diamond] ").formatted(Formatting.AQUA)
                .append(Text.literal(n + " popped a totem (" + c + ")").formatted(Formatting.YELLOW)));
    }

    public void onDeath(String name) { pops.remove(name); }
}
