package com.example.hhggk.module.combat;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;

/** Hold right click with a bow: releases the arrow after N ticks and draws again (fast arrows). */
public class BowSpam extends Module {
    public final Setting.Num charge = add(new Setting.Num("Release after (ticks)", 3, 3, 20, 1));

    public BowSpam() { super("BowSpam", Category.COMBAT); }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (mc.interactionManager == null || mc.currentScreen != null) return;
        if (!p.getMainHandStack().isOf(Items.BOW) || !mc.options.useKey.isPressed()) return;
        if (p.isUsingItem() && p.getItemUseTime() >= (int) charge.value) {
            mc.interactionManager.stopUsingItem(p);
        }
    }
}
