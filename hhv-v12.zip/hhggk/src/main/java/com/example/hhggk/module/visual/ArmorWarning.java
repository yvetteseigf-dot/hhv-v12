package com.example.hhggk.module.visual;

import com.example.hhggk.module.HudText;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;

public class ArmorWarning extends HudText {
    public final Setting.Num percent = add(new Setting.Num("Warn below %", 15, 5, 50, 1));

    public ArmorWarning() { super("ArmorWarning", Category.VISUAL, 50, 35); }

    @Override
    protected String text(MinecraftClient mc) {
        EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
        for (EquipmentSlot sl : slots) {
            ItemStack s = mc.player.getEquippedStack(sl);
            if (s.isEmpty() || !s.isDamageable()) continue;
            int left = s.getMaxDamage() - s.getDamage();
            if (left * 100 < s.getMaxDamage() * percent.value) return "LOW ARMOR: " + s.getName().getString();
        }
        return "";
    }

    @Override
    protected int color(MinecraftClient mc) {
        return 0xFFFF5555;
    }
}
