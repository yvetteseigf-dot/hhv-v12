package com.example.hhggk.module.visual;

import com.example.hhggk.module.Module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

/** Shows how many totems you have (inventory + offhand) next to the crosshair. */
public class TotemCount extends Module {
    public TotemCount() { super("TotemCount", Category.VISUAL); }

    @Override
    public void onHud(DrawContext ctx, MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        int n = 0;
        for (int i = 0; i < 36; i++) if (p.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) n++;
        if (p.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) n++;
        int x = ctx.getScaledWindowWidth() / 2 + 24, y = ctx.getScaledWindowHeight() - 58;
        ctx.fill(x - 2, y - 2, x + 38, y + 18, 0xA0101018);
        ctx.drawItem(new ItemStack(Items.TOTEM_OF_UNDYING), x, y);
        ctx.drawTextWithShadow(mc.textRenderer, "x" + n, x + 19, y + 5, n == 0 ? 0xFFFF5555 : 0xFFFFFFFF);
    }
}
