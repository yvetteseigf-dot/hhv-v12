package com.example.hhggk.module.movement;

import com.example.hhggk.module.Fireworks;
import com.example.hhggk.module.Module;
import com.example.hhggk.module.ModuleManager;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.projectile.FireworkRocketEntity;
import net.minecraft.util.math.Vec3d;

public class SuperFireworks extends Module {
    public final Setting.Mode mode = add(new Setting.Mode("Mode", "Boost", "Constant", "Burst", "Ramp"));
    public final Setting.Num speed = add(new Setting.Num("Speed (b/s) max 80", 40, 0, 80, 1));
    public final Setting.Num accel = add(new Setting.Num("Acceleration", 0.4, 0.05, 2.0, 0.05));
    public final Setting.Num burst = add(new Setting.Num("Burst length (ticks)", 20, 5, 60, 5));
    public final Setting.Bool always = add(new Setting.Bool("Always boost", false));

    private boolean prevRocket;
    private int burstLeft;
    private double rampSpeed;

    public SuperFireworks() { super("SuperFireworks", Category.MOVEMENT); }

    /** Max speed in blocks per tick. */
    public double capPerTick() { return speed.value / 20.0; }

    @Override
    public void onDisable() { prevRocket = false; burstLeft = 0; rampSpeed = 0; }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (!p.isGliding()) { prevRocket = false; burstLeft = 0; rampSpeed = 0; return; }

        // ElytraTarget steers by itself while it has a target
        ElytraTarget et = ModuleManager.elytraTarget;
        if (et != null && et.enabled && et.targeting) return;

        double cap = capPerTick();
        if (cap <= 0) return;

        boolean rocket = always.value
                || System.currentTimeMillis() - Fireworks.lastUse < 1500
                || !mc.world.getEntitiesByClass(FireworkRocketEntity.class,
                        p.getBoundingBox().expand(6), e -> e.getOwner() == p).isEmpty();

        Vec3d look = p.getRotationVec(1.0f);
        Vec3d v = p.getVelocity();

        switch (mode.get()) {
            case "Constant" -> {
                if (rocket) p.setVelocity(look.multiply(cap));
            }
            case "Burst" -> {
                if (rocket && !prevRocket) burstLeft = (int) burst.value;
                if (burstLeft > 0) {
                    burstLeft--;
                    p.setVelocity(look.multiply(cap));
                }
            }
            case "Ramp" -> {
                if (rocket) {
                    rampSpeed = Math.max(rampSpeed, v.length());
                    rampSpeed = Math.min(cap, rampSpeed + accel.value * 0.1);
                    p.setVelocity(look.multiply(rampSpeed));
                } else {
                    rampSpeed = 0;
                }
            }
            default -> {
                if (rocket) {
                    Vec3d nv = v.add(look.multiply(accel.value));
                    if (nv.length() > cap) nv = nv.normalize().multiply(cap);
                    p.setVelocity(nv);
                }
            }
        }
        prevRocket = rocket;
    }
}
