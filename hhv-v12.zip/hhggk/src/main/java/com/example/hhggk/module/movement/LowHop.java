package com.example.hhggk.module.movement;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

/** Small fast hops while walking forward. */
public class LowHop extends Module {
    public final Setting.Num height = add(new Setting.Num("Hop height", 0.27, 0.1, 0.42, 0.01));
    public LowHop() { super("LowHop", Category.MOVEMENT); }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (mc.currentScreen != null || !mc.options.forwardKey.isPressed()) return;
        if (!p.isOnGround() || p.isSneaking() || p.isTouchingWater() || p.isClimbing()) return;
        Vec3d v = p.getVelocity();
        p.setVelocity(v.x, height.value, v.z);
    }
}
