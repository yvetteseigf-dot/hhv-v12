package com.example.hhggk.module.visual;

import com.example.hhggk.module.Fx;
import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;

import java.util.concurrent.ThreadLocalRandom;

/**
 * Fire coming off your body (client-side particles).
 * Fixed: it now shows in first person by default (fire spawns in a ring around you so the view stays clear)
 * and the particles ignore the "Particles: Minimal" video setting.
 */
public class Hell extends Module {
    public final Setting.Num intensity = add(new Setting.Num("Intensity", 8, 1, 30, 1));
    public final Setting.Mode flame = add(new Setting.Mode("Flame", "Fire", "Soul"));
    public final Setting.Bool smoke = add(new Setting.Bool("Smoke", true));
    public final Setting.Bool embers = add(new Setting.Bool("Embers", true));
    public final Setting.Bool lava = add(new Setting.Bool("Lava drops", false));
    public final Setting.Bool firstPerson = add(new Setting.Bool("Show in first person", true));

    public Hell() { super("Hell", Category.VISUAL); }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        ThreadLocalRandom r = ThreadLocalRandom.current();
        boolean fp = mc.options.getPerspective().isFirstPerson();
        if (fp && !firstPerson.value) return;

        ParticleEffect main = flame.is("Soul") ? ParticleTypes.SOUL_FIRE_FLAME : ParticleTypes.FLAME;
        double h = p.getHeight();
        double vx = p.getVelocity().x * 0.35, vy = p.getVelocity().y * 0.2, vz = p.getVelocity().z * 0.35;

        for (int i = 0; i < (int) intensity.value; i++) {
            // spawn along the path travelled this tick so fast flight leaves a trail
            double t = r.nextDouble();
            double bx = p.prevX + (p.getX() - p.prevX) * t;
            double by = p.prevY + (p.getY() - p.prevY) * t;
            double bz = p.prevZ + (p.getZ() - p.prevZ) * t;

            // first person: ring 0.55..0.95 blocks around you (visible at the sides / below, never blocks the crosshair)
            // third person: dense column on the body
            double ang = r.nextDouble() * Math.PI * 2;
            double rad = fp ? 0.55 + r.nextDouble() * 0.4 : r.nextDouble() * 0.45;
            double x = bx + Math.cos(ang) * rad;
            double z = bz + Math.sin(ang) * rad;
            double y = by + r.nextDouble() * (fp ? h * 0.9 : h + 0.25);
            double up = 0.02 + r.nextDouble() * 0.05;

            Fx.add(mc, main, x, y, z, vx + (r.nextDouble() - 0.5) * 0.02, vy + up, vz + (r.nextDouble() - 0.5) * 0.02);

            if (embers.value && r.nextInt(4) == 0) {
                Fx.add(mc, ParticleTypes.SMALL_FLAME, x, y, z,
                        (r.nextDouble() - 0.5) * 0.06, 0.05 + r.nextDouble() * 0.06, (r.nextDouble() - 0.5) * 0.06);
            }
            if (smoke.value && r.nextInt(5) == 0) {
                Fx.add(mc, ParticleTypes.LARGE_SMOKE, x, y + 0.2, z,
                        (r.nextDouble() - 0.5) * 0.02, 0.04 + r.nextDouble() * 0.04, (r.nextDouble() - 0.5) * 0.02);
            }
        }
        if (lava.value && r.nextInt(3) == 0) {
            double ang = r.nextDouble() * Math.PI * 2, rad = fp ? 0.6 : 0.3;
            Fx.add(mc, ParticleTypes.LAVA, p.getX() + Math.cos(ang) * rad,
                    p.getY() + r.nextDouble() * h, p.getZ() + Math.sin(ang) * rad, 0, 0, 0);
        }
    }
}
