package com.example.hhggk.module.combat;

import com.example.hhggk.module.EntityFilter;
import com.example.hhggk.module.Inv;
import com.example.hhggk.module.Module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;

/** If the player under your crosshair blocks with a shield, hits once with an axe from your hotbar (disables the shield). */
public class ShieldBreaker extends Module {
    private int cd;

    public ShieldBreaker() { super("ShieldBreaker", Category.COMBAT); }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (cd-- > 0 || mc.interactionManager == null || mc.currentScreen != null) return;
        Entity t = mc.targetedEntity;
        if (!(t instanceof PlayerEntity pe) || !pe.isBlocking() || EntityFilter.kind(t, p) != 0) return;
        int axe = Inv.hotbar(p, s -> Inv.path(s).endsWith("_axe"));
        if (axe < 0) return;
        int prev = p.getInventory().selectedSlot;
        p.getInventory().selectedSlot = axe;
        mc.interactionManager.attackEntity(p, t);
        p.swingHand(Hand.MAIN_HAND);
        p.getInventory().selectedSlot = prev;
        cd = 12;
    }
}
