package com.example.hhggk.module.visual;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.Stats;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/** Small X around the crosshair for a moment after every hit. */
public class HitMarker extends Module {
    public HitMarker() { super("HitMarker", Category.VISUAL); }

    @Override
    public void onHud(DrawContext ctx, MinecraftClient mc) {
        long dt = System.currentTimeMillis() - Stats.lastHit;
        if (dt > 260) return;
        int cx = ctx.getScaledWindowWidth() / 2, cy = ctx.getScaledWindowHeight() / 2;
        int a = (int) (255 * (1.0 - dt / 260.0));
        int col = (a << 24) | 0xFFFFFF;
        for (int i = 4; i <= 9; i++) {
            ctx.fill(cx + i, cy + i, cx + i + 2, cy + i + 2, col);
            ctx.fill(cx - i - 1, cy + i, cx - i + 1, cy + i + 2, col);
            ctx.fill(cx + i, cy - i - 1, cx + i + 2, cy - i + 1, col);
            ctx.fill(cx - i - 1, cy - i - 1, cx - i + 1, cy - i + 1, col);
        }
    }
}
