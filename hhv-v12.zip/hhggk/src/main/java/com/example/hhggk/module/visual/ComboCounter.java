package com.example.hhggk.module.visual;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.Stats;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public class ComboCounter extends Module {
    public ComboCounter() { super("ComboCounter", Category.VISUAL); }

    @Override
    public void onHud(DrawContext ctx, MinecraftClient mc) {
        if (Stats.combo <= 0) return;
        String s = "COMBO x" + Stats.combo;
        int w = mc.textRenderer.getWidth(s);
        int x = ctx.getScaledWindowWidth() / 2 - w / 2, y = ctx.getScaledWindowHeight() / 2 - 40;
        ctx.fill(x - 4, y - 3, x + w + 4, y + 11, 0xA0101018);
        ctx.fill(x - 4, y + 10, x + w + 4, y + 11, 0xFFFFD36B);
        ctx.drawTextWithShadow(mc.textRenderer, s, x, y, 0xFFFFD36B);
    }
}
