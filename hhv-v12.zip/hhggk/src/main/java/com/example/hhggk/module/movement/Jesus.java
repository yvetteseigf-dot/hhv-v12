package com.example.hhggk.module.movement;

import com.example.hhggk.module.Module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

public class Jesus extends Module {
    public Jesus() { super("Jesus", Category.MOVEMENT); }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (mc.currentScreen != null) return;
        if (p.isTouchingWater() && !mc.options.sneakKey.isPressed()) {
            Vec3d v = p.getVelocity();
            p.setVelocity(v.x, 0.12, v.z);
        }
    }
}
