package com.example.hhggk.module.visual;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/** White streaks from the screen edges when you move fast (elytra, speed...). */
public class SpeedLines extends Module {
    public final Setting.Num minSpeed = add(new Setting.Num("Min speed (b/s)", 20, 5, 80, 1));
    private double bps;

    public SpeedLines() { super("SpeedLines", Category.VISUAL); }

    @Override
    public void onTick(MinecraftClient mc) {
        bps = Math.hypot(mc.player.getX() - mc.player.prevX, mc.player.getZ() - mc.player.prevZ) * 20.0;
    }

    @Override
    public void onHud(DrawContext ctx, MinecraftClient mc) {
        if (bps < minSpeed.value) return;
        int w = ctx.getScaledWindowWidth(), h = ctx.getScaledWindowHeight();
        int a = (int) Math.min(150, (bps - minSpeed.value) * 4 + 30);
        int col = (a << 24) | 0xFFFFFF;
        long t = System.currentTimeMillis() / 40;
        for (int i = 0; i < 14; i++) {
            long r = (t * 31 + i * 7919L) % 1000L;
            int len = 14 + (int) (r % 30);
            int y = (int) ((r * 37L + i * 53L) % h);
            int x = (int) ((r * 17L + i * 97L) % (w / 5 + 1));
            ctx.fill(x, y, x + len, y + 1, col);
            ctx.fill(w - x - len, (y + h / 2) % h, w - x, (y + h / 2) % h + 1, col);
        }
    }
}
