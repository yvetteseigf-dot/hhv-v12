package com.example.hhggk.module.misc;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.ModuleManager;
import com.example.hhggk.module.Setting;

import com.mojang.authlib.GameProfile;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.OtherClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

import net.minecraft.entity.LivingEntity;

import java.util.List;
import java.util.UUID;

/**
 * Client-side decoy player (only you can see it) for testing Aura / hits / totems.
 *  - Take damage: your hits hurt it (weapon damage, cooldown, crits, armor).
 *  - Auto totem: it holds a totem and pops (with the real totem effect) instead of dying.
 */
public class FakePlayer extends Module {
    public final Setting.Bool copyGear = add(new Setting.Bool("Copy my gear", true));
    public final Setting.Bool follow = add(new Setting.Bool("Follow me", false));
    public final Setting.Num followDist = add(new Setting.Num("Follow distance", 3.0, 1.0, 10.0, 0.5));
    public final Setting.Bool takeDamage = add(new Setting.Bool("Take damage", true));
    public final Setting.Bool autoTotem = add(new Setting.Bool("Auto totem", true));
    public final Setting.Num totems = add(new Setting.Num("Totems", 5, 0, 36, 1));
    public final Setting.Num spawnDist = add(new Setting.Num("Spawn distance", 3.0, 0.0, 10.0, 0.5));
    public final Setting.Bool targetable = add(new Setting.Bool("Targetable (Aura etc.)", true));

    public static OtherClientPlayerEntity fake;
    public static boolean canTarget = true;
    public static int pops;

    private int totemsLeft;
    private Vec3d kb = Vec3d.ZERO;

    public FakePlayer() { super("FakePlayer", Category.MISC); }

    @Override
    public void onEnable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) { enabled = false; return; }
        ClientPlayerEntity p = mc.player;
        fake = new OtherClientPlayerEntity(mc.world,
                new GameProfile(UUID.randomUUID(), p.getName().getString()));
        fake.setId(-8541);
        fake.copyPositionAndRotation(p);
        // spawn in FRONT of you (not inside you) and face you
        double yawRad = Math.toRadians(p.getYaw());
        fake.updatePosition(p.getX() - Math.sin(yawRad) * spawnDist.value, p.getY(),
                p.getZ() + Math.cos(yawRad) * spawnDist.value);
        fake.setYaw(p.getYaw() + 180f);
        fake.headYaw = p.getYaw() + 180f;
        fake.bodyYaw = p.getYaw() + 180f;
        if (copyGear.value) fake.getInventory().clone(p.getInventory());
        if (autoTotem.value) fake.setStackInHand(Hand.OFF_HAND, new ItemStack(Items.TOTEM_OF_UNDYING));
        fake.setHealth(20f);
        totemsLeft = (int) totems.value;
        pops = 0;
        kb = Vec3d.ZERO;
        mc.world.addEntity(fake);
    }

    @Override
    public void onDisable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (fake != null && mc.world != null) {
            mc.world.removeEntity(fake.getId(), Entity.RemovalReason.DISCARDED);
        }
        fake = null;
    }

    @Override
    public void onTick(MinecraftClient mc) {
        if (fake == null) return;
        canTarget = targetable.value;
        ClientPlayerEntity p = mc.player;

        if (follow.value) {
            double yaw = Math.toRadians(p.getYaw());
            Vec3d back = new Vec3d(Math.sin(yaw), 0, -Math.cos(yaw)).multiply(followDist.value);
            fake.updatePosition(p.getX() + back.x, p.getY(), p.getZ() + back.z);
            fake.setYaw(p.getYaw());
            fake.headYaw = p.headYaw;
            fake.bodyYaw = p.bodyYaw;
        } else if (kb.lengthSquared() > 1.0E-4) {
            fake.updatePosition(fake.getX() + kb.x, fake.getY(), fake.getZ() + kb.z);
            kb = kb.multiply(0.6);
        }

        // auto totem: keep the totem in its offhand
        if (autoTotem.value && totemsLeft > 0 && !fake.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) {
            fake.setStackInHand(Hand.OFF_HAND, new ItemStack(Items.TOTEM_OF_UNDYING));
        }
    }

    /** Makes sure the decoy is part of a module's target list (even if the world lookup misses it). */
    public static void addTo(List<LivingEntity> list) {
        LivingEntity f = fake;
        if (f != null && canTarget && f.isAlive() && !list.contains(f)) list.add(f);
    }

    // ------------------------------------------------------------- damage (called from AttackMixin)
    private static float weaponDamage(ItemStack s) {
        Item i = s.getItem();
        if (i == Items.WOODEN_SWORD || i == Items.GOLDEN_SWORD) return 4;
        if (i == Items.STONE_SWORD) return 5;
        if (i == Items.IRON_SWORD) return 6;
        if (i == Items.DIAMOND_SWORD) return 7;
        if (i == Items.NETHERITE_SWORD) return 8;
        if (i == Items.WOODEN_AXE || i == Items.GOLDEN_AXE) return 7;
        if (i == Items.STONE_AXE || i == Items.IRON_AXE || i == Items.DIAMOND_AXE) return 9;
        if (i == Items.NETHERITE_AXE) return 10;
        if (i == Items.TRIDENT) return 9;
        if (i == Items.MACE) return 6;
        return 1;
    }

    public static void onAttacked(MinecraftClient mc, PlayerEntity attacker) {
        FakePlayer m = ModuleManager.fakePlayer;
        OtherClientPlayerEntity f = fake;
        if (m == null || !m.enabled || f == null || !m.takeDamage.value) return;

        float c = attacker.getAttackCooldownProgress(0.5f);
        float dmg = weaponDamage(attacker.getMainHandStack()) * (0.2f + c * c * 0.8f);
        double fd = attacker.fallDistance;
        if (attacker.getMainHandStack().isOf(Items.MACE) && fd > 1.5) {
            dmg += (float) (4 * Math.min(fd, 3) + 2 * Math.min(Math.max(fd - 3, 0), 5) + Math.max(fd - 8, 0));
        } else if (c > 0.9f && fd > 0 && !attacker.isOnGround() && !attacker.isClimbing()
                && !attacker.isTouchingWater() && !attacker.isSprinting()) {
            dmg *= 1.5f; // critical hit
        }
        dmg *= 1.0f - Math.min(20, f.getArmor()) / 25.0f;

        f.handleStatus((byte) 2); // hurt flash + sound
        double dx = f.getX() - attacker.getX(), dz = f.getZ() - attacker.getZ();
        double len = Math.max(0.001, Math.hypot(dx, dz));
        m.kb = new Vec3d(dx / len * 0.18, 0, dz / len * 0.18);

        float hp = f.getHealth() - dmg;
        if (hp > 0) { f.setHealth(hp); return; }

        if (m.autoTotem.value && m.totemsLeft > 0) {
            m.totemsLeft--;
            pops++;
            f.setHealth(1f);
            f.handleStatus((byte) 35); // totem pop particles + sound
            if (mc.inGameHud != null) {
                mc.inGameHud.getChatHud().addMessage(Text.literal("[FakePlayer] popped a totem (" + pops
                        + " pops, " + m.totemsLeft + " left)"));
            }
            return;
        }
        if (mc.inGameHud != null) {
            mc.inGameHud.getChatHud().addMessage(Text.literal("[FakePlayer] died after " + pops + " pops."));
        }
        m.toggle();
    }
}
