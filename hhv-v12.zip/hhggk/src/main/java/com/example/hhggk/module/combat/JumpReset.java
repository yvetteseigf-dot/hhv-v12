package com.example.hhggk.module.combat;

import com.example.hhggk.module.Module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.Vec3d;

/** Jumps the moment you get hit, so you take less knockback. */
public class JumpReset extends Module {
    public JumpReset() { super("JumpReset", Category.COMBAT); }

    @Override
    public void onTick(MinecraftClient mc) {
        if (mc.player.hurtTime >= 8 && mc.player.isOnGround() && !mc.player.isTouchingWater()) {
            Vec3d v = mc.player.getVelocity();
            mc.player.setVelocity(v.x, 0.42, v.z);
        }
    }
}
