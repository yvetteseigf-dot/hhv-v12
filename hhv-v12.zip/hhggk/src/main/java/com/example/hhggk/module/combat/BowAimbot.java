package com.example.hhggk.module.combat;

import com.example.hhggk.module.EntityFilter;
import com.example.hhggk.module.Module;
import com.example.hhggk.module.Rot;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/** While drawing a bow / crossbow, aims at the closest player with lead and gravity compensation. */
public class BowAimbot extends Module {
    public final Setting.Num range = add(new Setting.Num("Range", 60, 10, 120, 5));
    public final Setting.Num smooth = add(new Setting.Num("Smoothing", 0.7, 0.1, 1.0, 0.05));
    public final Setting.Bool needSight = add(new Setting.Bool("Only visible", true));

    public BowAimbot() { super("BowAimbot", Category.COMBAT); }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (mc.currentScreen != null || !p.isUsingItem()) return;
        boolean bow = p.getActiveItem().isOf(Items.BOW);
        if (!bow && !p.getActiveItem().isOf(Items.CROSSBOW)) return;

        PlayerEntity best = null;
        double bd = range.value;
        for (PlayerEntity e : mc.world.getPlayers()) {
            if (EntityFilter.kind(e, p) != 0 || !e.isAlive()) continue;
            if (needSight.value && !p.canSee(e)) continue;
            double d = p.distanceTo(e);
            if (d < bd) { bd = d; best = e; }
        }
        if (best == null) return;

        double speed = 3.0;
        if (bow) {
            float f = p.getItemUseTime() / 20.0f;
            f = Math.min(1.0f, (f * f + f * 2.0f) / 3.0f);
            speed = Math.max(0.5, f * 3.0);
        }
        Vec3d eye = p.getEyePos();
        Vec3d c = best.getBoundingBox().getCenter();
        Vec3d v = new Vec3d(best.getX() - best.prevX, best.getY() - best.prevY, best.getZ() - best.prevZ);
        double time = Math.min(40.0, eye.distanceTo(c) / speed);
        Vec3d aim = c.add(v.multiply(time)).add(0, 0.5 * 0.05 * time * time, 0);

        float s = (float) smooth.value;
        float ty = Rot.yawTo(eye, aim), tp = Rot.pitchTo(eye, aim);
        p.setYaw(p.getYaw() + MathHelper.wrapDegrees(ty - p.getYaw()) * s);
        p.setPitch(MathHelper.clamp(p.getPitch() + (tp - p.getPitch()) * s, -90f, 90f));
    }
}
