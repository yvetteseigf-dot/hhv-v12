package com.example.hhggk.module.movement;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

/** Falls faster (use together with NoFall). */
public class FastFall extends Module {
    public final Setting.Num speed = add(new Setting.Num("Fall speed", 1.0, 0.3, 3.0, 0.1));
    public FastFall() { super("FastFall", Category.MOVEMENT); }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p.isOnGround() || p.isGliding() || p.isTouchingWater() || p.getAbilities().flying || p.isClimbing()) return;
        Vec3d v = p.getVelocity();
        if (v.y < -0.1) p.setVelocity(v.x, Math.min(v.y, -speed.value), v.z);
    }
}
