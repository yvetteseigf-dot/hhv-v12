package com.example.hhggk.module.combat;

import com.example.hhggk.module.Inv;
import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.util.Hand;

/** Throws a splash Instant Health potion at your feet when your health is low. */
public class AutoPot extends Module {
    public final Setting.Num health = add(new Setting.Num("Health (half hearts)", 10, 2, 19, 1));
    public final Setting.Num delay = add(new Setting.Num("Delay (ticks)", 6, 2, 20, 1));

    private int cd;

    public AutoPot() { super("AutoPot", Category.COMBAT); }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (cd-- > 0 || mc.interactionManager == null || mc.currentScreen != null) return;
        if (p.getHealth() > health.value) return;
        int slot = Inv.hotbar(p, s -> Inv.isSplash(s) && Inv.hasPotionEffect(s, StatusEffects.INSTANT_HEALTH));
        if (slot < 0) return;
        int prev = p.getInventory().selectedSlot;
        float pitch = p.getPitch();
        p.getInventory().selectedSlot = slot;
        p.setPitch(90f);
        mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
        p.swingHand(Hand.MAIN_HAND);
        p.setPitch(pitch);
        p.getInventory().selectedSlot = prev;
        cd = (int) delay.value;
    }
}
