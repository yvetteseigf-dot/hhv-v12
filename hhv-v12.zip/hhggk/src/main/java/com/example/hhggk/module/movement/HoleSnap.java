package com.example.hhggk.module.movement;

import com.example.hhggk.module.BlockUtil;
import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

/** Pulls you into the closest safe hole (obsidian / bedrock walls). Turns off when you are inside. */
public class HoleSnap extends Module {
    public final Setting.Num range = add(new Setting.Num("Range", 4, 1, 8, 1));
    public final Setting.Num speed = add(new Setting.Num("Speed", 0.3, 0.1, 0.6, 0.01));
    public final Setting.Bool autoOff = add(new Setting.Bool("Turn off in hole", true));

    public HoleSnap() { super("HoleSnap", Category.MOVEMENT); }

    public static BlockPos nearest(MinecraftClient mc, int r) {
        ClientPlayerEntity p = mc.player;
        BlockPos me = p.getBlockPos();
        BlockPos best = null;
        double bd = Double.MAX_VALUE;
        for (int dx = -r; dx <= r; dx++) for (int dy = -3; dy <= 1; dy++) for (int dz = -r; dz <= r; dz++) {
            BlockPos pos = me.add(dx, dy, dz);
            double d = p.squaredDistanceTo(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5);
            if (d >= bd || !BlockUtil.isHole(mc, pos)) continue;
            best = pos; bd = d;
        }
        return best;
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        BlockPos h = nearest(mc, (int) range.value);
        if (h == null) return;
        Vec3d c = new Vec3d(h.getX() + 0.5, h.getY(), h.getZ() + 0.5);
        double dx = c.x - p.getX(), dz = c.z - p.getZ();
        double d = Math.hypot(dx, dz);
        if (d < 0.15 && Math.abs(p.getY() - c.y) < 1.2) {
            p.setVelocity(0, p.getVelocity().y, 0);
            if (autoOff.value) enabled = false;
            return;
        }
        double s = Math.min(speed.value, d);
        Vec3d v = p.getVelocity();
        p.setVelocity(dx / d * s, v.y, dz / d * s);
    }
}
