package com.example.hhggk.module.movement;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.Move;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

/** Full air control: you can change direction in the air without losing speed. */
public class Strafe extends Module {
    public final Setting.Num minSpeed = add(new Setting.Num("Min air speed", 0.26, 0.1, 0.8, 0.01));

    public Strafe() { super("Strafe", Category.MOVEMENT); }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p.isOnGround() || p.isGliding() || p.isTouchingWater() || p.isClimbing() || p.getAbilities().flying) return;
        Vec3d v = p.getVelocity();
        double cur = Math.hypot(v.x, v.z);
        Vec3d dir = Move.horizontal(mc, Math.max(cur, minSpeed.value));
        if (dir == Vec3d.ZERO) return;
        p.setVelocity(dir.x, v.y, dir.z);
    }
}
