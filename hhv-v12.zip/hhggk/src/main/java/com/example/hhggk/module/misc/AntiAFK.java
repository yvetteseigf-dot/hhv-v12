package com.example.hhggk.module.misc;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.util.Hand;

/** Small movements every few seconds so the server does not kick you for being AFK. */
public class AntiAFK extends Module {
    public final Setting.Num seconds = add(new Setting.Num("Every (seconds)", 20, 5, 120, 5));
    private int t;
    private boolean flip;

    public AntiAFK() { super("AntiAFK", Category.MISC); }

    @Override
    public void onTick(MinecraftClient mc) {
        if (++t < (int) seconds.value * 20) return;
        t = 0;
        flip = !flip;
        mc.player.setYaw(mc.player.getYaw() + (flip ? 4f : -4f));
        mc.player.swingHand(Hand.MAIN_HAND);
    }
}
