package com.example.hhggk.module.combat;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

/** Anti-knockback: scales the knockback the server sends you. 0 % = none. Applied in NetMixin. */
public class Velocity extends Module {
    public final Setting.Num horizontal = add(new Setting.Num("Horizontal %", 0, 0, 100, 5));
    public final Setting.Num vertical = add(new Setting.Num("Vertical %", 0, 0, 100, 5));

    public Velocity() { super("Velocity", Category.COMBAT); }
}
