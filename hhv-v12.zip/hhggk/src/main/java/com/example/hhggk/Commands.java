package com.example.hhggk;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.ModuleManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.List;

/** Chat commands with the "." prefix:  .cfg  .friend  .toggle  .help */
public class Commands {
    private static final String[] ROOT = {".cfg", ".friend", ".server", ".toggle", ".bind", ".help"};

    private static void say(String msg, Formatting color) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.inGameHud == null) return;
        mc.inGameHud.getChatHud().addMessage(Text.literal("[Diamond] ").formatted(Formatting.AQUA)
                .append(Text.literal(msg).formatted(color)));
    }

    private static void ok(String m) { say(m, Formatting.GREEN); }
    private static void err(String m) { say(m, Formatting.RED); }
    private static void info(String m) { say(m, Formatting.WHITE); }

    /** @return true if the message was a command and must not be sent to the server */
    public static boolean handle(String msg) {
        if (msg == null || !msg.startsWith(".")) return false;
        String[] a = msg.trim().split("\\s+");
        switch (a[0].toLowerCase()) {
            case ".cfg", ".config" -> { cfg(a); return true; }
            case ".friend", ".friends" -> { friend(a); return true; }
            case ".server", ".servers" -> { server(a); return true; }
            case ".toggle", ".t" -> { toggle(a); return true; }
            case ".bind", ".keybind" -> { bind(a); return true; }
            case ".help" -> { help(); return true; }
            default -> { return false; }
        }
    }

    private static void help() {
        info(".cfg save <name>  |  .cfg load <name>  |  .cfg delete <name>  |  .cfg list");
        info(".friend add <name>  |  .friend remove <name>  |  .friend list  |  .friend clear");
        info(".server add [ip]  |  .server remove [ip]  |  .server list   (no ip = the server you are on)");
        info(".toggle <module>");
        info(".bind <module> <key>  |  .bind <module> none  |  .bind list     (one key = on, press again = off)");
        info("keys: g, f6, left.shift, space, mouse4, mmb ...   example:  .bind AutoTrap g");
    }

    private static Module find(String name) {
        for (Module m : ModuleManager.modules) if (m.name.equalsIgnoreCase(name)) return m;
        return null;
    }

    private static void bind(String[] a) {
        if (a.length < 2) { info("Usage: .bind <module> <key>  |  .bind <module> none  |  .bind list"); return; }
        if (a[1].equalsIgnoreCase("list")) {
            StringBuilder sb = new StringBuilder();
            for (Module m : ModuleManager.modules) {
                if (m.bind == null) continue;
                if (sb.length() > 0) sb.append(", ");
                sb.append(m.name).append(" = ").append(Binds.label(m.bind));
            }
            info(sb.length() == 0 ? "No binds yet. Example: .bind AutoTrap g" : "Binds: " + sb);
            return;
        }
        Module m = find(a[1]);
        if (m == null) { err("Module '" + a[1] + "' not found."); return; }
        if (a.length < 3) {
            info(m.name + " is bound to: " + Binds.label(m.bind) + "   (use .bind " + m.name + " <key>)");
            return;
        }
        String k = a[2].toLowerCase();
        if (k.equals("none") || k.equals("clear") || k.equals("remove") || k.equals("off")) {
            Binds.set(m, null);
            ok(m.name + " unbound.");
            return;
        }
        // allow "left shift" typed with a space
        if (a.length > 3) k = k + "." + a[3].toLowerCase();
        net.minecraft.client.util.InputUtil.Key key = Binds.parse(k);
        if (key == null) { err("Unknown key '" + k + "'. Examples: g, f6, space, left.shift, mouse4, mmb"); return; }
        for (Module o : ModuleManager.modules) {
            if (o != m && o.bind != null && o.bind.getTranslationKey().equals(key.getTranslationKey())) {
                err(Binds.label(key) + " is already used by " + o.name + ". Unbind it first: .bind " + o.name + " none");
                return;
            }
        }
        Binds.set(m, key);
        ok(m.name + " is now toggled with [" + Binds.label(key) + "]  (one press = on, again = off).");
    }

    private static void server(String[] a) {
        if (a.length < 2) { info("Usage: .server add|remove|list [ip]"); return; }
        String addr = a.length >= 3 ? a[2] : Settings.current();
        switch (a[1].toLowerCase()) {
            case "list" -> {
                List<String> l = Settings.list();
                info(l.isEmpty() ? "No servers yet. Join one and type .server add" : "Servers: " + String.join(", ", l));
            }
            case "add" -> {
                if (addr == null) { err("You are not on a server. Use: .server add <ip>"); return; }
                if (Settings.add(addr)) ok(addr + " added. Modules are unlocked there.");
                else info(addr + " is already in the list.");
            }
            case "remove", "del" -> {
                if (addr == null) { err("You are not on a server. Use: .server remove <ip>"); return; }
                if (Settings.remove(addr)) ok(addr + " removed. Modules are locked there.");
                else err(addr + " is not in the list.");
            }
            default -> info("Usage: .server add|remove|list [ip]");
        }
    }

    private static void cfg(String[] a) {
        if (a.length < 2) { info("Usage: .cfg save|load|delete|list <name>"); return; }
        switch (a[1].toLowerCase()) {
            case "list" -> {
                List<String> l = ConfigManager.list();
                info(l.isEmpty() ? "No configs saved yet." : "Configs: " + String.join(", ", l));
            }
            case "save" -> {
                if (a.length < 3) { err("Usage: .cfg save <name>"); return; }
                if (ConfigManager.save(a[2])) ok("Saved config '" + a[2] + "'.");
                else err("Could not save (use letters/numbers/_/- only).");
            }
            case "load" -> {
                if (a.length < 3) { err("Usage: .cfg load <name>"); return; }
                if (ConfigManager.load(a[2])) ok("Loaded config '" + a[2] + "'.");
                else err("Config '" + a[2] + "' not found.");
            }
            case "delete", "remove" -> {
                if (a.length < 3) { err("Usage: .cfg delete <name>"); return; }
                if (ConfigManager.delete(a[2])) ok("Deleted config '" + a[2] + "'.");
                else err("Config '" + a[2] + "' not found.");
            }
            default -> info("Usage: .cfg save|load|delete|list <name>");
        }
    }

    private static void friend(String[] a) {
        if (a.length < 2) { info("Usage: .friend add|remove|list|clear <name>"); return; }
        switch (a[1].toLowerCase()) {
            case "list" -> {
                List<String> l = Friends.list();
                info(l.isEmpty() ? "No friends yet." : "Friends: " + String.join(", ", l));
            }
            case "clear" -> { Friends.clear(); ok("Friend list cleared."); }
            case "add" -> {
                if (a.length < 3) { err("Usage: .friend add <name>"); return; }
                if (Friends.add(a[2])) ok(a[2] + " added. Aura will ignore them.");
                else info(a[2] + " is already a friend.");
            }
            case "remove", "del" -> {
                if (a.length < 3) { err("Usage: .friend remove <name>"); return; }
                if (Friends.remove(a[2])) ok(a[2] + " removed.");
                else err(a[2] + " is not in your friend list.");
            }
            default -> info("Usage: .friend add|remove|list|clear <name>");
        }
    }

    private static void toggle(String[] a) {
        if (a.length < 2) { err("Usage: .toggle <module>"); return; }
        for (Module m : ModuleManager.modules) {
            if (m.name.equalsIgnoreCase(a[1])) {
                if (!Settings.active() && !m.enabled) { err("Locked: this server is not allowed. Type .server add"); return; }
                m.toggle();
                ok(m.name + (m.enabled ? " enabled." : " disabled."));
                return;
            }
        }
        err("Module '" + a[1] + "' not found.");
    }

    /** Suggestions for the chat box. Input = text up to the cursor. */
    public static List<String> suggest(String text) {
        List<String> c = new ArrayList<>();
        String[] p = text.split(" ", -1);
        int idx = p.length - 1;
        String cur = p[idx].toLowerCase();
        if (idx == 0) {
            for (String r : ROOT) c.add(r);
        } else {
            String first = p[0].toLowerCase();
            String sub = p.length > 1 ? p[1].toLowerCase() : "";
            switch (first) {
                case ".cfg", ".config" -> {
                    if (idx == 1) { c.add("save"); c.add("load"); c.add("delete"); c.add("list"); }
                    else if (idx == 2 && !sub.equals("list")) c.addAll(ConfigManager.list());
                }
                case ".friend", ".friends" -> {
                    if (idx == 1) { c.add("add"); c.add("remove"); c.add("list"); c.add("clear"); }
                    else if (idx == 2 && sub.equals("add")) {
                        MinecraftClient mc = MinecraftClient.getInstance();
                        if (mc.getNetworkHandler() != null) {
                            String me = mc.player != null ? mc.player.getName().getString() : "";
                            for (PlayerListEntry e : mc.getNetworkHandler().getPlayerList()) {
                                String n = e.getProfile().getName();
                                if (!n.equalsIgnoreCase(me) && !Friends.isFriend(n)) c.add(n);
                            }
                        }
                    } else if (idx == 2 && (sub.equals("remove") || sub.equals("del"))) c.addAll(Friends.list());
                }
                case ".server", ".servers" -> {
                    if (idx == 1) { c.add("add"); c.add("remove"); c.add("list"); }
                    else if (idx == 2 && (sub.equals("remove") || sub.equals("del"))) c.addAll(Settings.list());
                }
                case ".toggle", ".t" -> {
                    if (idx == 1) for (Module m : ModuleManager.modules) c.add(m.name);
                }
                case ".bind", ".keybind" -> {
                    if (idx == 1) { c.add("list"); for (Module m : ModuleManager.modules) c.add(m.name); }
                    else if (idx == 2 && !sub.equals("list")) {
                        c.add("none");
                        for (char ch = 'a'; ch <= 'z'; ch++) c.add(String.valueOf(ch));
                        for (int i = 1; i <= 12; i++) c.add("f" + i);
                        c.add("space"); c.add("left.shift"); c.add("left.control"); c.add("left.alt");
                        c.add("mouse4"); c.add("mouse5"); c.add("mmb");
                    }
                }
                default -> {}
            }
        }
        List<String> out = new ArrayList<>();
        for (String s : c) if (s.toLowerCase().startsWith(cur)) out.add(s);
        return out;
    }
}
