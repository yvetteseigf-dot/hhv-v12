package com.example.hhggk.module.combat;

import com.example.hhggk.module.BlockUtil;
import com.example.hhggk.module.EntityFilter;
import com.example.hhggk.module.Inv;
import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;

/** Fills holes around you while an enemy is close, so they can not hide / pop crystals from inside them. */
public class HoleFill extends Module {
    public final Setting.Num range = add(new Setting.Num("Hole range", 4.5, 2, 6, 0.1));
    public final Setting.Num enemyRange = add(new Setting.Num("Enemy range", 8, 3, 16, 1));
    public final Setting.Bool skipOwn = add(new Setting.Bool("Skip the hole you stand in", true));

    public HoleFill() { super("HoleFill", Category.COMBAT); }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        int slot = Inv.hotbar(p, Items.OBSIDIAN);
        if (slot < 0) return;
        boolean enemy = false;
        for (PlayerEntity e : mc.world.getPlayers()) {
            if (EntityFilter.kind(e, p) == 0 && p.distanceTo(e) <= enemyRange.value) { enemy = true; break; }
        }
        if (!enemy) return;
        BlockPos me = p.getBlockPos();
        int r = (int) Math.ceil(range.value);
        BlockPos best = null;
        double bd = Double.MAX_VALUE;
        for (int dx = -r; dx <= r; dx++) for (int dy = -2; dy <= 2; dy++) for (int dz = -r; dz <= r; dz++) {
            BlockPos pos = me.add(dx, dy, dz);
            if (skipOwn.value && pos.equals(me)) continue;
            double d = p.getEyePos().squaredDistanceTo(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5);
            if (d > range.value * range.value || d >= bd) continue;
            if (!BlockUtil.isHole(mc, pos)) continue;
            best = pos; bd = d;
        }
        if (best != null) BlockUtil.place(mc, best, slot);
    }
}
