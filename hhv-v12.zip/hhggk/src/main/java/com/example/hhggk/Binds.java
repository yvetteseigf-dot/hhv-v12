package com.example.hhggk;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.ModuleManager;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;

/** Module keybinds:  .bind <module> <key>  -> that key toggles the module (press = on, press again = off). */
public class Binds {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("hhggk-binds.json");
    }

    /** "g", "f6", "left.shift", "mouse4", "mmb", "space" ... -> Key, or null if unknown. */
    public static InputUtil.Key parse(String raw) {
        if (raw == null) return null;
        String n = raw.trim().toLowerCase().replace(' ', '.').replace('_', '.');
        if (n.isEmpty()) return null;
        String tk;
        switch (n) {
            case "lmb" -> tk = "key.mouse.left";
            case "rmb" -> tk = "key.mouse.right";
            case "mmb", "middle" -> tk = "key.mouse.middle";
            case "lshift", "shift" -> tk = "key.keyboard.left.shift";
            case "rshift" -> tk = "key.keyboard.right.shift";
            case "lctrl", "ctrl" -> tk = "key.keyboard.left.control";
            case "rctrl" -> tk = "key.keyboard.right.control";
            case "lalt", "alt" -> tk = "key.keyboard.left.alt";
            case "ralt" -> tk = "key.keyboard.right.alt";
            case "esc" -> tk = "key.keyboard.escape";
            default -> {
                if (n.matches("mouse\\d+")) tk = "key.mouse." + n.substring(5);
                else tk = "key.keyboard." + n;
            }
        }
        try {
            return InputUtil.fromTranslationKey(tk);
        } catch (Throwable t) {
            return null;
        }
    }

    public static String label(InputUtil.Key k) {
        return k == null ? "none" : k.getLocalizedText().getString();
    }

    private static boolean down(MinecraftClient mc, InputUtil.Key k) {
        long w = mc.getWindow().getHandle();
        if (k.getCategory() == InputUtil.Type.MOUSE) return GLFW.glfwGetMouseButton(w, k.getCode()) == GLFW.GLFW_PRESS;
        return InputUtil.isKeyPressed(w, k.getCode());
    }

    /** Called every client tick. */
    public static void tick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null) return;
        for (Module m : ModuleManager.modules) {
            if (m.bind == null) continue;
            boolean d = down(mc, m.bind);
            // ignore presses while a screen (chat, menu...) is open, and never fire on the tick the screen closes
            if (mc.currentScreen != null) { m.bindWasDown = d; continue; }
            if (d && !m.bindWasDown) {
                if (!m.enabled && !Settings.active()) {
                    mc.player.sendMessage(Text.literal("[Diamond] Locked: this server is not allowed (.server add)"), true);
                } else {
                    m.toggle();
                    mc.player.sendMessage(Text.literal("[Diamond] " + m.name + (m.enabled ? " ON" : " OFF")), true);
                }
            }
            m.bindWasDown = d;
        }
    }

    public static void save() {
        try {
            JsonObject o = new JsonObject();
            for (Module m : ModuleManager.modules) if (m.bind != null) o.addProperty(m.name, m.bind.getTranslationKey());
            Files.writeString(file(), GSON.toJson(o));
        } catch (Exception ignored) {}
    }

    public static void load() {
        try {
            if (!Files.exists(file())) return;
            JsonObject o = JsonParser.parseString(Files.readString(file())).getAsJsonObject();
            for (Map.Entry<String, com.google.gson.JsonElement> e : o.entrySet()) {
                for (Module m : ModuleManager.modules) {
                    if (!m.name.equals(e.getKey())) continue;
                    try { m.bind = InputUtil.fromTranslationKey(e.getValue().getAsString()); } catch (Throwable ignored) {}
                }
            }
        } catch (Exception ignored) {}
    }

    public static boolean set(Module m, InputUtil.Key k) {
        m.bind = k;
        m.bindWasDown = false;
        save();
        return true;
    }
}
