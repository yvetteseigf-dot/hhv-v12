package com.example.hhggk.module.misc;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;

/** Sneaks on and off quickly. */
public class Twerk extends Module {
    public final Setting.Num ticks = add(new Setting.Num("Delay (ticks)", 3, 1, 20, 1));
    private int t;
    private boolean down;

    public Twerk() { super("Twerk", Category.MISC); }

    @Override
    public void onTick(MinecraftClient mc) {
        if (++t < (int) ticks.value) return;
        t = 0;
        down = !down;
        mc.options.sneakKey.setPressed(down);
    }

    @Override
    public void onDisable() {
        MinecraftClient.getInstance().options.sneakKey.setPressed(false);
        down = false;
    }
}
