package com.example.hhggk.module.visual;

import com.example.hhggk.module.Drawable3D;
import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;
import com.example.hhggk.render.Overlay3D;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

/** Highlights end crystals. Red = close enough to hurt you (within 12 blocks), magenta = far. */
public class CrystalESP extends Module implements Drawable3D {
    public final Setting.Num range = add(new Setting.Num("Range", 40, 10, 100, 5));

    public CrystalESP() { super("CrystalESP", Category.VISUAL); }

    @Override
    public void draw3d(MinecraftClient mc, MatrixStack ms, VertexConsumerProvider vcp, Vec3d cam, float td) {
        double r = range.value;
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof EndCrystalEntity) || mc.player.squaredDistanceTo(e) > r * r) continue;
            Vec3d off = e.getLerpedPos(td).subtract(e.getPos());
            Box b = e.getBoundingBox().offset(off);
            boolean danger = mc.player.distanceTo(e) <= 12;
            float cr = danger ? 1f : 0.85f, cg = danger ? 0.15f : 0.25f, cb = danger ? 0.15f : 1f;
            Overlay3D.filled(ms, vcp, b, cr, cg, cb, 0.25f);
            Overlay3D.outline(ms, vcp, b, cr, cg, cb, 1f);
        }
    }
}
