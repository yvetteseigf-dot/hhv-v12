package com.example.hhggk.module.movement;

import com.example.hhggk.module.Module;

import net.minecraft.client.MinecraftClient;

public class AutoWalk extends Module {
    public AutoWalk() { super("AutoWalk", Category.MOVEMENT); }

    @Override
    public void onTick(MinecraftClient mc) {
        if (mc.currentScreen == null) mc.options.forwardKey.setPressed(true);
    }

    @Override
    public void onDisable() {
        MinecraftClient.getInstance().options.forwardKey.setPressed(false);
    }
}
