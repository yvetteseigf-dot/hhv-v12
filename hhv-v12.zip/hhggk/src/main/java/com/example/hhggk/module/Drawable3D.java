package com.example.hhggk.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Vec3d;

/** A Module that draws boxes in the world. Drawn by render/Overlay3D (camera space already applied). */
public interface Drawable3D {
    void draw3d(MinecraftClient mc, MatrixStack ms, VertexConsumerProvider vcp, Vec3d cam, float td);
}
