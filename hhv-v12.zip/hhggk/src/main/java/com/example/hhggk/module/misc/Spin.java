package com.example.hhggk.module.misc;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;

public class Spin extends Module {
    public final Setting.Num speed = add(new Setting.Num("Speed (deg/tick)", 20, 5, 90, 5));

    public Spin() { super("Spin", Category.MISC); }

    @Override
    public void onTick(MinecraftClient mc) {
        if (mc.currentScreen != null) return;
        mc.player.setYaw(mc.player.getYaw() + (float) speed.value);
    }
}
