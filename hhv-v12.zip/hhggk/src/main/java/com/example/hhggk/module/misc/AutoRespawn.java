package com.example.hhggk.module.misc;

import com.example.hhggk.module.Module;

import net.minecraft.client.MinecraftClient;

public class AutoRespawn extends Module {
    public AutoRespawn() { super("AutoRespawn", Category.MISC); }

    @Override
    public void onTick(MinecraftClient mc) {
        if (mc.player.isDead()) mc.player.requestRespawn();
    }
}
