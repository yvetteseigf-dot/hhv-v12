package com.example.hhggk.module.visual;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;

public class FovChanger extends Module {
    public final Setting.Num fov = add(new Setting.Num("FOV", 100, 30, 110, 1));
    private int old = 70;

    public FovChanger() { super("FOV", Category.VISUAL); }

    @Override
    public void onEnable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        old = mc.options.getFov().getValue();
    }

    @Override
    public void onTick(MinecraftClient mc) {
        mc.options.getFov().setValue((int) fov.value);
    }

    @Override
    public void onDisable() {
        MinecraftClient.getInstance().options.getFov().setValue(old);
    }
}
