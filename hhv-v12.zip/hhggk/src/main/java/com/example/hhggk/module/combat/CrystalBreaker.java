package com.example.hhggk.module.combat;

import com.example.hhggk.module.EntityFilter;
import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.util.Hand;

import java.util.Comparator;
import java.util.List;

/** Breaks end crystals that are in reach (fast, with a small delay setting). */
public class CrystalBreaker extends Module {
    public final Setting.Num range = add(new Setting.Num("Range", 4.5, 2.0, 6.0, 0.1));
    public final Setting.Num delay = add(new Setting.Num("Delay (ticks)", 2, 0, 10, 1));

    private int cd;

    public CrystalBreaker() { super("CrystalBreaker", Category.COMBAT); }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (cd-- > 0 || mc.interactionManager == null || mc.currentScreen != null) return;
        double r = range.value;
        List<EndCrystalEntity> list = mc.world.getEntitiesByClass(EndCrystalEntity.class,
                p.getBoundingBox().expand(r + 1), e -> e.isAlive()
                        && EntityFilter.distSqToBox(p.getEyePos(), e.getBoundingBox()) <= r * r);
        if (list.isEmpty()) return;
        EndCrystalEntity c = list.stream().min(Comparator.comparingDouble(p::distanceTo)).get();
        mc.interactionManager.attackEntity(p, c);
        p.swingHand(Hand.MAIN_HAND);
        cd = (int) delay.value;
    }
}
