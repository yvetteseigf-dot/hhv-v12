package com.example.hhggk.module.movement;

import com.example.hhggk.module.EntityFilter;
import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

/** Circles around the closest enemy while you hold forward (hard to hit, easy to hit with). */
public class TargetStrafe extends Module {
    public final Setting.Num range = add(new Setting.Num("Range", 6, 2, 12, 1));
    public final Setting.Num radius = add(new Setting.Num("Circle radius", 2.5, 1.0, 5.0, 0.1));
    public final Setting.Num speed = add(new Setting.Num("Speed", 0.28, 0.15, 0.6, 0.01));
    public final Setting.Bool needForward = add(new Setting.Bool("Only while holding forward", true));

    private int dir = 1;

    public TargetStrafe() { super("TargetStrafe", Category.MOVEMENT); }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p.isGliding() || mc.currentScreen != null) return;
        if (needForward.value && !mc.options.forwardKey.isPressed()) return;
        PlayerEntity t = null;
        double bd = range.value * range.value;
        for (PlayerEntity e : mc.world.getPlayers()) {
            if (EntityFilter.kind(e, p) != 0 || !e.isAlive()) continue;
            double d = p.squaredDistanceTo(e);
            if (d < bd) { bd = d; t = e; }
        }
        if (t == null) return;
        if (p.horizontalCollision) dir = -dir;
        double ang = Math.atan2(p.getZ() - t.getZ(), p.getX() - t.getX());
        double cur = Math.hypot(p.getX() - t.getX(), p.getZ() - t.getZ());
        double step = speed.value / Math.max(1.0, cur);
        ang += dir * step;
        Vec3d goal = new Vec3d(t.getX() + Math.cos(ang) * radius.value, p.getY(), t.getZ() + Math.sin(ang) * radius.value);
        double dx = goal.x - p.getX(), dz = goal.z - p.getZ();
        double d = Math.hypot(dx, dz);
        if (d < 0.01) return;
        double s = Math.min(speed.value, d);
        Vec3d v = p.getVelocity();
        p.setVelocity(dx / d * s, v.y, dz / d * s);
    }
}
