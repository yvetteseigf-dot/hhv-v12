package com.example.hhggk.module.misc;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.ShulkerBoxScreenHandler;
import net.minecraft.screen.slot.SlotActionType;

/** Takes everything out of an open chest / barrel / shulker, one stack at a time. */
public class ChestStealer extends Module {
    public final Setting.Num delay = add(new Setting.Num("Delay (ticks)", 1, 0, 10, 1));

    private int cd;

    public ChestStealer() { super("ChestStealer", Category.MISC); }

    @Override
    public void onTick(MinecraftClient mc) {
        if (!(mc.currentScreen instanceof HandledScreen<?> hs) || mc.interactionManager == null) return;
        ScreenHandler h = hs.getScreenHandler();
        if (!(h instanceof GenericContainerScreenHandler) && !(h instanceof ShulkerBoxScreenHandler)) return;
        if (cd-- > 0) return;
        int n = h.slots.size() - 36;
        for (int i = 0; i < n; i++) {
            if (!h.getSlot(i).getStack().isEmpty()) {
                mc.interactionManager.clickSlot(h.syncId, i, 0, SlotActionType.QUICK_MOVE, mc.player);
                cd = (int) delay.value;
                return;
            }
        }
    }
}
