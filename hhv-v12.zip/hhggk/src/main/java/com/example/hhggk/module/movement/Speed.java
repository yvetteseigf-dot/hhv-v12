package com.example.hhggk.module.movement;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.Move;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

public class Speed extends Module {
    public final Setting.Mode mode = add(new Setting.Mode("Mode",
            "Basic", "BHop", "LowHop", "Strafe", "Ground", "Ramp", "Pulse"));
    public final Setting.Num speed = add(new Setting.Num("Speed", 0.45, 0.1, 3.0, 0.05));
    public final Setting.Bool autoJump = add(new Setting.Bool("Auto jump (Basic)", false));

    private double ramp;
    private int pulse;

    public Speed() { super("Speed", Category.MOVEMENT); }

    @Override
    public void onDisable() { ramp = 0; pulse = 0; }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (mc.currentScreen != null || p.isGliding()) return;

        Vec3d dir = Move.horizontal(mc, 1.0);
        if (dir.lengthSquared() == 0) { ramp = 0; pulse = 0; return; }

        Vec3d cur = p.getVelocity();
        double base = speed.value;
        double vy = cur.y;
        double sp = base;

        switch (mode.get()) {
            case "BHop" -> {
                if (p.isOnGround()) vy = 0.42;
                sp = p.isOnGround() ? base : base * 0.95;
            }
            case "LowHop" -> {
                if (p.isOnGround()) vy = 0.2;
            }
            case "Strafe" -> {
                double cs = Math.hypot(cur.x, cur.z);
                sp = Math.min(Math.max(cs, base * 0.7), base * 1.6);
            }
            case "Ground" -> {
                if (!p.isOnGround()) return;
            }
            case "Ramp" -> {
                if (ramp <= 0) ramp = base * 0.4;
                ramp = Math.min(base, ramp + base * 0.06);
                sp = ramp;
            }
            case "Pulse" -> {
                pulse++;
                sp = (pulse % 8 < 4) ? base : base * 0.35;
            }
            default -> {
                if (autoJump.value && p.isOnGround()) vy = 0.42;
            }
        }
        p.setVelocity(dir.x * sp, vy, dir.z * sp);
    }
}
