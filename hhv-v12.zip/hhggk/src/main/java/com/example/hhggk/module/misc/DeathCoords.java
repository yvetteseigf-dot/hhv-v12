package com.example.hhggk.module.misc;

import com.example.hhggk.module.Module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;

/** Prints the coordinates of the place where you died. */
public class DeathCoords extends Module {
    private Vec3d last = Vec3d.ZERO;
    private boolean said;

    public DeathCoords() { super("DeathCoords", Category.MISC); }

    @Override
    public void onTick(MinecraftClient mc) {
        if (mc.player.isAlive() && mc.player.getHealth() > 0) {
            last = mc.player.getPos();
            said = false;
        } else if (!said) {
            said = true;
            mc.player.sendMessage(Text.literal(String.format("[Diamond] You died at %.0f %.0f %.0f",
                    last.x, last.y, last.z)), false);
        }
    }
}
