package com.example.hhggk.module.movement;

import com.example.hhggk.module.BlockUtil;
import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

/** While you fall / stand over a hole, centers you in it and stops sideways drift. */
public class HoleAnchor extends Module {
    public final Setting.Num depth = add(new Setting.Num("Look down (blocks)", 3, 1, 5, 1));
    public final Setting.Bool needSneakOff = add(new Setting.Bool("Not while moving keys held", false));

    public HoleAnchor() { super("HoleAnchor", Category.MOVEMENT); }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p.getAbilities().flying || p.isGliding()) return;
        if (needSneakOff.value && (mc.options.forwardKey.isPressed() || mc.options.backKey.isPressed()
                || mc.options.leftKey.isPressed() || mc.options.rightKey.isPressed())) return;
        BlockPos top = BlockPos.ofFloored(p.getX(), p.getY() + 0.1, p.getZ());
        for (int i = 0; i <= (int) depth.value; i++) {
            BlockPos pos = top.down(i);
            if (!BlockUtil.isHole(mc, pos)) continue;
            double cx = pos.getX() + 0.5, cz = pos.getZ() + 0.5;
            double dx = cx - p.getX(), dz = cz - p.getZ();
            if (Math.abs(dx) > 0.6 || Math.abs(dz) > 0.6) return;
            Vec3d v = p.getVelocity();
            p.setVelocity(dx * 0.5, v.y, dz * 0.5);
            return;
        }
    }
}
