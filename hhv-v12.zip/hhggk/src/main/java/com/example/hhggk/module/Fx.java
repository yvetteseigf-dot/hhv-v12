package com.example.hhggk.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;

/** Particle helpers. Particles are spawned as "important" so they show even with Particles = Minimal. */
public class Fx {
    public static final String[] PARTICLES = {"End rod", "Flame", "Soul flame", "Crit", "Enchant", "Totem"};

    public static ParticleEffect particle(String name) {
        return switch (name) {
            case "Flame" -> ParticleTypes.FLAME;
            case "Soul flame" -> ParticleTypes.SOUL_FIRE_FLAME;
            case "Crit" -> ParticleTypes.CRIT;
            case "Enchant" -> ParticleTypes.ENCHANT;
            case "Totem" -> ParticleTypes.TOTEM_OF_UNDYING;
            default -> ParticleTypes.END_ROD;
        };
    }

    public static void add(MinecraftClient mc, ParticleEffect e, double x, double y, double z,
                           double vx, double vy, double vz) {
        if (mc.world == null) return;
        mc.world.addImportantParticle(e, x, y, z, vx, vy, vz);
    }
}
