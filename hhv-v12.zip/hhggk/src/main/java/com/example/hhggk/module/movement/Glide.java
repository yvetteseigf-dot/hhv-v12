package com.example.hhggk.module.movement;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

/** Slow falling. */
public class Glide extends Module {
    public final Setting.Num fall = add(new Setting.Num("Fall speed", 0.1, 0.02, 0.5, 0.02));

    public Glide() { super("Glide", Category.MOVEMENT); }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p.isOnGround() || p.isGliding()) return;
        Vec3d v = p.getVelocity();
        if (v.y < -fall.value) p.setVelocity(v.x, -fall.value, v.z);
    }
}
