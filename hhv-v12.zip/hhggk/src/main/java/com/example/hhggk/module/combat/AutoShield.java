package com.example.hhggk.module.combat;

import com.example.hhggk.module.EntityFilter;
import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;

/** Holds your shield up while an enemy player is close. */
public class AutoShield extends Module {
    public final Setting.Num range = add(new Setting.Num("Enemy range", 6, 2, 15, 0.5));
    private boolean pressed;

    public AutoShield() { super("AutoShield", Category.COMBAT); }

    @Override
    public void onTick(MinecraftClient mc) {
        boolean shield = mc.player.getOffHandStack().isOf(Items.SHIELD) || mc.player.getMainHandStack().isOf(Items.SHIELD);
        boolean near = false;
        if (shield && mc.currentScreen == null) {
            for (PlayerEntity e : mc.world.getPlayers()) {
                if (EntityFilter.kind(e, mc.player) == 0 && mc.player.distanceTo(e) <= range.value) { near = true; break; }
            }
        }
        if (near) { mc.options.useKey.setPressed(true); pressed = true; }
        else if (pressed) { mc.options.useKey.setPressed(false); pressed = false; }
    }

    @Override
    public void onDisable() {
        if (pressed) MinecraftClient.getInstance().options.useKey.setPressed(false);
        pressed = false;
    }
}
