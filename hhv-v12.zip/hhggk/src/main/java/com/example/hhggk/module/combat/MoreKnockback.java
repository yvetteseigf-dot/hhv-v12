package com.example.hhggk.module.combat;

import com.example.hhggk.module.Module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;

/** Sprint-reset packets right before every hit = extra knockback on the target. Hooked in AttackMixin. */
public class MoreKnockback extends Module {
    public static MoreKnockback instance;

    public MoreKnockback() { super("MoreKnockback", Category.COMBAT); instance = this; }

    public static void onAttack(MinecraftClient mc, Entity target) {
        MoreKnockback m = instance;
        if (m == null || !m.enabled || mc.getNetworkHandler() == null || !(target instanceof LivingEntity)) return;
        if (!mc.player.isSprinting()) return;
        mc.getNetworkHandler().sendPacket(new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.STOP_SPRINTING));
        mc.getNetworkHandler().sendPacket(new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.START_SPRINTING));
    }
}
