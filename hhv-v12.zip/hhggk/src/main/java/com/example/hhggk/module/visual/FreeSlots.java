package com.example.hhggk.module.visual;

import com.example.hhggk.module.HudText;

import net.minecraft.client.MinecraftClient;


public class FreeSlots extends HudText {

    public FreeSlots() { super("FreeSlots", Category.VISUAL, 100, 50); }

    @Override
    protected String text(MinecraftClient mc) {
        int n = 0;
        for (int i = 0; i < 36; i++) if (mc.player.getInventory().getStack(i).isEmpty()) n++;
        return "Free slots " + n;
    }
}
