package com.example.hhggk.module.visual;

import com.example.hhggk.module.HudText;

import net.minecraft.client.MinecraftClient;


public class BiomeHud extends HudText {

    public BiomeHud() { super("BiomeHud", Category.VISUAL, 0, 48); }

    @Override
    protected String text(MinecraftClient mc) {
        return mc.world.getBiome(mc.player.getBlockPos()).getKey()
                .map(k -> k.getValue().getPath()).orElse("unknown");
    }
}
