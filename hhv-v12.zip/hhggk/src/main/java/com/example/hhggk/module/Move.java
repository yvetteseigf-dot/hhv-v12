package com.example.hhggk.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.GameOptions;
import net.minecraft.util.math.Vec3d;

public class Move {
    /** Horizontal velocity from the movement keys (blocks per tick). ZERO if no key pressed. */
    public static Vec3d horizontal(MinecraftClient mc, double speed) {
        GameOptions o = mc.options;
        double f = (o.forwardKey.isPressed() ? 1 : 0) - (o.backKey.isPressed() ? 1 : 0);
        double s = (o.leftKey.isPressed() ? 1 : 0) - (o.rightKey.isPressed() ? 1 : 0);
        if (f == 0 && s == 0) return Vec3d.ZERO;
        double len = Math.sqrt(f * f + s * s);
        f /= len; s /= len;
        double yaw = Math.toRadians(mc.player.getYaw());
        double sin = Math.sin(yaw), cos = Math.cos(yaw);
        return new Vec3d((-sin * f + cos * s) * speed, 0, (cos * f + sin * s) * speed);
    }
}
