package com.example.hhggk.mixin;

import com.example.hhggk.Settings;
import com.example.hhggk.module.visual.CustomCrosshair;
import com.example.hhggk.module.ModuleManager;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Hides the vanilla crosshair while the custom Crosshair module is on. */
@Mixin(InGameHud.class)
public class HudMixin {
    @Inject(method = "renderCrosshair", at = @At("HEAD"), cancellable = true)
    private void hhggk$crosshair(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
        for (var m : ModuleManager.modules) {
            if (m instanceof CustomCrosshair && m.enabled && Settings.active()) { ci.cancel(); return; }
        }
    }
}
