package com.example.hhggk.module.movement;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.Vec3d;

/** Extra forward push at the moment you jump. */
public class LongJump extends Module {
    public final Setting.Num boost = add(new Setting.Num("Boost", 1.6, 1.0, 3.0, 0.1));
    private boolean wasGround;

    public LongJump() { super("LongJump", Category.MOVEMENT); }

    @Override
    public void onTick(MinecraftClient mc) {
        boolean g = mc.player.isOnGround();
        Vec3d v = mc.player.getVelocity();
        if (wasGround && !g && v.y > 0.3 && mc.options.forwardKey.isPressed() && !mc.player.isGliding()) {
            mc.player.setVelocity(v.x * boost.value, v.y, v.z * boost.value);
        }
        wasGround = g;
    }
}
