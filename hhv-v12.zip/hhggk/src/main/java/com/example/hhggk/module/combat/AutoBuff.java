package com.example.hhggk.module.combat;

import com.example.hhggk.module.EntityFilter;
import com.example.hhggk.module.Inv;
import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.Hand;

/** Throws splash Strength / Speed / Fire resistance / Resistance potions at your feet when the effect ran out. */
public class AutoBuff extends Module {
    public final Setting.Bool strength = add(new Setting.Bool("Strength", true));
    public final Setting.Bool speed = add(new Setting.Bool("Speed", true));
    public final Setting.Bool resistance = add(new Setting.Bool("Resistance", false));
    public final Setting.Bool fire = add(new Setting.Bool("Fire resistance", false));
    public final Setting.Num enemyRange = add(new Setting.Num("Only if enemy within (0 = always)", 20, 0, 60, 5));
    public final Setting.Num delay = add(new Setting.Num("Delay (ticks)", 10, 2, 40, 1));

    private int cd;

    public AutoBuff() { super("AutoBuff", Category.COMBAT); }

    private boolean need(ClientPlayerEntity p, boolean on, RegistryEntry<StatusEffect> e) {
        return on && !p.hasStatusEffect(e);
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (cd-- > 0 || mc.interactionManager == null || mc.currentScreen != null) return;
        if (enemyRange.value > 0) {
            boolean near = false;
            for (PlayerEntity e : mc.world.getPlayers()) {
                if (EntityFilter.kind(e, p) == 0 && p.distanceTo(e) <= enemyRange.value) { near = true; break; }
            }
            if (!near) return;
        }
        RegistryEntry<StatusEffect> want = null;
        if (need(p, strength.value, StatusEffects.STRENGTH)) want = StatusEffects.STRENGTH;
        else if (need(p, speed.value, StatusEffects.SPEED)) want = StatusEffects.SPEED;
        else if (need(p, resistance.value, StatusEffects.RESISTANCE)) want = StatusEffects.RESISTANCE;
        else if (need(p, fire.value, StatusEffects.FIRE_RESISTANCE)) want = StatusEffects.FIRE_RESISTANCE;
        if (want == null) return;
        final RegistryEntry<StatusEffect> w = want;
        int slot = Inv.hotbar(p, s -> Inv.isSplash(s) && Inv.hasPotionEffect(s, w));
        if (slot < 0) return;
        int prev = p.getInventory().selectedSlot;
        float pitch = p.getPitch();
        p.getInventory().selectedSlot = slot;
        p.setPitch(90f);
        mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
        p.swingHand(Hand.MAIN_HAND);
        p.setPitch(pitch);
        p.getInventory().selectedSlot = prev;
        cd = (int) delay.value;
    }
}
