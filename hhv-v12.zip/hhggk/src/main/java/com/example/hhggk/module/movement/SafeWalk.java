package com.example.hhggk.module.movement;

import com.example.hhggk.module.Module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

/** Sneaks automatically at the edge of a block so you never walk off. */
public class SafeWalk extends Module {
    private boolean pressed;

    public SafeWalk() { super("SafeWalk", Category.MOVEMENT); }

    @Override
    public void onDisable() {
        if (pressed) MinecraftClient.getInstance().options.sneakKey.setPressed(false);
        pressed = false;
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        boolean edge = false;
        if (p.isOnGround() && mc.currentScreen == null) {
            Vec3d v = p.getVelocity();
            double px = p.getX() + v.x * 3.0, pz = p.getZ() + v.z * 3.0;
            BlockPos below = BlockPos.ofFloored(px, p.getY() - 0.5, pz);
            edge = mc.world.getBlockState(below).getCollisionShape(mc.world, below).isEmpty();
        }
        if (edge) { mc.options.sneakKey.setPressed(true); pressed = true; }
        else if (pressed) { mc.options.sneakKey.setPressed(false); pressed = false; }
    }
}
