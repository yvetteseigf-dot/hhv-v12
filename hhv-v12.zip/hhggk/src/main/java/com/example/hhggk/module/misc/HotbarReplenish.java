package com.example.hhggk.module.misc;

import com.example.hhggk.module.Inv;
import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

/** When a hotbar stack runs out (totems, crystals, pearls, gapples...), refills the slot from your inventory. */
public class HotbarReplenish extends Module {
    public final Setting.Num delay = add(new Setting.Num("Delay (ticks)", 3, 1, 20, 1));

    private final Item[] last = new Item[9];
    private int cd;

    public HotbarReplenish() { super("HotbarReplenish", Category.MISC); }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (mc.interactionManager == null || p.currentScreenHandler != p.playerScreenHandler) return;
        for (int i = 0; i < 9; i++) {
            ItemStack s = p.getInventory().getStack(i);
            if (!s.isEmpty()) { last[i] = s.getItem(); continue; }
            if (last[i] == null || last[i] == Items.AIR || cd-- > 0) continue;
            for (int j = 9; j < 36; j++) {
                if (p.getInventory().getStack(j).isOf(last[i])) {
                    mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, j, i, SlotActionType.SWAP, p);
                    cd = (int) delay.value;
                    last[i] = null;
                    return;
                }
            }
            last[i] = null;
        }
    }
}
