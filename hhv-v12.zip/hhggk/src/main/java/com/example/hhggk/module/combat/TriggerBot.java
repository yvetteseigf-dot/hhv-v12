package com.example.hhggk.module.combat;

import com.example.hhggk.module.EntityFilter;
import com.example.hhggk.module.Setting;
import com.example.hhggk.module.TargetModule;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Hand;

/** Attacks whatever is under your crosshair, once per full 1.9 cooldown. */
public class TriggerBot extends TargetModule {
    public final Setting.Bool critOnly = add(new Setting.Bool("Only crits (falling)", false));
    public final Setting.Bool noShield = add(new Setting.Bool("Skip blocking targets", false));

    public TriggerBot() { super("TriggerBot", Category.COMBAT, true, false, false, false); }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (mc.currentScreen != null || mc.interactionManager == null || p.isUsingItem()) return;
        Entity t = mc.targetedEntity;
        if (!(t instanceof LivingEntity le) || !le.isAlive()) return;
        int k = EntityFilter.kind(t, p);
        if (k < 0 || !allows(k)) return;
        if (noShield.value && le.isBlocking()) return;
        if (p.getAttackCooldownProgress(0.5f) < 0.99f) return;
        if (critOnly.value && (p.isOnGround() || p.getVelocity().y >= 0 || p.isClimbing() || p.isTouchingWater())) return;
        mc.interactionManager.attackEntity(p, t);
        p.swingHand(Hand.MAIN_HAND);
    }
}
