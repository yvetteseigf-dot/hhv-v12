package com.example.hhggk.module;

import net.minecraft.util.math.Vec3d;

public class Rot {
    public static float yawTo(Vec3d from, Vec3d to) {
        return (float) (Math.atan2(to.z - from.z, to.x - from.x) * 180.0 / Math.PI) - 90f;
    }

    public static float pitchTo(Vec3d from, Vec3d to) {
        double dx = to.x - from.x, dz = to.z - from.z;
        return (float) -(Math.atan2(to.y - from.y, Math.sqrt(dx * dx + dz * dz)) * 180.0 / Math.PI);
    }
}
