package com.example.hhggk.module.visual;

import com.example.hhggk.module.HudText;

import net.minecraft.client.MinecraftClient;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class ClockHud extends HudText {

    public ClockHud() { super("ClockHud", Category.VISUAL, 100, 0); }

    @Override
    protected String text(MinecraftClient mc) {
        return LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss"));
    }
}
