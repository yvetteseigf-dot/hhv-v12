package com.example.hhggk.module.combat;

import com.example.hhggk.module.EntityFilter;
import com.example.hhggk.module.Rot;
import com.example.hhggk.module.Setting;
import com.example.hhggk.module.TargetModule;
import com.example.hhggk.module.misc.FakePlayer;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public class Aura extends TargetModule {
    public final Setting.Mode mode = add(new Setting.Mode("Mode", "Single", "Switch", "Multi"));
    public final Setting.Mode sort = add(new Setting.Mode("Priority", "Distance", "Health", "Angle"));
    public final Setting.Num range = add(new Setting.Num("Range", 3.5, 1.0, 6.0, 0.1));
    public final Setting.Num delay = add(new Setting.Num("Delay (ticks) 20 = 1/sec", 20, 1, 40, 1));
    public final Setting.Bool longRange = add(new Setting.Bool("Long range (nearest loaded)", false));
    public final Setting.Num longDist = add(new Setting.Num("Long range distance", 100, 10, 150, 5));
    public final Setting.Bool airOnly = add(new Setting.Bool("Long range only in air", false));
    public final Setting.Num multi = add(new Setting.Num("Multi targets", 3, 1, 8, 1));
    public final Setting.Num fov = add(new Setting.Num("FOV limit", 360, 30, 360, 10));
    public final Setting.Num hitChance = add(new Setting.Num("Hit chance %", 100, 10, 100, 5));
    public final Setting.Bool crits = add(new Setting.Bool("Criticals (jump)", false));
    public final Setting.Bool autoWeapon = add(new Setting.Bool("Auto weapon", false));
    public final Setting.Bool walls = add(new Setting.Bool("Through walls", false));
    public final Setting.Bool invisible = add(new Setting.Bool("Invisible", true));
    public final Setting.Bool rotate = add(new Setting.Bool("Rotate", true));
    public final Setting.Mode rotMode = add(new Setting.Mode("Rotation mode", "HvH", "Smooth", "Legit", "Snap"));
    public final Setting.Mode aimAt = add(new Setting.Mode("Aim at", "Body", "Head"));
    public final Setting.Num rotSpeed = add(new Setting.Num("Smooth speed (deg/tick)", 25, 2, 180, 1));
    public final Setting.Bool shieldBreak = add(new Setting.Bool("Break shields (axe)", true));

    public LivingEntity lastTarget;
    public long lastHit;
    private int switchIndex;
    private int timer;

    private boolean longActive(ClientPlayerEntity p) {
        return longRange.value && (!airOnly.value || !p.isOnGround() || p.isGliding());
    }

    private double reach(ClientPlayerEntity p) {
        return longActive(p) ? longDist.value : range.value;
    }

    public Aura() { super("Aura", Category.COMBAT, true, true, false, false); }

    @Override public void onEnable() { timer = 999; }

    private boolean valid(ClientPlayerEntity p, LivingEntity e) {
        int k = EntityFilter.kind(e, p);
        if (k < 0 || !allows(k)) return false;
        if (!e.isAlive() || e.isSpectator() || e.getHealth() <= 0) return false;
        if (e.isInvisible() && !invisible.value) return false;
        double r = reach(p);
        if (EntityFilter.distSqToBox(p.getEyePos(), e.getBoundingBox()) > r * r) return false;
        if (fov.value < 360) {
            Vec3d eye = p.getEyePos(), c = e.getBoundingBox().getCenter();
            if (Math.abs(MathHelper.wrapDegrees(Rot.yawTo(eye, c) - p.getYaw())) > fov.value / 2) return false;
        }
        if (!walls.value && !longActive(p) && !p.canSee(e)) return false;
        return true;
    }

    private double angle(ClientPlayerEntity p, LivingEntity e) {
        Vec3d eye = p.getEyePos(), c = e.getBoundingBox().getCenter();
        return Math.abs(MathHelper.wrapDegrees(Rot.yawTo(eye, c) - p.getYaw()))
                + Math.abs(Rot.pitchTo(eye, c) - p.getPitch());
    }

    private void selectWeapon(ClientPlayerEntity p) {
        int best = -1;
        for (int i = 0; i < 9; i++) {
            ItemStack s = p.getInventory().getStack(i);
            if (s.isIn(ItemTags.SWORDS)) { best = i; break; }
            if (best < 0 && s.isIn(ItemTags.AXES)) best = i;
        }
        if (best >= 0) p.getInventory().selectedSlot = best;
    }

    private Vec3d aimPoint(LivingEntity e) {
        return aimAt.is("Head") ? e.getEyePos() : e.getBoundingBox().getCenter();
    }

    /** Called EVERY tick while a target exists, so the head stays glued to the enemy. */
    private void lookAt(ClientPlayerEntity p, LivingEntity e) {
        Vec3d eye = p.getEyePos(), c = aimPoint(e);
        float ty = Rot.yawTo(eye, c), tp = Rot.pitchTo(eye, c);
        switch (rotMode.get()) {
            case "Smooth", "Legit" -> {
                float step = (float) rotSpeed.value;
                if (rotMode.is("Legit")) {
                    step *= 0.6f + ThreadLocalRandom.current().nextFloat() * 0.8f;
                    ty += (ThreadLocalRandom.current().nextFloat() - 0.5f) * 1.2f;
                    tp += (ThreadLocalRandom.current().nextFloat() - 0.5f) * 0.8f;
                }
                float dy = MathHelper.wrapDegrees(ty - p.getYaw());
                float dp = tp - p.getPitch();
                p.setYaw(p.getYaw() + MathHelper.clamp(dy, -step, step));
                p.setPitch(MathHelper.clamp(p.getPitch() + MathHelper.clamp(dp, -step, step), -90f, 90f));
            }
            case "Snap" -> { }   // only at the moment of the hit (see hit())
            default -> {         // HvH: instant, locked on the target every tick
                p.setYaw(ty);
                p.setPitch(MathHelper.clamp(tp, -90f, 90f));
            }
        }
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (mc.interactionManager == null || mc.currentScreen != null) return;
        boolean ready = timer >= (int) delay.value;
        if (!ready) timer++;

        List<LivingEntity> list = new ArrayList<>(mc.world.getEntitiesByClass(
                LivingEntity.class, p.getBoundingBox().expand(reach(p) + 1), e -> valid(p, e)));
        if (FakePlayer.fake != null && valid(p, FakePlayer.fake)) FakePlayer.addTo(list);
        if (list.isEmpty()) return;

        Comparator<LivingEntity> cmp = switch (sort.get()) {
            case "Health" -> Comparator.comparingDouble(LivingEntity::getHealth);
            case "Angle" -> Comparator.comparingDouble(e -> angle(p, e));
            default -> Comparator.comparingDouble(e -> EntityFilter.distSqToBox(p.getEyePos(), e.getBoundingBox()));
        };
        list.sort(cmp);

        // keep the head on the enemy all the time (not only when hitting)
        LivingEntity focus = mode.is("Switch") ? list.get(switchIndex % list.size()) : list.get(0);
        if (rotate.value) lookAt(p, focus);
        if (!ready) return;

        // Criticals: jump first, hit while falling
        if (crits.value && !(p.isTouchingWater() || p.isGliding() || p.isClimbing())) {
            if (p.isOnGround()) {
                Vec3d v = p.getVelocity();
                p.setVelocity(v.x, 0.42, v.z);
                return;
            }
            if (p.getVelocity().y > 0) return;
        }

        if (hitChance.value < 100 && ThreadLocalRandom.current().nextInt(100) >= (int) hitChance.value) return;
        if (autoWeapon.value) selectWeapon(p);

        switch (mode.get()) {
            case "Switch" -> {
                switchIndex = (switchIndex + 1) % list.size();
                hit(mc, p, list.get(switchIndex));
            }
            case "Multi" -> {
                int n = Math.min((int) multi.value, list.size());
                for (int i = 0; i < n; i++) hit(mc, p, list.get(i));
            }
            default -> hit(mc, p, list.get(0));
        }
    }

    private void selectAxe(ClientPlayerEntity p) {
        for (int i = 0; i < 9; i++) {
            if (p.getInventory().getStack(i).isIn(ItemTags.AXES)) { p.getInventory().selectedSlot = i; return; }
        }
    }

    private void hit(MinecraftClient mc, ClientPlayerEntity p, LivingEntity e) {
        if (shieldBreak.value && e.isBlocking()) selectAxe(p);
        if (rotate.value && rotMode.is("Snap")) {
            Vec3d eye = p.getEyePos(), c = aimPoint(e);
            p.setYaw(Rot.yawTo(eye, c));
            p.setPitch(Rot.pitchTo(eye, c));
        }
        lastTarget = e;
        lastHit = System.currentTimeMillis();
        timer = 0;
        mc.interactionManager.attackEntity(p, e);
        p.swingHand(Hand.MAIN_HAND);
    }
}
