package com.example.hhggk.module.combat;

import com.example.hhggk.module.BlockUtil;
import com.example.hhggk.module.Inv;
import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.math.BlockPos;

/** One-shot: puts an obsidian block inside your own feet (crystals can not hurt you from below). Turns itself off. */
public class Burrow extends Module {
    public final Setting.Num rubberband = add(new Setting.Num("Rubberband offset", 1.2, -2.0, 3.0, 0.1));

    public Burrow() { super("Burrow", Category.COMBAT); }

    @Override
    public void onEnable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        enabled = false;                                       // single use
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.getNetworkHandler() == null) return;
        int slot = Inv.hotbar(p, Items.OBSIDIAN);
        if (slot < 0 || !p.isOnGround()) {
            p.sendMessage(net.minecraft.text.Text.literal("[Diamond] Burrow: need obsidian in the hotbar and stand on the ground."), true);
            return;
        }
        BlockPos feet = BlockPos.ofFloored(p.getX(), p.getY() + 0.1, p.getZ());
        double x = p.getX(), y = p.getY(), z = p.getZ();
        double[] up = {0.4199999, 0.7531999, 1.0013359, 1.1661093};
        for (double u : up) {
            mc.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(x, y + u, z, false, false));
        }
        BlockUtil.place(mc, feet, slot);
        mc.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(x, y + rubberband.value, z, false, false));
    }
}
