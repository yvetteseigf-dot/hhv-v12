package com.example.hhggk.module.render;

import com.example.hhggk.module.EntityFilter;
import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.LivingEntity;

public class Radar extends Module {
    public final Setting.Num range = add(new Setting.Num("Range", 40, 10, 100, 5));
    public final Setting.Num size = add(new Setting.Num("Size", 50, 30, 90, 5));
    public final Setting.Bool playersOnly = add(new Setting.Bool("Players only", false));

    public Radar() { super("Radar", Category.RENDER); }

    @Override
    public void onHud(DrawContext ctx, MinecraftClient mc) {
        var p = mc.player;
        int s = (int) size.value;
        int cx = s + 6, cy = ctx.getScaledWindowHeight() / 2;
        ctx.fill(cx - s, cy - s, cx + s, cy + s, 0x90101018);
        ctx.fill(cx - 1, cy - 1, cx + 2, cy + 2, 0xFFFFFFFF);

        double yaw = Math.toRadians(p.getYaw());
        double sin = Math.sin(yaw), cos = Math.cos(yaw);
        double scale = s / range.value;

        for (LivingEntity e : mc.world.getEntitiesByClass(LivingEntity.class,
                p.getBoundingBox().expand(range.value), x -> EntityFilter.kind(x, p) >= 0)) {
            int k = EntityFilter.kind(e, p);
            if (playersOnly.value && k != 0) continue;
            double dx = e.getX() - p.getX(), dz = e.getZ() - p.getZ();
            double right = -dx * cos - dz * sin;
            double fwd = -dx * sin + dz * cos;
            int sx = cx + (int) (right * scale), sy = cy - (int) (fwd * scale);
            if (sx < cx - s + 1 || sx > cx + s - 2 || sy < cy - s + 1 || sy > cy + s - 2) continue;
            int color = switch (k) {
                case 0 -> 0xFFFF4040;
                case 1 -> 0xFFFFA030;
                case 2 -> 0xFF50D060;
                default -> 0xFFAAAAAA;
            };
            ctx.fill(sx - 1, sy - 1, sx + 2, sy + 2, color);
        }
    }
}
