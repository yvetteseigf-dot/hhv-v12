package com.example.hhggk.module.combat;

import com.example.hhggk.module.EntityFilter;
import com.example.hhggk.module.Rot;
import com.example.hhggk.module.Setting;
import com.example.hhggk.module.TargetModule;
import com.example.hhggk.module.misc.FakePlayer;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/** Gently pulls your aim towards the closest target inside your field of view. */
public class AimAssist extends TargetModule {
    public final Setting.Num range = add(new Setting.Num("Range", 5.0, 2.0, 12.0, 0.5));
    public final Setting.Num fov = add(new Setting.Num("FOV", 90, 10, 360, 10));
    public final Setting.Num speed = add(new Setting.Num("Speed (deg/tick)", 6, 1, 40, 1));
    public final Setting.Bool onlyAttack = add(new Setting.Bool("Only while attacking", false));

    public AimAssist() { super("AimAssist", Category.COMBAT, true, false, false, false); }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (mc.currentScreen != null || (onlyAttack.value && !mc.options.attackKey.isPressed())) return;
        LivingEntity best = null;
        double bd = Double.MAX_VALUE;
        List<LivingEntity> cands = new ArrayList<>(mc.world.getEntitiesByClass(LivingEntity.class,
                p.getBoundingBox().expand(range.value + 1), x -> x.isAlive()));
        FakePlayer.addTo(cands);
        for (LivingEntity e : cands) {
            int k = EntityFilter.kind(e, p);
            if (k < 0 || !allows(k)) continue;
            double d = EntityFilter.distSqToBox(p.getEyePos(), e.getBoundingBox());
            if (d > range.value * range.value) continue;
            Vec3d c = e.getBoundingBox().getCenter();
            if (Math.abs(MathHelper.wrapDegrees(Rot.yawTo(p.getEyePos(), c) - p.getYaw())) > fov.value / 2) continue;
            if (d < bd) { bd = d; best = e; }
        }
        if (best == null) return;
        Vec3d c = best.getBoundingBox().getCenter();
        float dy = MathHelper.wrapDegrees(Rot.yawTo(p.getEyePos(), c) - p.getYaw());
        float dp = Rot.pitchTo(p.getEyePos(), c) - p.getPitch();
        float s = (float) speed.value;
        p.setYaw(p.getYaw() + MathHelper.clamp(dy, -s, s));
        p.setPitch(MathHelper.clamp(p.getPitch() + MathHelper.clamp(dp, -s, s), -90f, 90f));
    }
}
