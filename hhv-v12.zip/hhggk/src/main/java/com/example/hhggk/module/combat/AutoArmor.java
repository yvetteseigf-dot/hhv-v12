package com.example.hhggk.module.combat;

import com.example.hhggk.module.Inv;
import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

/** Wears the best armor from your inventory (replaces broken / weaker pieces). Skips the chest slot while you wear an elytra. */
public class AutoArmor extends Module {
    public final Setting.Num delay = add(new Setting.Num("Delay (ticks)", 3, 1, 20, 1));
    public final Setting.Bool keepElytra = add(new Setting.Bool("Keep elytra on", true));

    private int cd;

    public AutoArmor() { super("AutoArmor", Category.COMBAT); }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (cd-- > 0 || mc.interactionManager == null) return;
        if (p.currentScreenHandler != p.playerScreenHandler) return;
        for (int kind = 0; kind < 4; kind++) {
            int armorSlot = 5 + kind;                       // 5 head, 6 chest, 7 legs, 8 feet
            ItemStack worn = p.playerScreenHandler.getSlot(armorSlot).getStack();
            if (kind == 1 && keepElytra.value && worn.isOf(Items.ELYTRA)) continue;
            double bestScore = Inv.armorScore(worn);
            int bestInv = -1;
            for (int i = 0; i < 36; i++) {
                ItemStack s = p.getInventory().getStack(i);
                if (Inv.armorKind(s) != kind) continue;
                double sc = Inv.armorScore(s);
                if (sc > bestScore + 0.5) { bestScore = sc; bestInv = i; }
            }
            if (bestInv >= 0) {
                Inv.swapSlots(mc, p, Inv.container(bestInv), armorSlot);
                cd = (int) delay.value;
                return;
            }
        }
    }
}
