package com.example.hhggk.module.movement;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;

/** Tells the server you are on the ground while falling, so you take no fall damage. */
public class NoFall extends Module {
    public final Setting.Num minFall = add(new Setting.Num("Min fall distance", 2.5, 1.0, 10.0, 0.5));

    public NoFall() { super("NoFall", Category.MOVEMENT); }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p.isGliding() || p.getAbilities().flying || mc.getNetworkHandler() == null) return;
        if (p.fallDistance > minFall.value) {
            mc.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.OnGroundOnly(true, false));
        }
    }
}
