package com.example.hhggk.module.visual;

import com.example.hhggk.module.Fx;
import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;

/** Expanding particle ring on the ground every time you jump. */
public class JumpCircles extends Module {
    public final Setting.Mode particle = add(new Setting.Mode("Particle", "End rod", "Flame", "Soul flame", "Crit", "Enchant", "Totem"));
    public final Setting.Num points = add(new Setting.Num("Points", 24, 8, 48, 2));
    private boolean wasGround = true;

    public JumpCircles() { super("JumpCircles", Category.VISUAL); }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        boolean ground = p.isOnGround();
        if (wasGround && !ground && p.getVelocity().y > 0.1) {
            var eff = Fx.particle(particle.get());
            int n = (int) points.value;
            for (int i = 0; i < n; i++) {
                double a = i * Math.PI * 2 / n;
                Fx.add(mc, eff, p.getX() + Math.cos(a) * 0.3, p.getY() + 0.05, p.getZ() + Math.sin(a) * 0.3,
                        Math.cos(a) * 0.12, 0.0, Math.sin(a) * 0.12);
            }
        }
        wasGround = ground;
    }
}
