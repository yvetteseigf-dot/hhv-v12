package com.example.hhggk.module.visual;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/** Red flash when you take damage, plus a permanent red edge when your health is low. */
public class HurtFlash extends Module {
    public final Setting.Num lowHealth = add(new Setting.Num("Low health edge (hp)", 8, 0, 20, 1));

    public HurtFlash() { super("HurtFlash", Category.VISUAL); }

    @Override
    public void onHud(DrawContext ctx, MinecraftClient mc) {
        int w = ctx.getScaledWindowWidth(), h = ctx.getScaledWindowHeight();
        if (mc.player.hurtTime > 0) {
            int a = Math.min(120, mc.player.hurtTime * 14);
            ctx.fill(0, 0, w, h, (a << 24) | 0xFF0000);
        }
        if (mc.player.getHealth() <= lowHealth.value) {
            int e = 14;
            int c = 0x80FF0000;
            ctx.fill(0, 0, w, e, c); ctx.fill(0, h - e, w, h, c);
            ctx.fill(0, 0, e, h, c); ctx.fill(w - e, 0, w, h, c);
        }
    }
}
