package com.example.hhggk.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;

public class Fireworks {
    public static long lastUse;

    /** Does the player have a rocket anywhere (offhand, hotbar or inventory)? */
    public static boolean has(ClientPlayerEntity p) {
        if (p.getOffHandStack().isOf(Items.FIREWORK_ROCKET)) return true;
        for (int i = 0; i < 36; i++) if (p.getInventory().getStack(i).isOf(Items.FIREWORK_ROCKET)) return true;
        return false;
    }

    /**
     * Uses a firework rocket from the offhand, the hotbar, or (new) the main inventory.
     * Inventory rockets are swapped into the selected hotbar slot, used, and swapped back.
     * Returns false if no rocket was found.
     */
    public static boolean use(MinecraftClient mc, ClientPlayerEntity p) {
        if (mc.interactionManager == null) return false;
        if (p.getOffHandStack().isOf(Items.FIREWORK_ROCKET)) {
            mc.interactionManager.interactItem(p, Hand.OFF_HAND);
            p.swingHand(Hand.OFF_HAND);
            lastUse = System.currentTimeMillis();
            return true;
        }
        for (int i = 0; i < 9; i++) {
            if (p.getInventory().getStack(i).isOf(Items.FIREWORK_ROCKET)) {
                int old = p.getInventory().selectedSlot;
                p.getInventory().selectedSlot = i;
                mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
                p.swingHand(Hand.MAIN_HAND);
                p.getInventory().selectedSlot = old;
                lastUse = System.currentTimeMillis();
                return true;
            }
        }
        // rockets in the main inventory (slots 9..35): swap into the selected hotbar slot
        if (p.currentScreenHandler == p.playerScreenHandler) {
            int sel = p.getInventory().selectedSlot;
            for (int i = 9; i < 36; i++) {
                if (p.getInventory().getStack(i).isOf(Items.FIREWORK_ROCKET)) {
                    int sync = p.playerScreenHandler.syncId;
                    mc.interactionManager.clickSlot(sync, i, sel, SlotActionType.SWAP, p);
                    mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
                    p.swingHand(Hand.MAIN_HAND);
                    mc.interactionManager.clickSlot(sync, i, sel, SlotActionType.SWAP, p);
                    lastUse = System.currentTimeMillis();
                    return true;
                }
            }
        }
        return false;
    }
}
