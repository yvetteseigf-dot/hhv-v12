package com.example.hhggk.module.visual;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

/**
 * Draws every entity's actual hitbox. Drawn by WorldRender using entity.getTargetingMargin(),
 * so with Hitbox enabled you see the expanded box (red) next to the vanilla one (gray).
 */
public class ShowHitboxes extends Module {
    public final Setting.Num range = add(new Setting.Num("Range", 48, 8, 128, 4));
    public final Setting.Bool playersOnly = add(new Setting.Bool("Players only", false));

    public ShowHitboxes() { super("ShowHitboxes", Category.VISUAL); }
}
