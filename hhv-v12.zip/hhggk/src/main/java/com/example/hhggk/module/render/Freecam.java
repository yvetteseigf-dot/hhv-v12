package com.example.hhggk.module.render;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.input.Input;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

/**
 * Free camera. Your body stays completely still while it is on:
 *  - the real input is swapped for an empty one (re-checked every tick),
 *  - horizontal speed is forced to 0, jumping is blocked,
 *  - optional position lock puts you back if anything pushed you.
 */
public class Freecam extends Module {
    public final Setting.Num speed = add(new Setting.Num("Speed", 1.0, 0.1, 5.0, 0.1));
    public final Setting.Bool lockBody = add(new Setting.Bool("Lock body position", true));

    public static double x, y, z;
    private Input saved;
    private Input blank;
    private double bx, bz;

    public Freecam() { super("Freecam", Category.RENDER); }

    @Override
    public void onEnable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) { enabled = false; return; }
        Vec3d e = mc.player.getEyePos();
        x = e.x; y = e.y; z = e.z;
        bx = mc.player.getX();
        bz = mc.player.getZ();
        saved = mc.player.input;
        blank = new Input() {};
        mc.player.input = blank;
        mc.player.setSprinting(false);
        Vec3d v = mc.player.getVelocity();
        mc.player.setVelocity(0, Math.min(0, v.y), 0);
    }

    @Override
    public void onDisable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null && saved != null) mc.player.input = saved;
        saved = null;
        blank = null;
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;

        // keep the body frozen (the game can put a fresh input back, so check every tick)
        if (blank != null && p.input != blank) {
            if (saved == null) saved = p.input;
            p.input = blank;
        }
        p.setSprinting(false);
        Vec3d v = p.getVelocity();
        p.setVelocity(0, Math.min(0, v.y), 0);       // no walking, no jumping (gravity still works)
        if (lockBody.value && Math.hypot(p.getX() - bx, p.getZ() - bz) > 0.02) {
            p.updatePosition(bx, p.getY(), bz);
        }

        if (mc.currentScreen != null) return;
        double f = (mc.options.forwardKey.isPressed() ? 1 : 0) - (mc.options.backKey.isPressed() ? 1 : 0);
        double s = (mc.options.leftKey.isPressed() ? 1 : 0) - (mc.options.rightKey.isPressed() ? 1 : 0);
        double up = (mc.options.jumpKey.isPressed() ? 1 : 0) - (mc.options.sneakKey.isPressed() ? 1 : 0);
        double yaw = Math.toRadians(p.getYaw());
        Vec3d left = new Vec3d(Math.cos(yaw), 0, Math.sin(yaw));
        Vec3d d = p.getRotationVec(1.0f).multiply(f).add(left.multiply(s)).add(0, up, 0);
        if (d.lengthSquared() > 0) {
            d = d.normalize().multiply(speed.value);
            x += d.x; y += d.y; z += d.z;
        }
    }
}
