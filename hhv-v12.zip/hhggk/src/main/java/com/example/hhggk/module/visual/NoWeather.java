package com.example.hhggk.module.visual;

import com.example.hhggk.module.Module;

import net.minecraft.client.MinecraftClient;

public class NoWeather extends Module {
    public NoWeather() { super("NoWeather", Category.VISUAL); }

    @Override
    public void onTick(MinecraftClient mc) {
        mc.world.setRainGradient(0f);
        mc.world.setThunderGradient(0f);
    }
}
