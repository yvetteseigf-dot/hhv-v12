package com.example.hhggk.module.movement;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

/** Jumps by itself at the edge of a block. */
public class Parkour extends Module {

    public Parkour() { super("Parkour", Category.MOVEMENT); }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (mc.currentScreen != null || !p.isOnGround() || p.isSneaking() || mc.options.jumpKey.isPressed()) return;
        if (!mc.options.forwardKey.isPressed() && !mc.options.backKey.isPressed()
                && !mc.options.leftKey.isPressed() && !mc.options.rightKey.isPressed()) return;
        double yaw = Math.toRadians(p.getYaw());
        Box b = p.getBoundingBox().offset(-Math.sin(yaw) * 0.4, -0.6, Math.cos(yaw) * 0.4);
        if (mc.world.isSpaceEmpty(p, b)) {
            Vec3d v = p.getVelocity();
            p.setVelocity(v.x, 0.42, v.z);
        }
    }
}
