package com.example.hhggk.module.visual;

import com.example.hhggk.module.HudText;

import net.minecraft.client.MinecraftClient;


public class FallDistanceHud extends HudText {

    public FallDistanceHud() { super("FallDistanceHud", Category.VISUAL, 50, 25); }

    @Override
    protected String text(MinecraftClient mc) {
        double f = mc.player.fallDistance;
        return f < 0.5 ? "" : String.format("Fall %.1f", f);
    }

    @Override
    protected int color(MinecraftClient mc) {
        return mc.player.fallDistance > 3 ? 0xFFFF5555 : 0xFFFFFF55;
    }
}
