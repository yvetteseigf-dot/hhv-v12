package com.example.hhggk.module;

import com.example.hhggk.module.visual.HitParticles;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Vec3d;

/** Shared combat state (combo, last target, kills) used by the Visual modules. */
public class Stats {
    public static int combo;
    public static long lastHit;
    public static LivingEntity lastTarget;
    public static boolean killPending;
    public static Vec3d killPos = Vec3d.ZERO;
    public static long killTime;
    private static int prevHurt;

    /** Called from AttackMixin before every attack the local player sends. */
    public static void onAttack(MinecraftClient mc, Entity target) {
        if (!(target instanceof LivingEntity le)) return;
        combo++;
        lastHit = System.currentTimeMillis();
        lastTarget = le;
        HitParticles hp = ModuleManager.hitParticles;
        if (hp != null && hp.enabled) hp.spawn(mc, le);
    }

    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p.hurtTime > 0 && prevHurt == 0) combo = 0;
        prevHurt = p.hurtTime;
        long now = System.currentTimeMillis();
        if (now - lastHit > 4000) combo = 0;
        if (lastTarget != null) {
            if (!lastTarget.isAlive() && now - lastHit < 2500 && killTime < lastHit) {
                killPending = true;
                killPos = lastTarget.getPos();
                killTime = now;
                lastTarget = null;
            } else if (now - lastHit > 6000) {
                lastTarget = null;
            }
        }
    }
}
