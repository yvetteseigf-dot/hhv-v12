package com.example.hhggk.module.misc;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.FoodComponent;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

/** Eats the best safe food from your hotbar when you are hungry. (Golden apples are left to AutoGap.) */
public class AutoEat extends Module {
    public final Setting.Num hunger = add(new Setting.Num("Eat below (food points)", 14, 2, 19, 1));

    private boolean eating;
    private int prevSlot = -1, ticks;

    public AutoEat() { super("AutoEat", Category.MISC); }

    private static boolean safe(ItemStack s) {
        return !(s.isOf(Items.ROTTEN_FLESH) || s.isOf(Items.SPIDER_EYE) || s.isOf(Items.POISONOUS_POTATO)
                || s.isOf(Items.PUFFERFISH) || s.isOf(Items.CHORUS_FRUIT) || s.isOf(Items.GOLDEN_APPLE)
                || s.isOf(Items.ENCHANTED_GOLDEN_APPLE) || s.isOf(Items.SUSPICIOUS_STEW));
    }

    private void stop(MinecraftClient mc, ClientPlayerEntity p) {
        mc.options.useKey.setPressed(false);
        if (prevSlot >= 0) p.getInventory().selectedSlot = prevSlot;
        prevSlot = -1; eating = false; ticks = 0;
    }

    @Override
    public void onDisable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (eating && mc.player != null) stop(mc, mc.player);
        eating = false;
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (!eating) {
            if (p.getHungerManager().getFoodLevel() >= hunger.value || mc.currentScreen != null || p.isUsingItem()) return;
            int slot = -1, best = 0;
            for (int i = 0; i < 9; i++) {
                ItemStack s = p.getInventory().getStack(i);
                FoodComponent f = s.get(DataComponentTypes.FOOD);
                if (f == null || !safe(s)) continue;
                if (f.nutrition() > best) { best = f.nutrition(); slot = i; }
            }
            if (slot < 0) return;
            prevSlot = p.getInventory().selectedSlot;
            p.getInventory().selectedSlot = slot;
            eating = true; ticks = 0;
            mc.options.useKey.setPressed(true);
        } else {
            ticks++;
            if ((!p.isUsingItem() && ticks > 3) || ticks > 70) stop(mc, p);
            else mc.options.useKey.setPressed(true);
        }
    }
}
