package com.example.hhggk.module.combat;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.ModuleManager;

import net.minecraft.entity.Entity;

/** Combat modules ignore players on your scoreboard team. */
public class Teams extends Module {
    public Teams() { super("Teams", Category.COMBAT); }

    public static boolean same(Entity self, Entity other) {
        Teams t = ModuleManager.teams;
        if (t == null || !t.enabled || self == null || other == null) return false;
        return self.isTeammate(other);
    }
}
