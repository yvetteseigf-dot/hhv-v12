package com.example.hhggk.module.misc;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;
import com.example.hhggk.module.Stats;

import net.minecraft.client.MinecraftClient;
import net.minecraft.sound.SoundEvents;

/** Plays a sound every time you hit something. */
public class HitSound extends Module {
    public final Setting.Num volume = add(new Setting.Num("Volume", 0.7, 0.1, 1.0, 0.1));
    public final Setting.Num pitch = add(new Setting.Num("Pitch", 1.4, 0.5, 2.0, 0.1));
    private long seen;

    public HitSound() { super("HitSound", Category.MISC); }

    @Override
    public void onTick(MinecraftClient mc) {
        if (Stats.lastHit != seen) {
            seen = Stats.lastHit;
            mc.player.playSound(SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, (float) volume.value, (float) pitch.value);
        }
    }
}
