package com.example.hhggk.module.misc;

import com.example.hhggk.Friends;
import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/** Tells you when a player enters your render distance (and how far away they are). */
public class VisualRange extends Module {
    public final Setting.Bool sound = add(new Setting.Bool("Sound", true));
    public final Setting.Bool ignoreFriends = add(new Setting.Bool("Ignore friends", true));

    private final Set<UUID> seen = new HashSet<>();

    public VisualRange() { super("VisualRange", Category.MISC); }

    @Override
    public void onEnable() { seen.clear(); }

    @Override
    public void onTick(MinecraftClient mc) {
        Set<UUID> now = new HashSet<>();
        for (PlayerEntity e : mc.world.getPlayers()) {
            if (e == mc.player || e == FakePlayer.fake) continue;
            now.add(e.getUuid());
            if (seen.contains(e.getUuid())) continue;
            String n = e.getName().getString();
            if (ignoreFriends.value && Friends.isFriend(n)) continue;
            mc.player.sendMessage(Text.literal(String.format("[Diamond] %s entered visual range (%.0f blocks)", n, mc.player.distanceTo(e))), false);
            if (sound.value) mc.player.playSound(SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, 0.8f, 0.7f);
        }
        seen.clear();
        seen.addAll(now);
    }
}
