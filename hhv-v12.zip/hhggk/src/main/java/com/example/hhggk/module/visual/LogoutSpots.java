package com.example.hhggk.module.visual;

import com.example.hhggk.module.Drawable3D;
import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;
import com.example.hhggk.render.Overlay3D;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/** Remembers where a player was when they left the server (box in the world + coordinates in chat). */
public class LogoutSpots extends Module implements Drawable3D {
    public final Setting.Num minutes = add(new Setting.Num("Keep for (minutes)", 5, 1, 30, 1));
    public final Setting.Bool chat = add(new Setting.Bool("Message in chat", true));

    private static class Spot { Vec3d pos; String name; long time; }
    private final Map<UUID, Vec3d> lastPos = new HashMap<>();
    private final Map<UUID, String> names = new HashMap<>();
    private final Map<UUID, Spot> spots = new HashMap<>();

    public LogoutSpots() { super("LogoutSpots", Category.VISUAL); }

    @Override
    public void onDisable() { lastPos.clear(); names.clear(); spots.clear(); }

    @Override
    public void onTick(MinecraftClient mc) {
        if (mc.getNetworkHandler() == null) return;
        Map<UUID, Vec3d> now = new HashMap<>();
        for (PlayerEntity e : mc.world.getPlayers()) {
            if (e == mc.player) continue;
            now.put(e.getUuid(), e.getPos());
            names.put(e.getUuid(), e.getName().getString());
            spots.remove(e.getUuid());
        }
        for (Map.Entry<UUID, Vec3d> en : lastPos.entrySet()) {
            UUID id = en.getKey();
            if (now.containsKey(id)) continue;
            if (mc.getNetworkHandler().getPlayerListEntry(id) != null) continue;   // still online, only out of range
            Spot s = new Spot();
            s.pos = en.getValue(); s.name = names.getOrDefault(id, "?"); s.time = System.currentTimeMillis();
            spots.put(id, s);
            if (chat.value) mc.player.sendMessage(Text.literal(String.format("[Diamond] %s logged out at %.0f %.0f %.0f",
                    s.name, s.pos.x, s.pos.y, s.pos.z)), false);
        }
        lastPos.clear();
        lastPos.putAll(now);
        long keep = (long) (minutes.value * 60_000);
        Iterator<Spot> it = spots.values().iterator();
        while (it.hasNext()) if (System.currentTimeMillis() - it.next().time > keep) it.remove();
    }

    @Override
    public void draw3d(MinecraftClient mc, MatrixStack ms, VertexConsumerProvider vcp, Vec3d cam, float td) {
        for (Spot s : spots.values()) {
            Box b = new Box(s.pos.x - 0.3, s.pos.y, s.pos.z - 0.3, s.pos.x + 0.3, s.pos.y + 1.8, s.pos.z + 0.3);
            Overlay3D.filled(ms, vcp, b, 1f, 0.5f, 0.1f, 0.25f);
            Overlay3D.outline(ms, vcp, b, 1f, 0.6f, 0.2f, 1f);
        }
    }
}
