package com.example.hhggk.module.movement;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

/** Climbs blocks automatically (jump-based). */
public class Step extends Module {
    public final Setting.Num height = add(new Setting.Num("Height", 1.5, 1.0, 2.5, 0.5));

    public Step() { super("Step", Category.MOVEMENT); }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (mc.currentScreen != null) return;
        if (p.horizontalCollision && p.isOnGround() && mc.options.forwardKey.isPressed()) {
            double v = 0.42 * Math.sqrt(height.value / 1.25);
            Vec3d cur = p.getVelocity();
            p.setVelocity(cur.x, v, cur.z);
        }
    }
}
