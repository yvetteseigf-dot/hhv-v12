package com.example.hhggk.module.misc;

import com.example.hhggk.module.Module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;

public class AutoSprint extends Module {
    public AutoSprint() { super("AutoSprint", Category.MISC); }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (mc.currentScreen == null && mc.options.forwardKey.isPressed()
                && !p.isSneaking() && p.getHungerManager().getFoodLevel() > 6) {
            p.setSprinting(true);
        }
    }
}
