package com.example.hhggk.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.InputUtil;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    public enum Category {
        COMBAT("Combat"), MOVEMENT("Movement"), VISUAL("Visual"), RENDER("Render"), MISC("Misc");
        public final String label;
        Category(String label) { this.label = label; }
    }

    public final String name;
    public final Category category;
    public boolean enabled;
    public boolean expanded;
    /** key bound with  .bind <module> <key>  (one press = on, next press = off) */
    public InputUtil.Key bind;
    public boolean bindWasDown;
    public final List<Setting> settings = new ArrayList<>();

    protected Module(String name, Category category) {
        this.name = name;
        this.category = category;
    }

    protected <T extends Setting> T add(T s) { settings.add(s); return s; }

    public void toggle() {
        enabled = !enabled;
        if (enabled) onEnable(); else onDisable();
    }

    public void onEnable() {}
    public void onDisable() {}
    public void onTick(MinecraftClient mc) {}
    public void onHud(DrawContext ctx, MinecraftClient mc) {}
}
