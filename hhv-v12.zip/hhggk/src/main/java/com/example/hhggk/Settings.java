package com.example.hhggk;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ServerInfo;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Settings {
    private static final Set<String> allowed = new HashSet<>();

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("hhggk-servers.txt");
    }

    public static void reload() {
        allowed.clear();
        try {
            Path f = file();
            if (!Files.exists(f)) {
                Files.writeString(f, "# Put allowed (HvH) server addresses here, one per line.\n# Example:\n# play.example.net\n");
                return;
            }
            List<String> lines = Files.readAllLines(f);
            for (String l : lines) {
                l = l.trim().toLowerCase();
                if (!l.isEmpty() && !l.startsWith("#")) allowed.add(norm(l));
            }
        } catch (Exception ignored) {}
    }

    /** Active in singleplayer, or on servers listed in config/hhggk-servers.txt */
    public static boolean active() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.isInSingleplayer()) return true;
        ServerInfo si = mc.getCurrentServerEntry();
        return si != null && allowed.contains(norm(si.address));
    }

    public static String norm(String a) {
        a = a.trim().toLowerCase();
        if (a.endsWith(":25565")) a = a.substring(0, a.length() - 6);
        return a;
    }

    /** Address of the server you are on now, or null (singleplayer / not connected). */
    public static String current() {
        MinecraftClient mc = MinecraftClient.getInstance();
        ServerInfo si = mc.getCurrentServerEntry();
        return si == null ? null : si.address;
    }

    private static void save() {
        try {
            List<String> out = new ArrayList<>();
            out.add("# Allowed (HvH) servers. Manage them in game with:  .server add <ip>  /  .server remove <ip>");
            List<String> l = new ArrayList<>(allowed);
            Collections.sort(l);
            out.addAll(l);
            Files.write(file(), out);
        } catch (Exception ignored) {}
    }

    public static boolean add(String addr) {
        boolean r = allowed.add(norm(addr));
        if (r) save();
        return r;
    }

    public static boolean remove(String addr) {
        boolean r = allowed.remove(norm(addr));
        if (r) save();
        return r;
    }

    public static List<String> list() {
        List<String> l = new ArrayList<>(allowed);
        Collections.sort(l);
        return l;
    }
}
