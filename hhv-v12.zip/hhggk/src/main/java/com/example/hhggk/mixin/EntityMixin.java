package com.example.hhggk.mixin;

import com.example.hhggk.Settings;
import com.example.hhggk.module.EntityFilter;
import com.example.hhggk.module.visual.Esp;
import com.example.hhggk.module.combat.Hitbox;
import com.example.hhggk.module.ModuleManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public class EntityMixin {

    @Inject(method = "getTargetingMargin", at = @At("HEAD"), cancellable = true)
    private void hhggk$margin(CallbackInfoReturnable<Float> cir) {
        Hitbox h = ModuleManager.hitbox;
        Entity self = (Entity) (Object) this;
        if (h != null && h.enabled && self.getWorld().isClient && Settings.active()) {
            int k = EntityFilter.kind(self, MinecraftClient.getInstance().player);
            if (k >= 0 && h.allows(k)) cir.setReturnValue(h.margin(self, MinecraftClient.getInstance().player));
        }
    }

    @Inject(method = "isGlowing", at = @At("HEAD"), cancellable = true)
    private void hhggk$glow(CallbackInfoReturnable<Boolean> cir) {
        Esp e = ModuleManager.esp;
        Entity self = (Entity) (Object) this;
        if (e != null && e.enabled && self.getWorld().isClient && Settings.active()) {
            int k = EntityFilter.kind(self, MinecraftClient.getInstance().player);
            if (k >= 0 && e.allows(k)) cir.setReturnValue(true);
        }
    }
}
