package com.example.hhggk.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

import java.util.function.Predicate;

/** Small inventory helpers shared by the PvP modules. */
public class Inv {
    public static String path(ItemStack s) {
        return Registries.ITEM.getId(s.getItem()).getPath();
    }

    /** Hotbar slot (0-8) of the first matching stack, or -1. */
    public static int hotbar(ClientPlayerEntity p, Predicate<ItemStack> f) {
        for (int i = 0; i < 9; i++) if (f.test(p.getInventory().getStack(i))) return i;
        return -1;
    }

    public static int hotbar(ClientPlayerEntity p, Item item) {
        return hotbar(p, s -> s.isOf(item));
    }

    /** Container slot id (player screen handler) for an inventory index 0-35. */
    public static int container(int invIndex) {
        return invIndex < 9 ? 36 + invIndex : invIndex;
    }

    /** Rank of the armor material from the item id: netherite 6 ... leather 1. 0 = not armor. */
    public static int material(ItemStack s) {
        if (s.isEmpty()) return 0;
        String n = path(s);
        if (n.startsWith("netherite_")) return 6;
        if (n.startsWith("diamond_")) return 5;
        if (n.startsWith("iron_")) return 4;
        if (n.startsWith("chainmail_")) return 3;
        if (n.startsWith("golden_")) return 2;
        if (n.startsWith("leather_") || n.startsWith("turtle_")) return 1;
        return 0;
    }

    /** 0 = head, 1 = chest, 2 = legs, 3 = feet, -1 = not armor. */
    public static int armorKind(ItemStack s) {
        if (s.isEmpty()) return -1;
        String n = path(s);
        if (n.endsWith("_helmet")) return 0;
        if (n.endsWith("_chestplate")) return 1;
        if (n.endsWith("_leggings")) return 2;
        if (n.endsWith("_boots")) return 3;
        return -1;
    }

    public static double armorScore(ItemStack s) {
        if (s.isEmpty() || armorKind(s) < 0) return 0;
        double d = 1.0;
        if (s.isDamageable() && s.getMaxDamage() > 0) d = 1.0 - (double) s.getDamage() / s.getMaxDamage();
        return material(s) * 10 + d * 5;
    }

    public static boolean hasPotionEffect(ItemStack s, RegistryEntry<StatusEffect> effect) {
        PotionContentsComponent c = s.get(DataComponentTypes.POTION_CONTENTS);
        if (c == null) return false;
        for (StatusEffectInstance e : c.getEffects()) {
            if (e.getEffectType().equals(effect)) return true;
        }
        return false;
    }

    public static boolean isSplash(ItemStack s) {
        return s.isOf(Items.SPLASH_POTION);
    }

    /** Swaps two inventory stacks through the cursor (3 clicks max). Both are container slot ids. */
    public static void swapSlots(MinecraftClient mc, ClientPlayerEntity p, int a, int b) {
        int sync = p.playerScreenHandler.syncId;
        mc.interactionManager.clickSlot(sync, a, 0, SlotActionType.PICKUP, p);
        mc.interactionManager.clickSlot(sync, b, 0, SlotActionType.PICKUP, p);
        if (!p.playerScreenHandler.getCursorStack().isEmpty()) {
            mc.interactionManager.clickSlot(sync, a, 0, SlotActionType.PICKUP, p);
        }
    }
}
