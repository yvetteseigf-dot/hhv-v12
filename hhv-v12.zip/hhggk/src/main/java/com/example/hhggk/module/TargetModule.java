package com.example.hhggk.module;

/** Module with a "which entity types" filter. */
public abstract class TargetModule extends Module {
    public final Setting.Bool players;
    public final Setting.Bool hostile;
    public final Setting.Bool animals;
    public final Setting.Bool others;

    protected TargetModule(String name, Category c, boolean p, boolean h, boolean a, boolean o) {
        super(name, c);
        players = add(new Setting.Bool("Players", p));
        hostile = add(new Setting.Bool("Hostile mobs", h));
        animals = add(new Setting.Bool("Animals", a));
        others = add(new Setting.Bool("Other mobs", o));
    }

    public boolean allows(int kind) {
        return switch (kind) {
            case 0 -> players.value;
            case 1 -> hostile.value;
            case 2 -> animals.value;
            case 3 -> others.value;
            default -> false;
        };
    }
}
