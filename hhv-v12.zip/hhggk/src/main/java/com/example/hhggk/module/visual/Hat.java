package com.example.hhggk.module.visual;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.util.math.MathHelper;

/** A hat floating on your head (rendered in WorldRender, visible in third person / F5). */
public class Hat extends Module {
    public final Setting.Mode style = add(new Setting.Mode("Style", "Top hat", "Crown", "Wizard", "Halo"));
    public final Setting.Mode color = add(new Setting.Mode("Color", "Black", "Red", "Gold", "Cyan", "Purple", "Rainbow"));
    public final Setting.Num size = add(new Setting.Num("Size", 1.0, 0.5, 2.0, 0.1));

    public Hat() { super("Hat", Category.VISUAL); }

    /** @return {r, g, b} 0..1 */
    public float[] rgb(double timeOffset) {
        return switch (color.get()) {
            case "Red" -> new float[]{0.85f, 0.1f, 0.12f};
            case "Gold" -> new float[]{1.0f, 0.78f, 0.15f};
            case "Cyan" -> new float[]{0.2f, 0.9f, 1.0f};
            case "Purple" -> new float[]{0.62f, 0.25f, 0.95f};
            case "Rainbow" -> {
                int c = MathHelper.hsvToRgb((float) (((System.currentTimeMillis() / 12.0 + timeOffset) % 360) / 360.0), 0.8f, 1f);
                yield new float[]{((c >> 16) & 255) / 255f, ((c >> 8) & 255) / 255f, (c & 255) / 255f};
            }
            default -> new float[]{0.08f, 0.08f, 0.1f};
        };
    }
}
