package com.example.hhggk.module.misc;

import com.example.hhggk.module.Module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.thrown.EnderPearlEntity;
import net.minecraft.text.Text;

import java.util.HashSet;
import java.util.Set;

/** Tells you when another player throws an ender pearl nearby (so you know they are about to teleport). */
public class PearlAlert extends Module {
    private final Set<Integer> seen = new HashSet<>();

    public PearlAlert() { super("PearlAlert", Category.MISC); }

    @Override
    public void onEnable() { seen.clear(); }

    @Override
    public void onTick(MinecraftClient mc) {
        Set<Integer> now = new HashSet<>();
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof EnderPearlEntity pearl)) continue;
            now.add(e.getId());
            if (seen.contains(e.getId())) continue;
            Entity owner = pearl.getOwner();
            if (owner == null || owner == mc.player) continue;
            mc.player.sendMessage(Text.literal(String.format("[Diamond] %s threw an ender pearl (%.0f blocks away)",
                    owner.getName().getString(), mc.player.distanceTo(owner))), false);
        }
        seen.clear();
        seen.addAll(now);
    }
}
