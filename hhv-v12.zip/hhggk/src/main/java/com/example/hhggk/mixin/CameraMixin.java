package com.example.hhggk.mixin;

import com.example.hhggk.Settings;
import com.example.hhggk.module.render.Freecam;
import com.example.hhggk.module.ModuleManager;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.Entity;
import net.minecraft.world.BlockView;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Camera.class)
public abstract class CameraMixin {
    @Shadow
    protected abstract void setPos(double x, double y, double z);

    @Inject(method = "update", at = @At("TAIL"))
    private void hhggk$update(BlockView area, Entity focusedEntity, boolean thirdPerson,
                                 boolean inverseView, float tickDelta, CallbackInfo ci) {
        if (ModuleManager.freecam != null && ModuleManager.freecam.enabled && Settings.active()) {
            setPos(Freecam.x, Freecam.y, Freecam.z);
        }
    }
}
