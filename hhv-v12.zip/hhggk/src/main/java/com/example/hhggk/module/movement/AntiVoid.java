package com.example.hhggk.module.movement;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

/** Pushes you back up when you fall to the bottom of the world. */
public class AntiVoid extends Module {
    public final Setting.Num above = add(new Setting.Num("Trigger above world bottom", 0, -20, 20, 1));
    public AntiVoid() { super("AntiVoid", Category.MOVEMENT); }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p.getY() > mc.world.getBottomY() + above.value || p.getAbilities().flying || p.isGliding()) return;
        Vec3d v = p.getVelocity();
        p.setVelocity(v.x, 0.9, v.z);
        p.fallDistance = 0;
    }
}
