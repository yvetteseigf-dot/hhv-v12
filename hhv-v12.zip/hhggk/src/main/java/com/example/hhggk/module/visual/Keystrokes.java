package com.example.hhggk.module.visual;

import com.example.hhggk.module.Module;
import com.example.hhggk.module.Setting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;

public class Keystrokes extends Module {
    public final Setting.Bool jump = add(new Setting.Bool("Show space", true));
    public final Setting.Num scale = add(new Setting.Num("Key size", 22, 16, 34, 2));

    public Keystrokes() { super("Keystrokes", Category.VISUAL); }

    private void key(DrawContext ctx, MinecraftClient mc, KeyBinding k, String label, int x, int y, int w, int h) {
        boolean on = k.isPressed();
        ctx.fill(x, y, x + w, y + h, on ? 0xD0FFFFFF : 0xA0101018);
        ctx.fill(x, y, x + w, y + 1, on ? 0xFFFFFFFF : 0xFF5CE1FF);
        ctx.drawCenteredTextWithShadow(mc.textRenderer, label, x + w / 2, y + (h - 8) / 2 + 1, on ? 0xFF000000 : 0xFFFFFFFF);
    }

    @Override
    public void onHud(DrawContext ctx, MinecraftClient mc) {
        int s = (int) scale.value, g = 2;
        int x0 = 8, y0 = ctx.getScaledWindowHeight() - (jump.value ? s * 3 + g * 3 + 6 : s * 2 + g * 2 + 6) - 28;
        key(ctx, mc, mc.options.forwardKey, "W", x0 + s + g, y0, s, s);
        key(ctx, mc, mc.options.leftKey, "A", x0, y0 + s + g, s, s);
        key(ctx, mc, mc.options.backKey, "S", x0 + s + g, y0 + s + g, s, s);
        key(ctx, mc, mc.options.rightKey, "D", x0 + 2 * (s + g), y0 + s + g, s, s);
        if (jump.value) key(ctx, mc, mc.options.jumpKey, "SPACE", x0, y0 + 2 * (s + g), s * 3 + g * 2, s - 6);
    }
}
