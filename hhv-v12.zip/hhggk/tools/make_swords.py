"""Generates the 6 custom sword textures (16x16). Run:  python3 tools/make_swords.py"""
from PIL import Image
import os

OUT = os.path.join(os.path.dirname(__file__), "..", "src/main/resources/assets/minecraft/textures/item")

# blade_light, blade_mid, blade_dark, guard, handle, gem
MATS = {
    "wooden":    ((0xE8C98A), (0xB98B4E), (0x7A5428), (0xC9A24A), (0x5A3A1E), (0x7CFF9F)),
    "stone":     ((0xE4E7EC), (0xA6ADB8), (0x5F6672), (0xC9A24A), (0x5A3A1E), (0xFF9F43)),
    "iron":      ((0xFFFFFF), (0xD7DEE8), (0x8A94A6), (0xC9A24A), (0x4A3020), (0x5CE1FF)),
    "golden":    ((0xFFF6B0), (0xFFD23F), (0xC98A12), (0xFF7A3D), (0x6A3A1E), (0xFF4D6D)),
    "diamond":   ((0xE8FFFF), (0x4DEBFF), (0x1795B8), (0xDDEFFF), (0x3A2A55), (0xFF5CE1)),
    "netherite": ((0xD9C7E8), (0x8A6FA8), (0x3E2A55), (0xFF8A3D), (0x2A2230), (0xFF3D3D)),
}

def rgb(h): return ((h >> 16) & 255, (h >> 8) & 255, h & 255, 255)

def make(name, pal):
    light, mid, dark, guard, handle, gem = [rgb(c) for c in pal]
    img = {}
    # blade: tip (14,1) running down-left to (6,9); 2px wide with a bright core line
    for i in range(9):
        x, y = 14 - i, 1 + i
        img[(x, y)] = light                 # core
        img[(x - 1, y)] = mid               # body
        img[(x, y + 1)] = dark if i < 8 else mid   # shaded lower edge
    img[(15, 0)] = light                    # sharp tip
    img[(14, 0)] = mid
    # fuller (inner shine) every other pixel
    for i in range(1, 8, 2):
        img[(13 - i, 1 + i)] = light
    # crossguard through (5,10), perpendicular to the blade
    for k in range(-2, 3):
        img[(5 + k, 10 + k)] = guard
    img[(5, 10)] = gem
    # handle running down-left
    for i in range(4):
        img[(4 - i, 11 + i)] = handle
    img[(0, 15)] = guard                    # pommel
    # 1px dark outline
    out = dict(img)
    for (x, y) in list(img):
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                nx, ny = x + dx, y + dy
                if 0 <= nx < 16 and 0 <= ny < 16 and (nx, ny) not in out:
                    out[(nx, ny)] = (20, 16, 30, 255)
    im = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    for (x, y), c in out.items():
        if 0 <= x < 16 and 0 <= y < 16:
            im.putpixel((x, y), c)
    im.save(os.path.join(OUT, f"{name}_sword.png"))

for n, p in MATS.items():
    make(n, p)
print("swords written to", os.path.abspath(OUT))
