"""
Turns ANY image into the main-menu background (anime wallpaper etc).
Usage:  python3 tools/make_background.py my_anime_image.png
Writes the 6 panorama files the game uses (the menu "rotates" around your picture).
Then rebuild the mod.   Needs: pip install pillow
"""
import sys, os
from PIL import Image

OUT = os.path.join(os.path.dirname(__file__), "..", "src/main/resources/assets/minecraft/textures/gui/title/background")
os.makedirs(OUT, exist_ok=True)

def build(src):
    im = Image.open(src).convert("RGB")
    s = min(im.size)                      # centre-crop to a square
    l, t = (im.width - s) // 2, (im.height - s) // 2
    im = im.crop((l, t, l + s, t + s)).resize((1024, 1024), Image.LANCZOS)
    for i in range(6):
        im.save(os.path.join(OUT, f"panorama_{i}.png"))
    print("wrote 6 panorama files to", os.path.abspath(OUT))

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(__doc__); sys.exit(1)
    build(sys.argv[1])
