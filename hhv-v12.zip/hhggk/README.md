# Diamond v2  (Fabric 1.21.4)

Build like before:  ./gradlew build   ->  build/libs/hhggk-1.0.0.jar
Menu key: P        Chat commands: type "." in chat (suggestions appear, Tab completes)

## Chat commands
.cfg save <name> | .cfg load <name> | .cfg delete <name> | .cfg list     (files: config/hhggk/configs/<name>.json)
.friend add <name> | remove <name> | list | clear                         (friends are ignored by Aura/ElytraTarget/Hitbox)
.toggle <module>   |   .help

## New / changed
- ElytraTarget: predictive intercept (velocity + acceleration), virtual block AHEAD of the target (red/cyan box),
  yellow path dots, full-speed fireworks, LOCK phase matches target speed + aim glued + auto attack.
- AutoMace: before every mace hit the server is told you fell "Fake fall height" blocks (max 200) while you stay in place.
  Does not work while gliding (vanilla rule). Needs free air above you.
- Hitbox: "Show real box" draws box + size. ShowHitboxes: gray = vanilla box, red = real expanded box, red line = eyes.
- Hat (Top hat / Crown / Wizard / Halo, colors) - visible in F5.   Hell - realistic fire particles from your body.
- New ClickGui: readable text, - / + buttons on every slider (hold to repeat, Shift = x5), switches, right click = back.
- Swords: tools/make_swords.py (already generated into assets/minecraft/textures/item).
- Main menu background: python3 tools/make_background.py my_anime_image.png   (a placeholder is included)

## v3 changes
- Freecam: body is frozen (input swapped every tick, speed 0, no jumping, optional position lock).
- ElytraTarget: rockets are now taken from offhand / hotbar / **inventory**; warns in the action bar if you have none.
- Hell: works in first person (ring of fire around you), ignores "Particles: Minimal".
- FakePlayer: Take damage, Auto totem (pops with the real animation, counts pops), Targetable by Aura.
- Aura: 1.9 combat only (one hit per full cooldown). CPS / wait-cooldown options removed.
- Hitbox: size up to 5.0 + "Grow with distance".
- New list **Visual** (ESP, Fullbright, FOV, NoWeather, ShowHitboxes, Hat, Hell + 13 new).
- 25 new modules:
  Combat: TriggerBot, CrystalBreaker, AutoGap, BowAimbot, Reach, Velocity, AntiBot, Teams, PopCounter
  Movement: NoFall, BunnyHop, AutoElytra
  Visual: Tracers, Trails, JumpCircles, HitParticles, KillEffect, TargetCircle, HitMarker, ComboCounter,
          Crosshair, Keystrokes, TotemCount, Ping, LowHealth

## v6: Aura rotation modes (HvH/Smooth/Legit/Snap, head locked every tick) + 40 new modules (auto-registered)

## v4: folders per menu (drop-in modules)
Each menu has its own folder under src/main/java/com/example/hhggk/module/ :
  combat/  movement/  visual/  render/  misc/
To add a module: put your .java file in the folder of the menu you want, with
  package com.example.hhggk.module.<folder>;   and   super("Name", Category.<MENU>);
It is picked up automatically at startup (no need to edit ModuleManager). Rebuild with ./gradlew build.
Aura: "Delay (ticks)" 20 = one hit per second; "Long range" = nearest loaded mob up to 150 blocks
(only works on servers that do not check reach).

## v7
- Main menu replaced by LuxeTitleScreen (artwork: assets/hhggk/textures/gui/luxe_menu.png - replace the PNG to change it).
- FakePlayer: spawns in front of you ("Spawn distance"), is always added to Aura / AimAssist / ElytraTarget target lists,
  and hits on it are handled locally (no packet is sent to the server).
- 15 more modules (HUD: ChunkHud, LightLevelHud, DimensionHud, VelocityHud, FallDistanceHud, FreeSlots, BlockUnderfoot,
  MemoryHud, ArmorStatus, SpeedLines; Dash (V), LongJump, AutoSneak, JumpReset, LowHpSound).

## v11: 38 new PvP modules (all auto-registered, no editing of ModuleManager needed)
Combat (14): Criticals, MoreKnockback, AutoCrystal, Surround, AutoTrap, AutoWeb, HoleFill, AutoPot, AutoBuff,
             AutoArmor, AutoTool, Burrow (one-shot), BowSpam, ShieldBreaker
Movement (8): Strafe, SafeWalk, Scaffold, HoleSnap, HoleAnchor, ElytraSwap (one-shot), TargetStrafe, GuiMove
Visual (7):  HoleESP, StorageESP, ItemESP, CrystalESP, BlockHighLight, Trajectories, LogoutSpots
Misc (9):    AutoEZ, AutoTPaccept, VisualRange, MiddleClick, AutoEat, DurabilityAlert, HotbarReplenish,
             ChestStealer, PearlAlert
Helpers: module/Inv.java, module/BlockUtil.java, module/Drawable3D.java (+ render/Overlay3D.java for 3D boxes).
Hooks: Criticals + MoreKnockback are called from AttackMixin. One-shot modules (Burrow, ElytraSwap) switch themselves off.

## v12
- AutoTrap rewritten:
  - Server: "No protection" (fast, several blocks/tick) or "With protection" (aims, visible face only, reach limit, 1 block per delay)
  - Block: click it in the menu -> list of EVERY block, search, pick, press Yes
  - Shape: Full / Sides / Feet ring / Head ring + top / Full + floor / Cage / Double top
  - Target: Closest / Lowest health, Take from inventory, Disable when done
- Keybinds: .bind <module> <key>  (one press = on, press again = off) | .bind <module> none | .bind list
  examples: .bind AutoTrap g   .bind TpNearest f6   .bind Aura mouse4   (saved in config/hhggk-binds.json)
- New module TpNearest (Movement): teleports to the nearest player and keeps repeating (Packet or /tp command).
  Only for HvH servers without movement protection.
